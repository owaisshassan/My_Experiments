package com.ndml.user_module.exceptions;

public class PasswordExpiryException extends RuntimeException {

	public PasswordExpiryException() {

	}

	public PasswordExpiryException(String error) {
		super(error);
	}

}
