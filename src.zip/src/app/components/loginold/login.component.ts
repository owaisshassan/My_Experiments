import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';

import { UserService } from 'src/app/service/user.service';
import { ForgotPasswordComponent } from '../forgot-password/forgot-password.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { sha512 } from 'js-sha512';
import { MatSnackBar } from '@angular/material/snack-bar';
import { User } from 'src/app/model/user';
import { AppConfig } from 'src/app/app.config';
import Keyboard from "simple-keyboard";

@Component({
  selector: 'app-login',
  templateUrl: './loginold.component.html',
  styleUrls: ['./loginold.component.css']
})
export class LoginoldComponent implements OnInit {

  user: User;
  loginForm: FormGroup;
  status: false;
  hide = true;
  returnUrl: string;
  userStat = false;
  verifiedCap = false;
  base64Image = '';

  styleVisi:any;
  styleInvisi:any;
  checkedVKey=false;
  showVK;
  value;
  keyboard: Keyboard;
  optForVK=false;

  constructor(private dialog: MatDialog,
    private userServices: UserService,
    private snackBar: MatSnackBar,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private sanitizer: DomSanitizer,
    private snackbar: MatSnackBar,
    private config:AppConfig
  ) { }

  async ngOnInit() {
    const EMAIL_REGEX = /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    const NEW_EMAIL_REGEX= /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z]+\.)+[a-zA-Z]{2,}))$/;
    
    this.loginForm = this.formBuilder.group({
      captchaString: ['', Validators.compose([Validators.required, Validators.minLength(5)])],
      password: ['', Validators.compose([Validators.required, ])],//Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}') //space " " not allowed (?!.* ) // ^(?!.* )(?=.*\d)(?=.*[A-Z]).{8,15}$
      email_id: ['', Validators.compose([Validators.required, Validators.minLength(9), Validators.maxLength(100),Validators.pattern(EMAIL_REGEX),Validators.pattern(NEW_EMAIL_REGEX)])],//Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')
    });
    
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/login';

    this.styleInvisi = {
      "display": "none",
    };
    this.styleVisi = {
      "display": "block",
      "width": "100%",
      "height": "auto",
      "margin-bottom": "10px",
    };
    this.showVK=this.styleInvisi

  }

  handleSubmit() {
    let formData = this.loginForm.value;
    // formData.password=this.value;

    let data = {
      email: formData.email_id,
      password: sha512(formData.password)
    }

    console.log(data);
    sessionStorage.setItem('useremail', data.email);
    sessionStorage.setItem('userpassword', data.password);
    this.getCapfromserver();
    this.userStat = true;
  }

  finalSubmit(user: any) {
    console.log("User email : " + sessionStorage.getItem('useremail'));
    console.log("inside final submit..." + user);
    if (this.verifiedCap) {
      let data = {
        email: sessionStorage.getItem('useremail'),
        password: sessionStorage.getItem('userpassword')
      }
      this.userServices.login(data).subscribe({
        next: (resp: any) => {
          console.log(resp.token);
          console.log(resp.redirectURL);
          console.log(resp.expDt);
          this.snackBar.open('logged in successfully! redirecting...', 'Dismiss', {
            duration: 3000,
          });
          let url = new URL(`${resp.redirectURL}`);
          url.searchParams.set('token', `${resp.token}`);
          url.searchParams.set('expDt', `${resp.expDt}`);
          window.location.href = url.href;
        },
        error: (error: any) => {
          this.snackbar.open(error + '\nplease try again', 'Dismiss', {
            duration: 3000,
          });
          setTimeout(() => {
            this.userServices.goToSSOPage();
          }, 500);
        }
      })
    }
  }

  handleForgotPasswordAction() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = "550px";
    this.dialog.open(ForgotPasswordComponent, dialogConfig);
  }

  checkCaptcha() {
    if (this.status) {
      this.snackbar.open('Captcha verification successfull...\nLogining in', 'Dismiss', {
        duration: 3000,
      });
      return true;
    }
    else {
      this.snackbar.open('Captcha verification failed...\nplease retry captcha and login again', 'Dismiss', {
        duration: 3000,
      });
      this.getCapfromserver();
      this.loginFormreset();
      return false;
    }
  }

  transformImage() {
    return this.sanitizer.bypassSecurityTrustResourceUrl('data:image/png;base64,' + this.base64Image);
  }

  getCapfromserver() {
    this.userServices.getCaptcha(sessionStorage.getItem('useremail')).subscribe({
      next: (resp: any) => {
        this.base64Image = resp;
        sessionStorage.setItem('capQues', resp);
      },
      error: (error) => {
        console.log(error);
      }
    })
  }

  verifyCaptcha() {
    this.verifiedCap = true;
    let data = {
      user: sessionStorage.getItem("useremail"),
      capQue: sessionStorage.getItem("capQues"),
      answer: this.loginForm.controls['captchaString'].value
    }

    this.userServices.verifyCap(data).subscribe({
      next: (resp: any) => {
        console.log("Captcha Verification Result: " + resp);
        this.status = resp;
        if (this.status) {
          this.loginForm.controls['captchaString'].disable();
          this.snackbar.open('Captcha verification successfull...\nProceed to Login!', 'Dismiss', {
            duration: 2000,
          });
          return true;
        }
        else {
          this.snackbar.open('Captcha verification failed...\nplease retry again', 'Dismiss', {
            duration: 2000,
          });
          this.getCapfromserver();
          this.loginFormreset();
          this.userStat = false;
          return false;
        }
      },
      error: (error) => {
        console.log("something went wrong");
        this.loginForm.reset();
      }
    })
  }

  loginFormreset() {
    this.loginForm.reset()
  }

  ngAfterViewInit() {
    this.keyboard = new Keyboard({
        onChange: input => this.onChange(input),
        onKeyPress: button => this.onKeyPress(button),
        theme: "hg-theme-default myTheme1",
       /*display: {
          '{bksp}': '← Backspace',
          '{enter}': '↵ Enter',
          '{shift}': '⇧ SHIFT',
          '{tab}': '↹ Tab',
          '{lock}': '⇩ Lock',
          '{space}': 'Spacebar',
      },*/
    });
}

onChange = (input: string) => {
    this.value = input;
};

onKeyPress = (button: string) => {
    /* To handle the shift and caps lock buttons */
    if (button === "{shift}" || button === "{lock}") {
      this.handleShift();
    }
};

onInputChange = (event: any) => {
    this.keyboard.setInput(event.target.value);
    this.loginForm.controls['password'].setValue(event.target.value);
};

handleShift = () => {
    let currentLayout = this.keyboard.options.layoutName;
    let shiftToggle = currentLayout === "default" ? "shift" : "default";

    this.keyboard.setOptions({
        layoutName: shiftToggle
    });
};

toggleVkey(checkedVKey:any){
  this.checkedVKey=!checkedVKey;
  if(!this.checkedVKey){
    this.optForVK=false;
  }
  else{
    this.optForVK=true;
  }
}

checkForVk() {
  if(this.optForVK) {
    this.showVK=this.styleVisi;
  }
  else {
    this.showVK=this.styleInvisi;
  }
}

}