package com.ndml.user_module.exceptions;

public class LogoutException extends RuntimeException{
	
	public LogoutException() {
		// TODO Auto-generated constructor stub
	}
	
	public LogoutException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
	

}
