package com.ndml.user_module.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ndml.user_module.model.MenuMaster;

public interface MenuMasterRepository extends JpaRepository<MenuMaster, Long>{

	public Optional<MenuMaster> findByMenuName(String menuName);
	
	public List<MenuMaster> findByMenuParentId(long parentId);
	
	//public MenuMaster getFirstMenu(String email);
	
	//public MenuMaster findByDisplayOrder(long parentId);
	
}
