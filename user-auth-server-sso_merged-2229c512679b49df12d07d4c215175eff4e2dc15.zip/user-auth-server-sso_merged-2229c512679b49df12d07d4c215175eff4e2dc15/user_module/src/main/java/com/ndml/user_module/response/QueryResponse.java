package com.ndml.user_module.response;

import java.util.List;

import com.ndml.user_module.model.MenuMaster;

public class QueryResponse {

	private long userid;

	private String useremail;

	private String username;

	private String roleName;

	private String roleDescription;

	private String application_name;

	private List<MenuMaster> menuList;

	private String accessToken;

	public QueryResponse(long userid, String useremail, String username, String roleName, String roleDescription,
			String application_name, List<MenuMaster> menuList, String accessToken) {
		super();
		this.userid = userid;
		this.useremail = useremail;
		this.username = username;
		this.roleName = roleName;
		this.roleDescription = roleDescription;
		this.application_name = application_name;
		this.menuList = menuList;
		this.accessToken = accessToken;
	}

	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}

	public String getUseremail() {
		return useremail;
	}

	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleDescription() {
		return roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	public String getApplication_name() {
		return application_name;
	}

	public void setApplication_name(String application_name) {
		this.application_name = application_name;
	}

	public List<MenuMaster> getMenuList() {
		return menuList;
	}

	public void setMenuList(List<MenuMaster> menuList) {
		this.menuList = menuList;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	@Override
	public String toString() {
		return "QueryResponse [userid=" + userid + ", useremail=" + useremail + ", username=" + username + ", roleName="
				+ roleName + ", roleDescription=" + roleDescription + ", application_name=" + application_name
				+ ", menuList=" + menuList + ", accessToken=" + accessToken + "]";
	}

}
