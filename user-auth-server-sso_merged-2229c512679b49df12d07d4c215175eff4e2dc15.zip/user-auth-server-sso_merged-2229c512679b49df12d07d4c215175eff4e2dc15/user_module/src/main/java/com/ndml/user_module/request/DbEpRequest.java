package com.ndml.user_module.request;

public class DbEpRequest {
	
	private String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	
	public DbEpRequest() {
		// TODO Auto-generated constructor stub
	}
	public DbEpRequest(String email) {
		super();
		this.email = email;
	}

	@Override
	public String toString() {
		return "DbEpRequest [email=" + email + "]";
	}
	
	

}
