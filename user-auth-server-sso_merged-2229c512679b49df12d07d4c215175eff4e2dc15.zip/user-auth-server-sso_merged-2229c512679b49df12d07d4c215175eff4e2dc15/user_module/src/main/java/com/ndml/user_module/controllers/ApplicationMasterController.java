package com.ndml.user_module.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ndml.user_module.exceptions.ApplicationException;
import com.ndml.user_module.model.ApplicationMaster;
import com.ndml.user_module.repositories.ApplicationMasterRepository;
import com.ndml.user_module.request.ApplicationRegisterRequest;
import com.ndml.user_module.services.ApplicationMasterService;


@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/app")
@EnableCaching
public class ApplicationMasterController {

	@Autowired
	private ApplicationMasterService appService;

	@Autowired
	private ApplicationMasterRepository applicationMasterRepo;

//  localhost:8083/app/register
	@PostMapping("/register")
	public ResponseEntity<String>registerNewApplicationHandler(@RequestBody ApplicationRegisterRequest request,HttpServletRequest http){
		
		System.out.println("inside register controller of app : "+request.getApplicationName());
		
		String appName =  request.getApplicationName().toUpperCase();
		
		ApplicationMaster app = 
				applicationMasterRepo.findByApplicationName(appName);
	
		if(app != null ) throw new ApplicationException("Sorry, Application with this Application-Name already Exists!");

		
		String registered =  appService.addNewApplication(request,http);
		
		return new ResponseEntity<String>(registered,HttpStatus.OK);
	}
	
	
	
	
	
	// localhost:8083/app/updatename
	@PutMapping("/updatename")
	public ResponseEntity<String> updateUserPasswordHandler(@RequestParam String oldPass,
															@RequestParam String newPass){
		String updatedName = appService.updateApplicationName(oldPass, newPass);
		
		return new ResponseEntity<String>(updatedName,HttpStatus.OK);
	}

}
