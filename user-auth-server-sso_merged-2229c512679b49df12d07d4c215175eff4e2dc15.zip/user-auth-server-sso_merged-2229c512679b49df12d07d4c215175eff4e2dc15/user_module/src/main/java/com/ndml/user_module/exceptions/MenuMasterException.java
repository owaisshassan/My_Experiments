package com.ndml.user_module.exceptions;

public class MenuMasterException extends RuntimeException{
	
	public MenuMasterException() {
		// TODO Auto-generated constructor stub
	}
	
	public MenuMasterException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
