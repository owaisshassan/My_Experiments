package com.ndml.user_module.exceptions;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(UserDetailsException.class)
	public ResponseEntity<ErrorDetails> customerExceptionHandler(UserDetailsException ce, WebRequest req) {

		ErrorDetails error = new ErrorDetails();
		error.setMessage(ce.getMessage());
		error.setTimeStamp(LocalDateTime.now());
		error.setDescription(req.getDescription(false));

		return new ResponseEntity<ErrorDetails>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(ApplicationException.class)
	public ResponseEntity<ErrorDetails> applicationExceptionHandler(ApplicationException ce, WebRequest req) {

		ErrorDetails error = new ErrorDetails();
		error.setMessage(ce.getMessage());
		error.setTimeStamp(LocalDateTime.now());
		error.setDescription(req.getDescription(false));

		return new ResponseEntity<ErrorDetails>(error, HttpStatus.BAD_GATEWAY);
	}

	@ExceptionHandler(MenuMasterException.class)
	public ResponseEntity<ErrorDetails> menuMasterExceptionHandler(MenuMasterException ce, WebRequest req) {

		ErrorDetails error = new ErrorDetails();
		error.setMessage(ce.getMessage());
		error.setTimeStamp(LocalDateTime.now());
		error.setDescription(req.getDescription(false));

		return new ResponseEntity<ErrorDetails>(error, HttpStatus.BAD_GATEWAY);
	}

	@ExceptionHandler(RoleMenuMapperException.class)
	public ResponseEntity<ErrorDetails> roleMenuMapperExceptionHandler(RoleMenuMapperException ce, WebRequest req) {

		ErrorDetails error = new ErrorDetails();
		error.setMessage(ce.getMessage());
		error.setTimeStamp(LocalDateTime.now());
		error.setDescription(req.getDescription(false));

		return new ResponseEntity<ErrorDetails>(error, HttpStatus.BAD_GATEWAY);
	}

	@ExceptionHandler(AddUrlException.class)
	public ResponseEntity<ErrorDetails> addUrlExceptionHandler(AddUrlException ce, WebRequest req) {

		ErrorDetails error = new ErrorDetails();
		error.setMessage(ce.getMessage());
		error.setTimeStamp(LocalDateTime.now());
		error.setDescription(req.getDescription(false));

		return new ResponseEntity<ErrorDetails>(error, HttpStatus.BAD_GATEWAY);
	}

	@ExceptionHandler(DPMasterException.class)
	public ResponseEntity<ErrorDetails> DPMasterExceptionHandler(DPMasterException ce, WebRequest req) {

		ErrorDetails error = new ErrorDetails();
		error.setMessage(ce.getMessage());
		error.setTimeStamp(LocalDateTime.now());
		error.setDescription(req.getDescription(false));

		return new ResponseEntity<ErrorDetails>(error, HttpStatus.BAD_GATEWAY);
	}

	@ExceptionHandler(LoginException.class)
	public ResponseEntity<ErrorDetails> LoginExceptionHandler(LoginException e, WebRequest req) {

		ErrorDetails error = new ErrorDetails();
		error.setMessage(e.getMessage());
		error.setTimeStamp(LocalDateTime.now());
		error.setDescription(req.getDescription(false));

		return new ResponseEntity<ErrorDetails>(error, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(LogoutException.class)
	public ResponseEntity<ErrorDetails> LogoutExceptionHandler(LogoutException e, WebRequest req) {

		ErrorDetails error = new ErrorDetails();
		error.setMessage(e.getMessage());
		error.setTimeStamp(LocalDateTime.now());
		error.setDescription(req.getDescription(false));

		return new ResponseEntity<ErrorDetails>(error, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(InvalidPasswordException.class)
	public ResponseEntity<ErrorDetails> invalidPasswordExceptionHandler(InvalidPasswordException ce, WebRequest req) {

		ErrorDetails error = new ErrorDetails();
		error.setMessage(ce.getMessage());
		error.setTimeStamp(LocalDateTime.now());
		error.setDescription(req.getDescription(false));

		return new ResponseEntity<ErrorDetails>(error, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(AlreadyExistsException.class)
	public ResponseEntity<ErrorDetails> invalidPasswordExceptionHandler(AlreadyExistsException ce, WebRequest req) {

		ErrorDetails error = new ErrorDetails();
		error.setMessage(ce.getMessage());
		error.setTimeStamp(LocalDateTime.now());
		error.setDescription(req.getDescription(false));

		return new ResponseEntity<ErrorDetails>(error, HttpStatus.FORBIDDEN);
	}
	
	@ExceptionHandler(NotFoundException.class)
	public ResponseEntity<ErrorDetails> invalidPasswordExceptionHandler(NotFoundException ce, WebRequest req) {

		ErrorDetails error = new ErrorDetails();
		error.setMessage(ce.getMessage());
		error.setTimeStamp(LocalDateTime.now());
		error.setDescription(req.getDescription(false));

		return new ResponseEntity<ErrorDetails>(error, HttpStatus.NOT_FOUND);
	}

	

	@ExceptionHandler(EndPointException.class)
	public ResponseEntity<ErrorDetails> endPointExceptionHandler(EndPointException ce, WebRequest req) {

		ErrorDetails error = new ErrorDetails();
		error.setMessage(ce.getMessage());
		error.setTimeStamp(LocalDateTime.now());
		error.setDescription(req.getDescription(false));

		return new ResponseEntity<ErrorDetails>(error, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorDetails> genericExceptionHandler(Exception e, WebRequest req) {

		ErrorDetails error = new ErrorDetails();
		error.setMessage(e.getMessage());
		error.setTimeStamp(LocalDateTime.now());
		error.setDescription(req.getDescription(false));

		return new ResponseEntity<ErrorDetails>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
