package com.ndml.user_module.response;

public class OtpResponseBean<T> {

	private TransactionBean response;
	private T data;

	public TransactionBean getResponse() {
		return response;
	}

	public void setResponse(TransactionBean response) {
		this.response = response;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "ResponseBean [response=" + response + ", data=" + data + "]";
	}

}
