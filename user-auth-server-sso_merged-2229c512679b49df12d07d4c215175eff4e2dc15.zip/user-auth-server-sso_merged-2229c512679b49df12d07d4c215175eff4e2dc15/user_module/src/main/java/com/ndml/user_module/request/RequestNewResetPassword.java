package com.ndml.user_module.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class RequestNewResetPassword {

	private String newPassword;
	private String email;
	private String mobile;
	private String mobileOtp;
	private String resetPasswordToken;
	private String requestType;
	

}
