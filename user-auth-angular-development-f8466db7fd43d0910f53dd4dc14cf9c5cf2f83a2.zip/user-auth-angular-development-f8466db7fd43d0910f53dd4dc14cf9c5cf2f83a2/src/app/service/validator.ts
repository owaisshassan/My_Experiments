import { AbstractControl, ValidatorFn } from '@angular/forms';

// export function phoneNumberValidator(): ValidatorFn {
//   return (control: AbstractControl): { [key: string]: any } | null => {
//     const phoneNumber = control.value;
//     if (phoneNumber && !/^\d{10}$/.test(phoneNumber)) {
//       return { 'invalidPhoneNumber': true };
//     }
//     return null;
//   };
// }

export function phoneNumberValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    const phoneNumber = control.value;
    if ((phoneNumber && !/^[6-9]\d{9}$/.test(phoneNumber))) {
      return { 'invalidPhoneNumber': true };
    }
    return null;
  };
}

export function emailValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const email = control.value;
      if (!email || !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
        return { 'invalidEmail': true };
      }
      return null;
    };
  }

  export function passValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
      const valid = passwordRegex.test(control.value);
      return valid ? null : { invalidPassword: { value: control.value } };
    };
  }

  // export function passValidator(): { validator: ValidatorFn, regex: RegExp } {
  //   const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  //   const validatorFn: ValidatorFn = (control: AbstractControl): { [key: string]: any } | null => {
  //     const valid = passwordRegex.test(control.value);
  //     return valid ? null : { invalidPassword: { value: control.value } };
  //   };
  //   return { validator: validatorFn, regex: passwordRegex };
  // }