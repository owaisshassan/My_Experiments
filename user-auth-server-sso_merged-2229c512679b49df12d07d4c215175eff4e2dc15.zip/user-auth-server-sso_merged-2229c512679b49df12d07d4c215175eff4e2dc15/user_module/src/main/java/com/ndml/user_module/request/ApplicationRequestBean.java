package com.ndml.user_module.request;

public class ApplicationRequestBean {

	private String appid;

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	@Override
	public String toString() {
		return "ApplicationRequestBean [appid=" + appid + "]";
	}
	
	

}
