package com.ndml.user_module.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MenuMaster {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long menuId;
	private String menuName;
	private String menuDisplayName;
	private long menuParentId;
	private String menuDescription;
	private long applicationId;
	private boolean isActive;
	private String routingUrl;
	private int displayOrder;
	private Date crtdDt;
	private Date updtDt;
	private String menuIcon;
	
	public MenuMaster(String menuName, String menuDisplayName, long menuParentId, String menuDescription,
			long applicationId, boolean isActive) {
		super();
		this.menuName = menuName;
		this.menuDisplayName = menuDisplayName;
		this.menuParentId = menuParentId;
		this.menuDescription = menuDescription;
		this.applicationId = applicationId;
		this.isActive = isActive;
	}
	
	
	
	
	

}
