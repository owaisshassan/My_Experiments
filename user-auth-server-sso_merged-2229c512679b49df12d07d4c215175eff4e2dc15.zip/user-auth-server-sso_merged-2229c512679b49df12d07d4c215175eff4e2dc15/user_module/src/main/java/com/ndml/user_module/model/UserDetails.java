package com.ndml.user_module.model;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UserDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long userid;
	private String username;

	@Column(unique = true)
	private String useremailId;

//	@Column(unique = true)
	private String usermobileNumber;

	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private String password; // hashed/some checksome
	private Date pwdexpdt;
	private String dpID;
	private long applicationid;
	private long roleId;
	private int loginAttempt;
	private String lastLogin;
	private boolean isLocked;
	private boolean isActive;
	private String crtdDt;
	private String updtDt;

	
	private String resetPasswordToken;
	
	@Column(name = "pwd_salt")
	private String passwordSalt;

	@Column(columnDefinition = "DATE")
	private LocalDateTime tokenCreationDate;

	

	public LocalDateTime getTokenCreationDate() {
		return tokenCreationDate;
	}

	public void setTokenCreationDate(LocalDateTime tokenCreationDate) {
		this.tokenCreationDate = tokenCreationDate;
	}

	public UserDetails(String username, String useremailId, String password) {
		super();
		this.username = username;
		this.useremailId = useremailId;
		this.password = password;
	}

	public UserDetails(String username, String useremailId, String usermobileNumber, String password, Date pwdexpdt,
			String crtdDt) {
		super();
		this.username = username;
		this.useremailId = useremailId;
		this.usermobileNumber = usermobileNumber;
		this.password = password;
		this.pwdexpdt = pwdexpdt;
		this.crtdDt = crtdDt;
	}

	public UserDetails(String username, String useremailId, String usermobileNumber, String password, String dpID,
			long applicationid, long roleId) {
		super();
		this.username = username;
		this.useremailId = useremailId;
		this.usermobileNumber = usermobileNumber;
		this.password = password;
		this.dpID = dpID;
		this.applicationid = applicationid;
		this.roleId = roleId;
	}

}
