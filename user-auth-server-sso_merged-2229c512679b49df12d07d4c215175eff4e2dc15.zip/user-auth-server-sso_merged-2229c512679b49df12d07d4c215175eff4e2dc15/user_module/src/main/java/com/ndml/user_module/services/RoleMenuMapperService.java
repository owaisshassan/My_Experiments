package com.ndml.user_module.services;

import com.ndml.user_module.exceptions.RoleMenuMapperException;
import com.ndml.user_module.model.RoleMenuMapper;
import com.ndml.user_module.request.RoleMenuMapperRequest;

public interface RoleMenuMapperService {
	
	public RoleMenuMapper addNewRoleMenuMapper(RoleMenuMapperRequest request) throws RoleMenuMapperException;

}
