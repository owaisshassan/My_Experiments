package com.ndml.user_module.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class SigninResponseBean {
	private String t1;
	private String t2;
	private String t3;
	private String t4;
	private String t5;
	private String t6;

	private String redirectURL;

	private String expDt;

	private String emailId;
	
	private String message;

	public SigninResponseBean(String t1, String t2, String t3, String t4, String t5, String t6, String redirectURL,
			String expDt, String emailId) {
		super();
		this.t1 = t1;
		this.t2 = t2;
		this.t3 = t3;
		this.t4 = t4;
		this.t5 = t5;
		this.t6 = t6;
		this.redirectURL = redirectURL;
		this.expDt = expDt;
		this.emailId = emailId;
	}
	
	
	
	
	
}
