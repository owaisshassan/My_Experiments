package com.ndml.user_module.request;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ActiveUserRequest {
	
	private String username;
	
	private String token;
	
	private String dcryptKey;
	

}
