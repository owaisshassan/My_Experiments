package com.ndml.user_module.services.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ndml.user_module.model.OTPDetails;
import com.ndml.user_module.repositories.OneTimePasswordRepository;
import com.ndml.user_module.services.CommonService;

@Service
public class CommonServiceImpl implements CommonService {

	private static final Logger logger = LoggerFactory.getLogger(CommonServiceImpl.class);

	@Autowired
	OneTimePasswordRepository otpRepository;

	@Override
	public OTPDetails checkResendOtpCount(String requestType, String mobileNo, String emailId) {
		logger.info("Inside checkResendOtpCount method");
		return otpRepository.findByOtpRequestTypeEmailIdAndMobileNumber(requestType,
				mobileNo, emailId);
	}

}
