package com.ndml.user_module.model;

public enum ERole {
	
	  ROLE_USER,
	  ROLE_CHECKER,
	  ROLE_MAKER

}
