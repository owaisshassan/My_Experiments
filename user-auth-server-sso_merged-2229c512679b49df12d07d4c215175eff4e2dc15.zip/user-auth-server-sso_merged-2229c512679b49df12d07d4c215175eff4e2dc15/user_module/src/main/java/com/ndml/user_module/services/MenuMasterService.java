package com.ndml.user_module.services;

import java.util.List;

import com.ndml.user_module.exceptions.MenuMasterException;
import com.ndml.user_module.exceptions.RoleException;
import com.ndml.user_module.exceptions.RoleMenuMapperException;
import com.ndml.user_module.exceptions.UserDetailsException;
import com.ndml.user_module.model.MenuMaster;
import com.ndml.user_module.request.GetMenuDetailsRequest;
import com.ndml.user_module.request.MenuMasterRegisterRequest;

public interface MenuMasterService {
	
	public MenuMaster addNewMenu(MenuMasterRegisterRequest request) throws MenuMasterException;
	
	public List<MenuMaster> getMenuDetailsThroughRoleMenuMapper(GetMenuDetailsRequest request) throws MenuMasterException, 
																RoleMenuMapperException, RoleException, UserDetailsException;

}
