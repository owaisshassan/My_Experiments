package com.ndml.user_module.utility;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

	@Override
	@Transactional
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {

		String name = authentication.getName();
		String password = authentication.getCredentials().toString();

//       Optional<User> u = userRepo.findByEmail(authentication.getName());
//        List<String> userRoles = new ArrayList<>();
//        		u.get().getRoles().forEach(r -> userRoles.add(r.getName().toString()));

		System.out.println("authentication.getName() Inside 'authenticate' method of 'CustomAuthenticationProvider': "
										+ ""+"/n" + name);

		// authentication.getAuthorities().add(new SimpleGrantedAuthority(""));

		if (shouldAuthenticateAgainstThirdPartySystem(name, password)) {
			System.out.println("shouldAuthenticateAgainstThirdPartySystem = true");
			// use the credentials
			// and authenticate against the third-party system
//            return new UsernamePasswordAuthenticationToken(
//              name, null, new ArrayList<>());
			return new UsernamePasswordAuthenticationToken(name, null, new ArrayList<>());
		} else {
			return null;
		}
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}

	// **

	public boolean shouldAuthenticateAgainstThirdPartySystem(String username, String pass) {
		return true;
	}

}
