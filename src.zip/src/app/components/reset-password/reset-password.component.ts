import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { sha512 } from 'js-sha512';
import { UserService } from 'src/app/service/user.service';
import { ConfirmPasswordValidator } from 'src/app/shared/confirm-password.validator';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {

  resetPasswordForm: any = FormGroup;
  responseMessage: any;
  hideN = true;
  hideC = true;

  constructor(private formBuilder: FormBuilder,
    private userService: UserService,
    public dialogRef: MatDialogRef<ResetPasswordComponent>,
    private snackbar:MatSnackBar
    ) { }

  ngOnInit(): void {
    this.resetPasswordForm = this.formBuilder.group({
      newPassword: [null, [Validators.required]],
      confirmPassword: [null, [Validators.required]]
    },
    {
      validator: ConfirmPasswordValidator("newPassword", "confirmPassword")
    });
  }

  handleSubmit() {
    var formData = this.resetPasswordForm.value;
    var data = {
      newPassword: sha512(formData.newPassword),
      resetPasswordToken: localStorage.getItem('resetPasswordToken')
    }
    console.log(data);

    this.userService.resetPassword(data).subscribe({
      next: (resp:any) => {
        this.dialogRef.close();
        console.log(resp);
        this.snackbar.open("Password updated successfully...", 'Dismiss', {
          duration: 3000,
        });
      },
      error: (error) => {
        this.dialogRef.close();
      }
    });
    
  }

}