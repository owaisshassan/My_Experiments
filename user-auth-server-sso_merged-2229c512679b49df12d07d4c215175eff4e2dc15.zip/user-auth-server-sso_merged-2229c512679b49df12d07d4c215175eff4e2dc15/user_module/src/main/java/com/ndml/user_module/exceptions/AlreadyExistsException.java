package com.ndml.user_module.exceptions;

public class AlreadyExistsException extends RuntimeException{
	
	public AlreadyExistsException() {
		// TODO Auto-generated constructor stub
	}

	public AlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
	
	

}
