package com.ndml.user_module.utility;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

//@EnableCaching
public class JwtCacheUtil { // **

	private static Map<String, Map<String, Date>> userNameJwtMapper = new HashMap<String, Map<String, Date>>();

	public static Map<String, Map<String, Date>> getUserNameJwtMapper() {
		return userNameJwtMapper;
	}

	public static void setUserNameJwtMapper(Map<String, Map<String, Date>> userNameJwtMapper) {
		JwtCacheUtil.userNameJwtMapper = userNameJwtMapper;
	}

	static Logger log = Logger.getLogger(JwtCacheUtil.class.getName());

	// @Cacheable("logincache")
	public static Map<String, Map<String, Date>> currentUserjwtCacheDetails(String username, String jwt, Date expiry) {

		if (userNameJwtMapper.containsKey(username)) {

			if (userNameJwtMapper.get(username).containsKey(jwt)) {
				if ((userNameJwtMapper.get(username).get(jwt)).compareTo(expiry) == 0)
					log.warning("username, Jwt , expiry are already present.");

			}
			userNameJwtMapper.get(username).put(jwt, expiry);
			log.info("jwt + expiry added to 'userNameJwtMapper' for '" + username + "' ");

		} else {
			Map<String, Date> jwtExpiryMapper = new HashMap<>();
			jwtExpiryMapper.put(jwt, expiry);
			userNameJwtMapper.put(username, jwtExpiryMapper);
		}

		System.out.println("Active Users : " + userNameJwtMapper.size());
		System.out.println("Active Users List : ");
		userNameJwtMapper.entrySet().forEach(c -> System.out.println(c));

		return userNameJwtMapper;
	}

//
//	private static List<String> usernameJwtMapper = new ArrayList<>();
//	
//	
//	
//	static Logger log = Logger.getLogger(JwtCacheUtil.class.getName());
//
//	@Cacheable("logincache")
//	public static List<String> currentUserjwtCacheDetails(String username) {
//		 
//		
//		boolean flag = false;
//
//		for (int i = 0; i < usernameJwtMapper.size(); i++) {
//			if (usernameJwtMapper.get(i).equals(username) ) {
//				System.out.println("JWT already cached!");
//				log.warning("JWT already cached!");
//				flag = true;
//			}
//		}
//
//		
//
//		if (!flag)
//			usernameJwtMapper.add(username);
//
//		return usernameJwtMapper;
//	}

//	 Map<String, Long> jwtExpiryMapper =  userNameJwtMapper.get(username);
//	 for(int j = 0; j< jwtExpiryMapper.size(); j++) {
//		 if(jwtExpiryMapper.containsKey(jwt) && jwtExpiryMapper.get(jwt) == expiry) {
//			 log.warning("username , jwt , expiry are already present.");
//		 }else if (jwtExpiryMapper.containsKey(jwt)) {
//			 log.warning("username present but jwt.");
//		 }
//	 }

	// deleting expired dates from cache :

//	 for (Map<String, Date> jwtKeys : userNameJwtMapper.values()) {
//		 System.out.println("value: " + jwtKeys);
//		 for(Date expiryDate : jwtKeys.values()) {
//			 System.out.println("Dates : "+ expiryDate);
//			 if(expiryDate.before(new Date())) {
//				 System.out.println("DATE NOW : "+ new Date());
//				 System.out.println(expiryDate +" is expired before "+new Date());
//				 userNameJwtMapper.remove(jwtKeys, expiryDate);
//			 }
//		 }
//	 }
//	 
//	 System.out.println("AFTER DELETING EXPIRED USERS :  : : : : :");
//	 System.out.println( "Active Users : "  + userNameJwtMapper.size());
//	 System.out.println("Active Users List : ");
//	 userNameJwtMapper.entrySet().forEach(c -> System.out.println(c));

}
