package com.ndml.user_module.services.impl;

import java.util.Date;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ndml.user_module.exceptions.ApplicationException;
import com.ndml.user_module.model.ApplicationMaster;
import com.ndml.user_module.repositories.ApplicationMasterRepository;
import com.ndml.user_module.request.ApplicationRegisterRequest;
import com.ndml.user_module.services.ApplicationMasterService;

@Service
public class ApplicationServiceImpl implements ApplicationMasterService {

	Logger log = Logger.getLogger(ApplicationServiceImpl.class.getName());

	@Value("${ndml.appmaster.isActive}")
	private boolean isApplicationActive;

	@Autowired
	private ApplicationMasterRepository applicationMasterRepo;

	@Override
	public String addNewApplication(ApplicationRegisterRequest appRegisterRequest, HttpServletRequest http)
			throws ApplicationException {

		log.info("appName Inside appServiceImpl : " + appRegisterRequest.getApplicationName());

		String appName = appRegisterRequest.getApplicationName().toUpperCase();

		// create new Application :
		ApplicationMaster appMaster = new ApplicationMaster();
		appMaster.setApplicationName(appRegisterRequest.getApplicationName());
		appMaster.setRedirectURL(appRegisterRequest.getApplicationName() + "/dashboard");
		appMaster.setApplicationName(appName);
		appMaster.setCrtdDt(new Date());
		appMaster.setActive(isApplicationActive);

		log.info("isApplicationActive boolean: " + isApplicationActive);

		applicationMasterRepo.save(appMaster);

		return "new AppMaster Registered successfully!";
	}

	@Override
	public String updateApplicationName(String oldAppName, String newAppName) throws ApplicationException {
		// TODO Auto-generated method stub
		ApplicationMaster app = applicationMasterRepo.findByApplicationName(oldAppName);
		if (app == null)
			throw new ApplicationException("No Application found with this name!");

		if (!app.isActive())
			throw new ApplicationException("Sorry, This Application is not active currently!");
		app.setApplicationName(newAppName);
		app.setUpdtDt(new Date());
		applicationMasterRepo.save(app);
		String res = oldAppName + " successfully changed to " + newAppName;

		return res;
	}

}
