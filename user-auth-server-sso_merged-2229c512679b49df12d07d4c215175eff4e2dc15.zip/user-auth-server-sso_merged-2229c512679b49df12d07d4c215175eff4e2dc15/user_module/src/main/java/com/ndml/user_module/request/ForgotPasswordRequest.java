package com.ndml.user_module.request;

public class ForgotPasswordRequest {

	private String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public ForgotPasswordRequest() {
		// TODO Auto-generated constructor stub
	}

	public ForgotPasswordRequest(String email) {
		super();
		this.email = email;
	}

	@Override
	public String toString() {
		return "ForgotPasswordRequest [email=" + email + "]";
	}

}
