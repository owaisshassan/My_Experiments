package com.ndml.user_module.response;

import java.util.Objects;

public class CustomResponseMenuMaster {

	private long id;
	private String icon; // frontend_icon
	private String text; // menu name
	private String action;
	private long menuFatherId;
	private String children;
	private String routingUrl;
	private int displayOrder;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public long getMenuFatherId() {
		return menuFatherId;
	}
	public void setMenuFatherId(long menuFatherId) {
		this.menuFatherId = menuFatherId;
	}
	public String getChildren() {
		return children;
	}
	public void setChildren(String children) {
		this.children = children;
	}
	public String getRoutingUrl() {
		return routingUrl;
	}
	public void setRoutingUrl(String routingUrl) {
		this.routingUrl = routingUrl;
	}
	public int getDisplayOrder() {
		return displayOrder;
	}
	public void setDisplayOrder(int displayOrder) {
		this.displayOrder = displayOrder;
	}
	@Override
	public int hashCode() {
		return Objects.hash(action, children, displayOrder, icon, id, menuFatherId, routingUrl, text);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomResponseMenuMaster other = (CustomResponseMenuMaster) obj;
		return Objects.equals(action, other.action) && Objects.equals(children, other.children)
				&& displayOrder == other.displayOrder && Objects.equals(icon, other.icon) && id == other.id
				&& menuFatherId == other.menuFatherId && Objects.equals(routingUrl, other.routingUrl)
				&& Objects.equals(text, other.text);
	}
	public CustomResponseMenuMaster(long id, String icon, String text, String action, long menuFatherId,
			String children, String routingUrl, int displayOrder) {
		super();
		this.id = id;
		this.icon = icon;
		this.text = text;
		this.action = action;
		this.menuFatherId = menuFatherId;
		this.children = children;
		this.routingUrl = routingUrl;
		this.displayOrder = displayOrder;
	}
	@Override
	public String toString() {
		return "CustomResponseMenuMaster [id=" + id + ", icon=" + icon + ", text=" + text + ", action=" + action
				+ ", menuFatherId=" + menuFatherId + ", children=" + children + ", routingUrl=" + routingUrl
				+ ", displayOrder=" + displayOrder + "]";
	}

	
}
