import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { UserService } from './user.service';


@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {

    constructor(private snackbar: MatSnackBar,  private userService: UserService) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        let token = JSON.parse(localStorage.getItem('token'));
        let expDt = JSON.parse(localStorage.getItem('expDt'));
        if (token && expDt) {
            let url = new URL(route.data['externalUrl']);
            url.searchParams.set('token', `${JSON.parse(localStorage.getItem('token'))}`);
            url.searchParams.set('expDt', `${JSON.parse(localStorage.getItem('expDt'))}`);
            window.location.href = url.href;
            return true;
        }
        else {
            this.snackbar.open('Something went wrong!\nServer not responding.\nplease try again later', 'Dismiss', {
                duration: 3000,
            });
            // window.location.reload();
            this.userService.goToSSOPage()
        }
    }
}