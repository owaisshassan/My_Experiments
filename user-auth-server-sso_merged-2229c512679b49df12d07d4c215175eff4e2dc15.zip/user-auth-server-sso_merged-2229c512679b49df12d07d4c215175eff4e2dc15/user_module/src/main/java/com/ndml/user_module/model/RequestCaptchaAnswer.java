package com.ndml.user_module.model;

public class RequestCaptchaAnswer {

	String user;
	String capQue;
	String answer;

	public RequestCaptchaAnswer(String user, String capQue, String answer) {
		super();
		this.user = user;
		this.capQue = capQue;
		this.answer = answer;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getCapQue() {
		return capQue;
	}

	public void setCapQue(String capQue) {
		this.capQue = capQue;
	}
	
	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

}
