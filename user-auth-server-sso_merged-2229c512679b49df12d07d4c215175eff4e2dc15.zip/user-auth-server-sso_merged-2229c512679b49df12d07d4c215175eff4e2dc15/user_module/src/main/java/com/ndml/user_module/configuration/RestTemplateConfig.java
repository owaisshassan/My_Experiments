package com.ndml.user_module.configuration;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {

	@Value("${connection.timeout}")
	Integer connTimeout;
	
	@Value("${ndml.proxy.host.name}")
	private String proxyHostName;

	@Value("${ndml.proxy.port.name}")
	private String proxyPortName;


	@Bean
	public RestTemplate getRestTemplate() {

		int proxyPort = 0;
		String proxyHost = null;
		

		proxyHost = proxyHostName;
		proxyPort = Integer.parseInt(proxyPortName);

		Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress(proxyHost, proxyPort));
		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
		requestFactory.setProxy(proxy);

		return new RestTemplate(requestFactory);
	}

}
