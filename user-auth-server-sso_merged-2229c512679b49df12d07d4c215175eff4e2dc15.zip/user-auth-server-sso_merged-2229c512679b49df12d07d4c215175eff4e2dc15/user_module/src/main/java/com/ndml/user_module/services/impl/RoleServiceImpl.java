package com.ndml.user_module.services.impl;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ndml.user_module.model.RoleMaster;
import com.ndml.user_module.repositories.RoleMasterRepository;
import com.ndml.user_module.services.RoleMasterService;

@Service
public class RoleServiceImpl implements RoleMasterService {

	@Autowired
	private RoleMasterRepository roleMasterRepo;

	@Override
	public String addApp09UserRole() throws Exception {
		// TODO Auto-generated method stub
		Optional<RoleMaster> repoRole = roleMasterRepo.findByRoleName("DAC_user");
		if (repoRole.isPresent())
			throw new Exception("User role is already present!");
		RoleMaster role = new RoleMaster();
		role.setRoleName("DAC_user");
		role.setCrtdDt(LocalDateTime.now());
		role.setRoleDescription("USER");
		roleMasterRepo.save(role);
		return role.toString();
	}

	@Override
	public String addApp09CheckerRole() throws Exception {
		Optional<RoleMaster> repoRole = roleMasterRepo.findByRoleName("DAC_checker");
		if (repoRole.isPresent())
			throw new Exception("Checker role is already present!");
		RoleMaster role = new RoleMaster();
		role.setRoleName("DAC_checker");
		role.setCrtdDt(LocalDateTime.now());
		role.setRoleDescription("CHECKER");
		roleMasterRepo.save(role);
		return role.toString();
	}

	@Override
	public String addApp09MakerRole() throws Exception {
		Optional<RoleMaster> repoRole = roleMasterRepo.findByRoleName("DAC_maker");
		if (repoRole.isPresent())
			throw new Exception("Maker role is already present!");
		RoleMaster role = new RoleMaster();
		role.setRoleName("DAC_maker");
		role.setCrtdDt(LocalDateTime.now());
		role.setRoleDescription("MAKER");
		roleMasterRepo.save(role);
		return role.toString();
	}

	@Override
	public String addApp10UserRole() throws Exception {
		// TODO Auto-generated method stub
		Optional<RoleMaster> repoRole = roleMasterRepo.findByRoleName("INSTIGO_user");
		if (repoRole.isPresent())
			throw new Exception("User role is already present!");
		RoleMaster role = new RoleMaster();
		role.setRoleName("INSTIGO_user");
		role.setCrtdDt(LocalDateTime.now());
		role.setRoleDescription("USER");
		roleMasterRepo.save(role);
		return role.toString();
	}

	@Override
	public String addApp10CheckerRole() throws Exception {
		Optional<RoleMaster> repoRole = roleMasterRepo.findByRoleName("INSTIGO_checker");
		if (repoRole.isPresent())
			throw new Exception("Checker role is already present!");
		RoleMaster role = new RoleMaster();
		role.setRoleName("INSTIGO_checker");
		role.setCrtdDt(LocalDateTime.now());
		role.setRoleDescription("CHECKER");
		roleMasterRepo.save(role);
		return role.toString();
	}

	@Override
	public String addApp10MakerRole() throws Exception {
		Optional<RoleMaster> repoRole = roleMasterRepo.findByRoleName("INSTIGO_maker");
		if (repoRole.isPresent())
			throw new Exception("Maker role is already present!");
		RoleMaster role = new RoleMaster();
		role.setRoleName("INSTIGO_maker");
		role.setCrtdDt(LocalDateTime.now());
		role.setRoleDescription("MAKER");
		roleMasterRepo.save(role);
		return role.toString();
	}

	@Override
	public String addApp11UserRole() throws Exception {
		Optional<RoleMaster> repoRole = roleMasterRepo.findByRoleName("RTA_user");
		if (repoRole.isPresent())
			throw new Exception("User role is already present!");
		RoleMaster role = new RoleMaster();
		role.setRoleName("RTA_user");
		role.setCrtdDt(LocalDateTime.now());
		role.setRoleDescription("USER");
		roleMasterRepo.save(role);
		return role.toString();
	}

	@Override
	public String addApp11CheckerRole() throws Exception {
		Optional<RoleMaster> repoRole = roleMasterRepo.findByRoleName("RTA_checker");
		if (repoRole.isPresent())
			throw new Exception("Checker role is already present!");
		RoleMaster role = new RoleMaster();
		role.setRoleName("RTA_checker");
		role.setCrtdDt(LocalDateTime.now());
		role.setRoleDescription("CHECKER");
		roleMasterRepo.save(role);
		return role.toString();
	}

	@Override
	public String addApp11MakerRole() throws Exception {
		Optional<RoleMaster> repoRole = roleMasterRepo.findByRoleName("RTA_maker");
		if (repoRole.isPresent())
			throw new Exception("Maker role is already present!");
		RoleMaster role = new RoleMaster();
		role.setRoleName("RTA_maker");
		role.setCrtdDt(LocalDateTime.now());
		role.setRoleDescription("MAKER");
		roleMasterRepo.save(role);
		return role.toString();
	}

}
