import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AppConfig } from '../app.config';
import { UserService } from './user.service';


@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
    constructor( private snackbar:MatSnackBar,private config:AppConfig, private userServices:UserService) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(request).pipe(catchError(err => {
            if ([401, 403].includes(err.status) ) {//&& this.authenticationService.userValue
                this.snackbar.open("Unauthorized/Forbidden user", 'Dismiss', {
                    duration: 3000,
                  });
                setTimeout(() => {
                    this.userServices.goToSSOPage();
            // window.location.replace("http://172.19.83.110:4200/login");
                }, 1000);
            }
            if ([400].includes(err.status)) {
                this.snackbar.open("New password must not match previous 3 passwords! Please try again..", 'Dismiss', {
                    duration: 3000,
                  });
                console.log("2");
                setTimeout(() => {
                    this.userServices.goToSSOPage();
            // window.location.replace("http://172.19.83.110:4200/login");
                }, 1000);
            }
            if ([500].includes(err.status)) {
                this.snackbar.open("Internal Server Error! please try again later...", 'Dismiss', {
                    duration: 3000,
                  });
                console.log("3");
                setTimeout(() => {
                    // this.userServices.goToSSOPage();
            // window.location.replace("http://172.19.83.110:4200/login");
                }, 1000);
            }

            if (err instanceof TypeError) {
                console.log("Type error");
            }

            const error = (err && err.error && err.error.message) || err.statusText;
            return throwError(error);
        }))
    }
}