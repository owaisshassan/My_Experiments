import {
  Injectable,
  Inject
} from '@angular/core';
import {
  Location
} from '@angular/common';
import {
  HttpClient
} from '@angular/common/http';
import {
  observable,
  Observable
} from 'rxjs';
import {
  environment
} from 'src/environments/environment';
import { MatSnackBar } from '@angular/material/snack-bar';


@Injectable({
  providedIn: 'root'
})
export class ConfigService {

  private appConfig: any;
  private serverLocation;
  private localLocation;
  private location;

  constructor(private http: HttpClient, private snackbar: MatSnackBar) {

    //     this.serverLocation = '/RTAWeb/assets/dac.json';
    // this.Location='/assets/dac.json';
    // const baseurl = window.location.pathname.split('/')[1];


    // To get config from assets/config path
    // const baseurl = document.getElementsByTagName('base')[0].baseURI;
    // if (baseurl === '') {
    //   this.location = '/assets/dac.json';
    // } else {
    //   this.location = baseurl + 'assets/dac.json';
    // }
    // console.log('location of config file', this.location);



    // To get config from common url path
    const host = window.location.origin;
    this.location = host + '/portal-config/portal-rtaweb.json';
    console.log('location of config file', this.location);

    // this.location="http://172.25.15.184:8085/portal-config/portal-rtaweb.json"
  }


  loadConfig(callback) {
    const self = this;
    // let configApiUrl;

    console.log('evei', environment);
    // (environment.production) ? configApiUrl = this.serverLocation: configApiUrl = this.localLocation;

    // let configApiUrl = `/assets/dac.json`;
    // if (localConfigUrl) {
    // 	configApiUrl = localConfigUrl + configApiUrl;
    // }
    const xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
      if (this.readyState === 4) {
        if (this.status === 200) {
          self.appConfig = JSON.parse(xhttp.responseText);
          callback(true);
        } else {
          console.log('Internal Server Error. Http Status: ' + this.status);
          callback(false);
          // self.snackbar.open('Error in loading config file', 'close', {
          //   duration: 10000
          // });
        }
      }
    };
    xhttp.open('GET', this.location, true);
    xhttp.send();
  }

  // This is an example property ... you can make it however you want.
  getConfig(params?: string) {

    // for deployment
    if (!environment.production) {
      return environment[params];
    }

    if (!this.appConfig) {
      console.log('Config file not loaded!');
    }

    if (this.appConfig && params) {
      return this.appConfig[params];
    }

    return this.appConfig;
  }
}
