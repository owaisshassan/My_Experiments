package com.ndml.user_module.exceptions;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SSOBusinessException extends Exception {

	private static final long serialVersionUID = 1L;

	Logger logger = LoggerFactory.getLogger(SSOBusinessException.class);

	private String errorForUser;

	private String errorCode;

	public SSOBusinessException(String errorMessage) {
		super(errorMessage);
		this.errorForUser = errorMessage;
	}

	public SSOBusinessException(String errorCode, String errorMessage) {
		super(errorMessage);
		this.errorForUser = errorMessage;
		this.errorCode = errorCode;
	}

	public String getErrorForUser() {
		return errorForUser;
	}

	public String getErrorCode() {
		return errorCode;
	}

}
