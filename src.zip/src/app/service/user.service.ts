import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../model/user';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { Router } from '@angular/router';
import { AppConfig } from '../app.config';
import { catchError } from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable({
  providedIn: 'root'
})
export class UserService {

  // authUrl = 'http://10.250.10.106:8082/sso-core';
  // authUrl = 'http://10.250.10.106:8082/sso-core';


  private userSubject: BehaviorSubject<User>;
  public user: Observable<User>;

  constructor(private http: HttpClient, private router: Router, private config: AppConfig,) {
    this.userSubject = new BehaviorSubject<User>(null);
    this.user = this.userSubject.asObservable();
  }

  public get userValue(): User {
    return this.userSubject.value;
  }

  login(data: any) {
    return this.http.post(this.config.GetSsoCoreUrl + "/auth/user/login", data, { headers: new HttpHeaders().set('Content-Type', 'application/json') })
  }

  forgotPassword(data: any) {
    return this.http.post(this.config.GetSsoCoreUrl + `/user/forgot-password`, data, { responseType: 'text' })
  }

  getOtp(body, url) {
    console.log('body inside getOtp', body);
    return this.http.post(this.config.GetSsoCoreUrl + url, body, httpOptions).pipe(
      catchError(this.handleError<object>('APIerror', []))
    );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error); // log to console instead

      console.log(`${operation} failed: ${error.message}`);
      result = error;
      return of(result as T);
    };

  }

  resetPassword(data: any) {
    return this.http.post(this.config.GetSsoCoreUrl + "/user/reset-password", data, { responseType: 'text' })
  }

  getCaptcha(user: any) {
    return this.http.post(this.config.GetSsoCoreUrl + '/app/user/getcap', user, { responseType: 'text' });
  }

  verifyCap(data: any) {
    return this.http.post(this.config.GetSsoCoreUrl + "/app/user/verifyCaptcha", data, { headers: new HttpHeaders().set('Content-Type', 'application/json') })
  }

  goToSSOPage(){
    window.location.replace(this.config.GetSsoWebUrl);
  }

  getHash(data: any) {
    return this.http.post(this.config.GetSsoCoreUrl + "/user/pwdsalt", data, { headers: new HttpHeaders().set('Content-Type', 'application/json') })
  }

}