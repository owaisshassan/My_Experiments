package com.ndml.user_module.controllers;

import java.nio.charset.Charset;
import java.util.Random;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
//import org.springframework.cache.annotation.Cacheable;
//import org.springframework.cache.annotation.EnableCaching;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ndml.user_module.constants.SSOConstants;
import com.ndml.user_module.request.ForgotPasswordRequest;
import com.ndml.user_module.request.LoginRequest;
import com.ndml.user_module.request.RequestNewResetPassword;
import com.ndml.user_module.response.GetPwrdSaltResponseBean;
import com.ndml.user_module.response.ResetPasswordResponseBean;
import com.ndml.user_module.services.UserDetailsService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/user")
//@EnableCaching
public class UserController {

	@Value("${ndml.app.jwtSecret}")
	private String jwtSecret;

	@Autowired
	private UserDetailsService userService;

	@PostMapping("/forgot-password")
	public ResponseEntity<String> forgotPasswordHandler(@RequestBody ForgotPasswordRequest request) throws Exception {

		System.out.println("User email for forgot password : " + request.getEmail());
		String resetPassToken = userService.forgotPassword(request);

		return new ResponseEntity<String>(resetPassToken, HttpStatus.OK);
	}

	@PostMapping("/reset-password")
	public ResponseEntity<?> resetPassword(@RequestBody RequestNewResetPassword req) {
		
		String response = "";

		ResetPasswordResponseBean resetPasswordResponse = userService.resetPassword(req);
		
		if(resetPasswordResponse.getResponse() != null && 
					resetPasswordResponse.getResponse().equalsIgnoreCase(SSOConstants.SSO_ERROR_MESSAGE)) {
			
			response = resetPasswordResponse.getResponseMsg();
		}else {
			response = "Password reset successfully.";
		}

	
		return new ResponseEntity<String>(response, HttpStatus.OK);
	}
	
	@PostMapping("/pwdsalt")
	public ResponseEntity<?> getLoginHash(@RequestBody LoginRequest req) {
		GetPwrdSaltResponseBean pwrdSaltResponseBean = new GetPwrdSaltResponseBean();
		
		
		try {
			pwrdSaltResponseBean = userService.getRandomPasswordSalt(req);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			pwrdSaltResponseBean.setResponse("Wrong email!");
			e.printStackTrace();
		}
	    
	    
	    return new ResponseEntity<GetPwrdSaltResponseBean>(pwrdSaltResponseBean, HttpStatus.OK);
	}
	
	
}
