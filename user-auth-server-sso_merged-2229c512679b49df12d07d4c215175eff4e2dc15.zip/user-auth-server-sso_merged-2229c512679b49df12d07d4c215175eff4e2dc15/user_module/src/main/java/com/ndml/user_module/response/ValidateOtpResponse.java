package com.ndml.user_module.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ValidateOtpResponse {
	
	
	private boolean isValid;
	
	private String errorMsg;

}
