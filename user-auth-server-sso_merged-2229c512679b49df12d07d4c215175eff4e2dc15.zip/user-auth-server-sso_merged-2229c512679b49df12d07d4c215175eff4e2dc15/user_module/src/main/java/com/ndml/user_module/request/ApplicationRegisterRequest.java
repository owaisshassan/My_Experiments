package com.ndml.user_module.request;

import java.time.LocalDateTime;

public class ApplicationRegisterRequest {

	private String applicationName;

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

}
