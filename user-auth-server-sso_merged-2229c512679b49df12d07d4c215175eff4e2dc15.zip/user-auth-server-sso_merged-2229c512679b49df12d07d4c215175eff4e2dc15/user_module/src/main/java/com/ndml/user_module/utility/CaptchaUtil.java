package com.ndml.user_module.utility;

import java.util.concurrent.ConcurrentHashMap;

public class CaptchaUtil {
	
	public static ConcurrentHashMap<String, String> captchaMap = new ConcurrentHashMap<>();

}
