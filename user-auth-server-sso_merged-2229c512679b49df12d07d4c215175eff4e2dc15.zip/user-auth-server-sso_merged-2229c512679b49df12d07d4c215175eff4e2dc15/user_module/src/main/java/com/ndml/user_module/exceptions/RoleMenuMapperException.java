package com.ndml.user_module.exceptions;

public class RoleMenuMapperException extends RuntimeException{
	
	public RoleMenuMapperException() {
		// TODO Auto-generated constructor stub
	}
	
	public RoleMenuMapperException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
