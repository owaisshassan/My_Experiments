package com.ndml.user_module.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ndml.user_module.model.EndPointsMaster;

public interface EndPointsRepository extends JpaRepository<EndPointsMaster, Long>{

	
	@Query(value = "select * from end_points_master e where e.ep_name = ?", nativeQuery = true)
	public EndPointsMaster findByEndPointsMasterName(String epName);
}
