package com.ndml.user_module.services.impl;

import java.util.Date;
import java.util.Optional;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ndml.user_module.exceptions.DPMasterException;
import com.ndml.user_module.model.DPMaster;
import com.ndml.user_module.repositories.DPMasterRepository;
import com.ndml.user_module.request.DPMasterRegisterRequest;
import com.ndml.user_module.services.DPMasterService;

@Service
public class DPMasterServiceImpl implements DPMasterService {

	Logger log = Logger.getLogger(DPMasterServiceImpl.class.getName());

	@Autowired
	private DPMasterRepository dpMasterRepo;

	@Override
	public DPMaster addNewDPMaster(DPMasterRegisterRequest request) throws DPMasterException {
		// TODO Auto-generated method stub
		log.info("DPName from Request : " + request.getDPName());
		String upperCaseDpName = request.getDPName().toUpperCase();

		DPMaster opt = dpMasterRepo.findByDPName(upperCaseDpName);

		if (opt != null)
			throw new DPMasterException("Sorry! This DPMaster already Exists!");

		DPMaster dpMaster = new DPMaster();
//		dpMaster.setEndpointsList(request.getEplist());
		dpMaster.setDPName(upperCaseDpName);
		dpMaster.setDPAddress(request.getDPAddress());
		dpMaster.setEnckey(request.getEnckey());
		dpMaster.setCrtdDt(new Date());

		dpMasterRepo.save(dpMaster);

		return dpMaster;
	}

}
