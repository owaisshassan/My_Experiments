package com.ndml.user_module.controllers;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.cache.annotation.EnableCaching;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ndml.user_module.model.DPMaster;
import com.ndml.user_module.request.DPMasterRegisterRequest;
import com.ndml.user_module.services.DPMasterService;

@CrossOrigin(origins = "*", maxAge = 3600)
//@RestController
@RequestMapping("/dp")
public class DPMasterController {
	
	
	@Autowired
	private DPMasterService dpService;
	
	
//  localhost:8083/dp/register
	@PostMapping("/register")
	public ResponseEntity<DPMaster> registerNewApplicationHandler(@RequestBody DPMasterRegisterRequest request){
		System.out.println("INSIDE REGISTER API OF DPCONTROLLER...");
		
		System.out.println(request.getDPName());
	
		DPMaster registered =  dpService.addNewDPMaster(request);
		
		return new ResponseEntity<DPMaster>(registered,HttpStatus.OK);
	}

}
