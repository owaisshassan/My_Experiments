package com.ndml.user_module.request;

import java.util.Date;
import java.util.List;

public class RoleMenuMapperRequest {

	private long roleId;
	private List<Long> menulist;
	private long applicationId;

	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public List<Long> getMenulist() {
		return menulist;
	}

	public void setMenulist(List<Long> menulist) {
		this.menulist = menulist;
	}

	public long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}

}
