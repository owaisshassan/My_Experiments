package com.ndml.user_module.exceptions;

import java.time.LocalDateTime;

public class ErrorDetails {

	private String message;
	private LocalDateTime timeStamp;
	private String description;

	public ErrorDetails() {
		// TODO Auto-generated constructor stub
	}

	public ErrorDetails(String message, LocalDateTime timeStamp, String description) {
		super();
		this.message = message;
		this.timeStamp = timeStamp;
		this.description = description;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public LocalDateTime getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(LocalDateTime timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "ErrorDetails [message=" + message + ", timeStamp=" + timeStamp + ", description=" + description + "]";
	}

}
