package com.ndml.user_module.jwt;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import javax.crypto.SecretKey;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.ndml.user_module.configuration.SecurityConstants;
import com.ndml.user_module.exceptions.LoginException;
import com.ndml.user_module.exceptions.NotFoundException;
import com.ndml.user_module.utility.CustomAuthenticationProvider;
import com.ndml.user_module.utility.CustomJwtSecretKeyPair;
import com.ndml.user_module.utility.EncryptDecrypt;
import com.ndml.user_module.utility.JwtCacheUtilWithEncryptKey;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtTokenValidatorFilter extends OncePerRequestFilter {

	Logger log = Logger.getLogger(JwtTokenValidatorFilter.class.getName());

	@Autowired
	CustomAuthenticationProvider customAuthProvider;
	
	private long refreshExpirationDateInMs;

	@Value("${ndml.jwt.refreshExpirationDateInMs}")
	public void setRefreshExpirationDateInMs(long refreshExpirationDateInMs) {
		this.refreshExpirationDateInMs = refreshExpirationDateInMs;
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException, ExpiredJwtException {

		// JWT --- > Authorization : Bearer Token
		// JWT --- > HEADER : VALUE
		log.info("Consoling JWT inside jwtValidatorClass :->  ");

		log.info("HTTP REMOTE USER INSIDE JWTVALID.....");
		String remoteUser = request.getRemoteUser();
		log.info(remoteUser);

		log.info("HTTP REQUEST  INSIDE JWTVALID.....");
		String reqURI = request.getRequestURI();
		log.info(reqURI);

		String encryptedJWTfromRequestHeader = request.getHeader(SecurityConstants.JWT_HEADER);
		log.info("encryptedJWTfromRequestHeader with Bearer : " + encryptedJWTfromRequestHeader);

		encryptedJWTfromRequestHeader = encryptedJWTfromRequestHeader.substring(7);
		log.info("encryptedJWTfromRequestHeader without Bearer : " + encryptedJWTfromRequestHeader);

		String jwt = "";
		// jwt = EncryptDecrypt.decryptData(decKey, encryptedJWTfromRequestHeader);

		// getting decKey from 'usernameJwtMapper' for decryption :
		// String jwt = JwtExtractorUtil.extractUserNamefromUserNameJwtKeyPair(request)
		Map<String, Map<CustomJwtSecretKeyPair, Date>> usernameJwtMapper = JwtCacheUtilWithEncryptKey
				.getUserNameJwtMapperWithKey();

		
		String emailFromDecryption = "";
		
		CustomJwtSecretKeyPair tempPair = new CustomJwtSecretKeyPair();

		for (String keys : usernameJwtMapper.keySet()) {
			Map<CustomJwtSecretKeyPair, Date> mapp = usernameJwtMapper.get(keys);
			for (CustomJwtSecretKeyPair pair : mapp.keySet()) {
				System.out.println("token match :");
				System.out.println(pair.getTokenKey());
				System.out.println(encryptedJWTfromRequestHeader);
				if (pair.getTokenKey().equals(encryptedJWTfromRequestHeader)) {
					log.info("FOUND!");
					System.out.println("USER : "+keys);
					tempPair.setSecretKeyForToken(pair.getSecretKeyForToken());
					tempPair.setTokenKey(pair.getTokenKey());
					String decryptedToken = EncryptDecrypt.decryptData(pair.getSecretKeyForToken(), encryptedJWTfromRequestHeader);
					emailFromDecryption = decryptedToken.substring(0,decryptedToken.indexOf(" ")).trim();
					System.out.println("emailFromDecryption : "+emailFromDecryption);
					if(emailFromDecryption.equals(keys)) {
						jwt = EncryptDecrypt.decryptData(pair.getSecretKeyForToken(), encryptedJWTfromRequestHeader)
									.substring(emailFromDecryption.length()+1).trim();
					}else {
						throw new NotFoundException("Not Authorized!");
					}
				}
			}
		}
		log.info("decryptedJWT : " + jwt);

		if (jwt == "")
			throw new LoginException("Kindly Login First!");

		SecretKey key = Keys.hmacShaKeyFor(SecurityConstants.JWT_KEY.getBytes());

		if (request.getRequestURI().contains("/refreshtoken")) {
			try {
				Claims claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(jwt).getBody();

				allowForRefreshToken(claims, request);

			} catch (ExpiredJwtException ex) {
				log.info("Refreshing 'Expired Session (Expired token)' inside JWTVALIDATION CLASS.......");
				
				allowForRefreshToken(ex.getClaims(), request);

//				request.setAttribute("exception", ex);
			} catch (Exception e) {
				throw new BadCredentialsException("Invalid Token received!");
			}
		}

		else if (jwt != null && jwt != "") {
			log.info("inside 'if' block of JwtTokenValidatorFilter");
			try {
				log.info("inside try block of JwtTokenValidatorFilter..");

				log.info("JWT after extracting Bearer in jwtvalidator : " + "\n" + jwt);

//				SecretKey key = Keys.hmacShaKeyFor(SecurityConstants.JWT_KEY.getBytes());

				Claims claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(jwt).getBody();

				String username = String.valueOf(claims.get("username"));

				log.info("USERNAME after extracting Bearer : " + username);

				// DECODING JWT to get token Expiry & Username :
				DecodedJWT decodedJWT = JWT.decode(jwt);
				String userName = decodedJWT.getClaim("username").toString();
				Date date = decodedJWT.getExpiresAt();
				log.info("username from JWT : " + userName);
				log.info("tkn expiresAt : " + date);
				log.info("CLAIMS : " + decodedJWT.getClaims());

				// it returns the comma separated authorities :
				String authorities = (String) claims.get("authorities");

				List<GrantedAuthority> auths = AuthorityUtils.commaSeparatedStringToAuthorityList(authorities);

				Authentication auth = new UsernamePasswordAuthenticationToken(username, null, auths);

				// Authentication customAuthentication = customAuthProvider.authenticate(auth);

				SecurityContextHolder.getContext().setAuthentication(auth);

				log.info("SecurityContextHolder auth set up DONE inside JwtTokenValidatorFilter..");

			} catch (ExpiredJwtException ex) {
				// TODO: handle exception
				log.info("INSIDE 'ExpiredJwtException' OF JWTVALIDATION CLASS.......");

//				String isRefreshToken = request.getHeader("isRefreshToken");

//				log.info("isRefreshToken from request HEADER: "+isRefreshToken);

				String requestURL = request.getRequestURL().toString();
				log.info("requestURL from request : " + requestURL);
				log.info("ex.getClaims() before if()  : " + ex.getClaims());


				request.setAttribute("exception", ex);
			} catch (Exception e) {
				throw new BadCredentialsException("Invalid Token received!");
			}
		} else
			log.warning("JWT is null..");

		filterChain.doFilter(request, response);
		log.info("doFilter done...");

	}



	protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
		if (request.getServletPath().contains("register"))
			return true;
		if (request.getServletPath().contains("/auth/get/otp"))
			return true;
		if (request.getServletPath().contains("/auth/validate/otp"))
			return true;
		if (request.getServletPath().contains("/app/user"))
			return true;
		if (request.getServletPath().contains("/user/forgot-password"))
			return true;
		if (request.getServletPath().contains("/user/reset-password"))
			return true;
		if (request.getServletPath().contains("api-docs"))
			return true;
		if (request.getServletPath().contains("signup"))
			return true;
		if (request.getServletPath().contains("/swagger"))
			return true;
		if (request.getServletPath().contains("checktoken"))
			return true;
		if (request.getServletPath().contains("/user/forgotpass"))
			return true;
		if (request.getServletPath().equals("/user/resetp"))
			return true;
		if (request.getServletPath().equals("/user/pwdsalt"))
			return true;
		if (request.getServletPath().equals("/auth/user/getallendpoints"))
			return true;
		if (request.getServletPath().equals("/test/auth"))
			return true;
		if (request.getServletPath().equals("/getcap"))
			return true;
		if (request.getServletPath().equals("/auth/user/isActive"))
			return true;
		return request.getServletPath().equals("/auth/user/login"); 
	}

	// ***************************

	private void allowForRefreshToken(Claims claims, HttpServletRequest request) {
		log.info("inside 'allowForRefreshToken' method...");

//		String authorities = (String) ex.getClaims().get("authorities");
		String authorities = (String) claims.get("authorities");
		List<GrantedAuthority> auths = AuthorityUtils.commaSeparatedStringToAuthorityList(authorities);

//		String username = String.valueOf(ex.getClaims().get("username"));

		String username = String.valueOf(claims.get("username"));

		log.info("auths : " + auths);
		log.info("username : " + username);

		String trimmedUserName = "";
		for (int i = 0; i < username.length(); i++) {
			if (username.charAt(i) == '"') {
				continue;
			} else {
				trimmedUserName += username.charAt(i);
			}
		}

		log.info("trimmedUserName inside allowForRefreshToken: " + trimmedUserName);

		Authentication usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(trimmedUserName,
				null, auths);
		// After setting the Authentication in the context, we specify
		// that the current user is authenticated. So it passes the
		// Spring Security Configurations successfully.
		SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
		log.info("usernamePasswordAuthenticationToken : " + usernamePasswordAuthenticationToken.getName());
//		log.info("issuer : " + ex.getClaims().getIssuer());
		// Setting the claims so that in controller we will be using it to create
		// new JWT
		request.setAttribute("claims", claims);
		log.info(" 'allowForRefreshToken' method  ENDS...");
	}
	
	public String doGenerateRefreshToken(Map<String, Object> claims) {
		String subject = (String) claims.get("subject");
		SecretKey secret = Keys.hmacShaKeyFor(SecurityConstants.JWT_KEY.getBytes());

		return Jwts.builder().setIssuer("ndml").setClaims(claims).setSubject(subject).setIssuedAt(new Date())
				.setExpiration(new Date(new Date().getTime() + refreshExpirationDateInMs)).signWith(secret).compact();

	}

}
