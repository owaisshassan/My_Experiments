package com.ndml.user_module.utility;

import java.util.Date;
import java.util.Map;

import javax.crypto.SecretKey;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ndml.user_module.configuration.SecurityConstants;
import com.ndml.user_module.exceptions.LogoutException;
import com.ndml.user_module.model.UserDetails;
import com.ndml.user_module.repositories.DPMasterRepository;
import com.ndml.user_module.repositories.UserRepository;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Component
public class IsLoggedOutUtil {
//
//	@Value("${ndml.app.jwtSecret}")
//	private static String jwtSecret;

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private DPMasterRepository dpRepo;

//	@Autowired
//	public IsLoggedOutUtil(UserRepository userRepo, DPMasterRepository dpRepo) {
//		super();
//		this.userRepo = userRepo;
//		this.dpRepo = dpRepo;
//	}
//	
//	public IsLoggedOutUtil() {
//		// TODO Auto-generated constructor stub
//	}
//
//	// Custom method for checking if the user is logged out ? / to check Session
//	// expiry :
//
//	public static boolean isLoggedOut(String email, HttpServletRequest http) throws Exception {
//		
//
//		boolean loggedOutBool = false;
//
//		String jwt = http.getHeader(SecurityConstants.JWT_HEADER);
//
//		System.out.println("JWT in 'isLoggedOut' = " + jwt);
//
//		if (jwt == null)
//			throw new Exception("Please provide token!");
//
//		try {
//			// extracting the word 'Bearer':
//			jwt = jwt.substring(7);
//
//			System.out.println("JWT without bearer in 'isLoggedOut' = " + jwt);
//			// SecretKey key = Keys.hmacShaKeyFor(SecurityConstants.JWT_KEY.getBytes());
//			// SecretKey key = Keys.hmacShaKeyFor(Decoders.BASE64.decode(jwtSecret));
//
//			// Claims claims =
//			// Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(jwt).getBody();
//			Claims claims = (Claims) http.getAttribute("claims");
//			System.out.println("Claims in isLoggedOut :" + claims);
//
//			String username = String.valueOf(claims.get("username"));
//
//			System.out
//					.println("Username + length from claims in 'isLoggedOut' = " + username + " " + username.length());
//			System.out.println("Request Email + length : " + email + " " + email.length());
//
//			if (email.equals(username)) {
//				System.out.println("username & Email matches!!!!!");
//
//				Map<String, Map<String, Date>> mapper = JwtCacheUtil.getUserNameJwtMapper();
//				if (mapper.containsKey(email)) {
//					System.out.println("Email is present in mapper -- ('isLoggedOut')");
//					Map<String, Date> jwtDateMapper = mapper.get(email);
//					if (jwtDateMapper.containsKey(jwt)) {
//						System.out.println("USER_JWT mapper CACHE Still Present, Not logged Out!");
//					} else
//						loggedOutBool = true;
//				} else
//					loggedOutBool = true;
//
//			} else
//				throw new Exception("Provided Email doesn't match!");
//
//		} catch (Exception e) {
//			throw new BadCredentialsException("Invalid Token received!");
//		}
//
//		return loggedOutBool;
//
//	}
//
//	// Custom method for URL-controller to check if the user is logged out ? / to
//	// check Session expiry :
//
//	@Cacheable(value = "logoutstatus", key = "#email")
//	public static boolean logoutStatus(String email, HttpServletRequest http) throws Exception {
//
//		boolean loggedOutBool = false;
//
//		String jwt = http.getHeader(SecurityConstants.JWT_HEADER);
//
//		System.out.println("JWT in 'isLoggedOut' = " + jwt);
//
//		if (jwt == null)
//			throw new Exception("Please provide token!");
//
//		try {
//			// extracting the word 'Bearer':
//			jwt = jwt.substring(7);
//
//			System.out.println("JWT without bearer in 'isLoggedOut' = " + jwt);
//			SecretKey key = Keys.hmacShaKeyFor(SecurityConstants.JWT_KEY.getBytes());
//			// SecretKey key = Keys.hmacShaKeyFor(Decoders.BASE64.decode(jwtSecret));
//
//			Claims claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(jwt).getBody();
//			// Claims claims = (Claims) http.getAttribute("claims");
//			System.out.println("Claims in isLoggedOut :" + claims);
//
//			String username = String.valueOf(claims.get("username"));
//
//			System.out
//					.println("Username + length from claims in 'isLoggedOut' = " + username + " " + username.length());
//			System.out.println("Request Email + length : " + email + " " + email.length());
//
//			if (email.equals(username)) {
//				System.out.println("username & Email matches!!!!!");
//
//				Map<String, Map<String, Date>> mapper = JwtCacheUtil.getUserNameJwtMapper();
//				if (mapper.containsKey(email)) {
//					System.out.println("Email is present in mapper -- ('isLoggedOut')");
//					Map<String, Date> jwtDateMapper = mapper.get(email);
//					
//					//removing expired JWT's : 
//					for(String token : jwtDateMapper.keySet()) {
//						if(jwtDateMapper.get(token).after(new Date())) {
//							jwtDateMapper.remove(token);
//						}
//					}
//					
//					//checking logout status : 
//					if (jwtDateMapper.containsKey(jwt)) {
//						System.out.println("USER_JWT mapper CACHE Still Present, Not logged Out!");
//					} else
//						loggedOutBool = true;
//				} else
//					loggedOutBool = true;
//
//			} else
//				throw new Exception("Provided Email doesn't match!");
//
//		} catch (Exception e) {
//			throw new BadCredentialsException("Invalid Token received!");
//		}
//
//		return loggedOutBool;
//
//	}
//	

	// Custom method for URL-controller to check if the user is logged out ? / to
	// check Session expiry :

	// @Cacheable(value = "logoutstatuswithkey", key = "#email")
	public boolean logoutStatusWithSecretEncKey(String email, HttpServletRequest http) throws Exception {

		boolean loggedOutBool = false;

		String encJwtFromHeader = http.getHeader(SecurityConstants.JWT_HEADER);

		System.out.println("encJwtFromHeader in 'isLoggedOut' = " + encJwtFromHeader);
//			
//			String encKeyFromHeader = http.getHeader("enckey");

//			if (encJwtFromHeader == null)
//				throw new Exception("Please provide token!");
//			
//			if(encKeyFromHeader == null)
//				throw new Exception("Please provide encKey!");

		// getting dp- dec-key from user email :
		UserDetails ud = userRepo.findByUseremailId(email);
		System.out.println(ud);
		String decKey = dpRepo.findByDpID(ud.getDpID()).get().getEnckey();

		try {
			// extracting the word 'Bearer':

			encJwtFromHeader = encJwtFromHeader.substring(7);

			System.out.println("encJwtFromHeader without bearer in 'isLoggedOut' = " + encJwtFromHeader);

			// String jwt = EncryptDecrypt.decrypt(encJwtFromHeader, decKey);

			String jwt = EncryptDecrypt.decryptData(decKey, encJwtFromHeader);
			System.out.println("DEC-KEY inside isLoggedOut : ");
			System.out.println(decKey);
			System.out.println("DEC-JWT inside isLoggedOut : ");
			System.out.println(jwt);
			SecretKey key = Keys.hmacShaKeyFor(SecurityConstants.JWT_KEY.getBytes());
			// SecretKey key = Keys.hmacShaKeyFor(Decoders.BASE64.decode(jwtSecret));

			Claims claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(jwt).getBody();
			// Claims claims = (Claims) http.getAttribute("claims");
			System.out.println("Claims in isLoggedOut :" + claims);

			String username = String.valueOf(claims.get("username"));

			System.out
					.println("Username + length from claims in 'isLoggedOut' = " + username + " " + username.length());
			System.out.println("Request Email + length : " + email + " " + email.length());

			if (email.equals(username)) {
				System.out.println("username from Claims & Email from request matches!!!!!");

				Map<String, Map<CustomJwtSecretKeyPair, Date>> mapper = JwtCacheUtilWithEncryptKey
						.getUserNameJwtMapperWithKey();

				if (mapper.containsKey(email)) {
					System.out.println("Email is present in mapper -- ('isLoggedOut')");
					Map<CustomJwtSecretKeyPair, Date> jwtEncKeyDateMapper = mapper.get(email);

					// removing expired JWT's :
//						for(CustomJwtSecretKeyPair k: jwtEncKeyDateMapper.keySet()) {
//							if(jwtEncKeyDateMapper.get(k).before(new Date())) {
//								jwtEncKeyDateMapper.remove(k);
//							}
//						}

					CustomJwtSecretKeyPair pair = new CustomJwtSecretKeyPair();
					pair.setSecretKeyForToken(decKey);
					pair.setTokenKey(encJwtFromHeader);

					System.out.println(pair.getTokenKey());
					System.out.println(pair.getSecretKeyForToken());

					System.out.println("CONTAINS OBJ IN LOGGEDOUT UTIL : " + jwtEncKeyDateMapper.containsKey(pair));
					// checking logout status :
					if (jwtEncKeyDateMapper.containsKey(pair)) {
						System.out.println("USER_JWT mapper CACHE Still Present, Not logged Out!");
					} else
						loggedOutBool = true;
				} else
					loggedOutBool = true;

			} else
				throw new Exception("Provided Email doesn't match!");

		} catch (Exception e) {
			throw new LogoutException("Invalid Token received!");
		}

		return loggedOutBool;

	}

}
