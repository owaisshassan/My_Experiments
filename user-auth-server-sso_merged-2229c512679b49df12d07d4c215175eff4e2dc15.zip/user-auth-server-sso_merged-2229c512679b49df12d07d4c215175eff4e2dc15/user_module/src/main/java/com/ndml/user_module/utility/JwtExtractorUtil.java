package com.ndml.user_module.utility;

import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.ndml.user_module.configuration.SecurityConstants;
import com.ndml.user_module.exceptions.NotFoundException;

public class JwtExtractorUtil {

	public static String jwt;

	public static String tokenDecryptionHelper(HttpServletRequest request) {
		String encryptedJWTfromRequestHeader = request.getHeader(SecurityConstants.JWT_HEADER);
		System.out.println("encryptedJWTfromRequestHeader with Bearer : " + encryptedJWTfromRequestHeader);

		encryptedJWTfromRequestHeader = encryptedJWTfromRequestHeader.substring(7);
		System.out.println("encryptedJWTfromRequestHeader without Bearer : " + encryptedJWTfromRequestHeader);

		Map<String, Map<CustomJwtSecretKeyPair, Date>> usernameJwtMapper = JwtCacheUtilWithEncryptKey
				.getUserNameJwtMapperWithKey();

//		for (String keys : usernameJwtMapper.keySet()) {
//			Map<CustomJwtSecretKeyPair, Date> mapp = usernameJwtMapper.get(keys);
//			for (CustomJwtSecretKeyPair pair : mapp.keySet()) {
//				if (pair.getTokenKey().equals(encryptedJWTfromRequestHeader)) {
//					System.out.println("extractUserNamefromUserNameJwtKeyPair : " + keys);
////					IsLoggedOutUtil logoutCheck = new IsLoggedOutUtil();
////					try {
////						if(logoutCheck.logoutStatusWithSecretEncKey(pair.getSecretKeyForToken(), request)) {
////							throw new Exception("Please Login First!");
////						}
////					} catch (Exception e) {
////						// TODO Auto-generated catch block
////						e.printStackTrace();
////					}
//					jwt = EncryptDecrypt.decryptData(pair.getSecretKeyForToken(), encryptedJWTfromRequestHeader);
//				}
//			}
//		}
		
		String emailFromDecryption = "";
		
		CustomJwtSecretKeyPair tempPair = new CustomJwtSecretKeyPair();

		for (String keys : usernameJwtMapper.keySet()) {
			Map<CustomJwtSecretKeyPair, Date> mapp = usernameJwtMapper.get(keys);
			for (CustomJwtSecretKeyPair pair : mapp.keySet()) {
				System.out.println("token match :");
				System.out.println(pair.getTokenKey());
				System.out.println(encryptedJWTfromRequestHeader);
				if (pair.getTokenKey().equals(encryptedJWTfromRequestHeader)) {
//					log.info("FOUND!");
					System.out.println("USER : "+keys);
					tempPair.setSecretKeyForToken(pair.getSecretKeyForToken());
					tempPair.setTokenKey(pair.getTokenKey());
					String decryptedToken = EncryptDecrypt.decryptData(pair.getSecretKeyForToken(), encryptedJWTfromRequestHeader);
					emailFromDecryption = decryptedToken.substring(0,decryptedToken.indexOf(" ")).trim();
					System.out.println("emailFromDecryption : "+emailFromDecryption);
					if(emailFromDecryption.equals(keys)) {
						jwt = EncryptDecrypt.decryptData(pair.getSecretKeyForToken(), encryptedJWTfromRequestHeader)
									.substring(emailFromDecryption.length()+1).trim();
					}else {
						throw new NotFoundException("Not Authorized!");
					}
				}
			}
		}

		return jwt;
	}

	public static String encKeyExtractor(HttpServletRequest request) {
		String encryptedJWTfromRequestHeader = request.getHeader(SecurityConstants.JWT_HEADER);
		System.out.println("encryptedJWTfromRequestHeader with Bearer : " + encryptedJWTfromRequestHeader);

		encryptedJWTfromRequestHeader = encryptedJWTfromRequestHeader.substring(7);
		System.out.println("encryptedJWTfromRequestHeader without Bearer : " + encryptedJWTfromRequestHeader);

		Map<String, Map<CustomJwtSecretKeyPair, Date>> usernameJwtMapper = JwtCacheUtilWithEncryptKey
				.getUserNameJwtMapperWithKey();

		for (String keys : usernameJwtMapper.keySet()) {
			Map<CustomJwtSecretKeyPair, Date> mapp = usernameJwtMapper.get(keys);
			for (CustomJwtSecretKeyPair pair : mapp.keySet()) {
				if (pair.getTokenKey().equals(encryptedJWTfromRequestHeader)) {
					System.out.println("extractUserNamefromUserNameJwtKeyPair : " + keys);
//					IsLoggedOutUtil logoutCheck = new IsLoggedOutUtil();
//					try {
//						if(logoutCheck.logoutStatusWithSecretEncKey(pair.getSecretKeyForToken(), request)) {
//							throw new Exception("Please Login First!");
//						}
//					} catch (Exception e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
					jwt = EncryptDecrypt.decryptData(pair.getSecretKeyForToken(), encryptedJWTfromRequestHeader);
				}
			}
		}

		return jwt;
	}

}
