package com.ndml.user_module.configuration;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;

import com.ndml.user_module.jwt.JwtTokenValidatorFilter;
import com.ndml.user_module.model.EndPointsMaster;
import com.ndml.user_module.model.RoleMenuMapper;
import com.ndml.user_module.repositories.EndPointsRepository;
import com.ndml.user_module.repositories.RoleMenuMapperRepository;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Value("${ndml.user.maxsessions}")
	private int maxAllowedSessions;

	@Value("${ndml.user.maxSessionsPreventsLogin}")
	private boolean isPreventsLogin;

	@Autowired
	private RoleMenuMapperRepository mapper;

	@Autowired
	private EndPointsRepository epRepo;

	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
		return authConfig.getAuthenticationManager();
	}

	@Override
	public void configure(HttpSecurity http) throws Exception {

		System.out.println("HTTP in SecurityFilterChain : " + http.toString());

		// DAC EP's:
		
		RoleMenuMapper rm = mapper.findByRoleId(3);
		System.out.println(rm);
		List<String> maker = rm.getEpList();
		String[] makerEp = new String[maker.size()];
		for (int i = 0; i < maker.size(); i++) {
			System.out.println("inside for loop #1 : maker");
			long id = Long.parseLong(maker.get(i));
			System.out.println("id : " + id);
			Optional<EndPointsMaster> epm = epRepo.findById(id);
			makerEp[i] = epm.get().getEpName();
		}
		System.out.println(Arrays.toString(makerEp));
		
		RoleMenuMapper rm1 = mapper.findByRoleId(2);
		System.out.println(rm1);
		List<String> checker = rm1.getEpList();
		String[] checkerEp = new String[checker.size()];
		for (int i = 0; i < checker.size(); i++) {
			System.out.println("inside for loop #2 : checker");
			long id = Long.parseLong(checker.get(i));
			System.out.println("id : " + id);
			Optional<EndPointsMaster> epm = epRepo.findById(id);
			checkerEp[i] = epm.get().getEpName();
//			System.out.println(checkerEp[i]);
		}
		System.out.println(Arrays.toString(checkerEp));

		// ===============================================================//

		http
				.csrf().disable().authorizeRequests()
//				.antMatchers(HttpMethod.POST,".*/register\\?{0,1}.*").permitAll()
				.antMatchers("/swagger-ui/**", "/api-docs/**").permitAll()
				.antMatchers("/auth/user/signup", "/auth/checktoken", "/auth/user/login", "/app/user/getcap",
						"/app/user/verifyCaptcha","/auth/user/getallendpoints","/auth/get/otp","/auth/validate/otp")
				.permitAll().antMatchers("/user/**").permitAll().antMatchers("/role/**","/auth/user/isActive").permitAll()
				.antMatchers(HttpMethod.POST, checkerEp).hasAuthority("DAC_CHECKER")
				.antMatchers(HttpMethod.POST, makerEp).hasAuthority("DAC_MAKER")
				

				.anyRequest().authenticated().and().cors().configurationSource(new CorsConfigurationSource() {
					@Override
					public CorsConfiguration getCorsConfiguration(HttpServletRequest request) {
						CorsConfiguration cfg = new CorsConfiguration();

						cfg.setAllowedOrigins(Collections.singletonList("*")); // enabling on all end points.
						cfg.setAllowedOrigins(Arrays.asList("*"));
//						cfg.setAllowedOrigins(Arrays.asList("http://localhost:4200", "http://localhost:4401","http://172.19.83.88:4200", "http://172.19.83.88:4401"));
						// "http://localhost:8083/api-docs/swagger-config"
						cfg.setAllowedMethods(Arrays.asList("POST", "GET", "PUT", "DELETE"));
						cfg.setAllowedMethods(Collections.singletonList("*")); // allowing all methods.
						cfg.setAllowCredentials(true);
						cfg.setAllowedHeaders(Collections.singletonList("*"));
						cfg.setExposedHeaders(Arrays.asList("Authorization"));
						// cfg.setMaxAge(3600L);

						return cfg;
					}
				}).and()

				// .authenticationProvider(customeAuthProvider)
				// .addFilterAfter(new JwtTokenGeneratorFilter(),
				// UsernamePasswordAuthenticationFilter.class)
				.addFilterBefore(new JwtTokenValidatorFilter(), UsernamePasswordAuthenticationFilter.class).formLogin()
				.disable()
				// .exceptionHandling(exception ->
				// exception.authenticationEntryPoint(unauthorizedHandler))
				.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
				.maximumSessions(maxAllowedSessions) // -1 : unlimited sessions
				.expiredUrl("/auth/user/logout").maxSessionsPreventsLogin(isPreventsLogin);

		System.out.println("maxAllowedSessions : " + maxAllowedSessions);
		System.out.println("isPreventsLogin ? :" + isPreventsLogin);
		System.out.println("SecurityFilterChain END..");

//		http.build();
	}

}
