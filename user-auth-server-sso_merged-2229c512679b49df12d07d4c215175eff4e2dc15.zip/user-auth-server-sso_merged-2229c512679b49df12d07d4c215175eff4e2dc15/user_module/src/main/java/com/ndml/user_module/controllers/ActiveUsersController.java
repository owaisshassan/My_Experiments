package com.ndml.user_module.controllers;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ndml.user_module.request.ActiveUserRequest;
import com.ndml.user_module.response.ActiveUserResponse;
import com.ndml.user_module.services.ActiveUsersService;

@CrossOrigin(origins = "*", maxAge = 3600, allowedHeaders = "*")
@RestController
@RequestMapping("/auth")
public class ActiveUsersController {
	
	Logger log = Logger.getLogger(ActiveUsersController.class.getName());
	
	@Autowired
	private ActiveUsersService activeUsersService;
	
	@PostMapping("/user/isActive")
	public ResponseEntity<?> isUserSessionActive(@RequestBody ActiveUserRequest request){
		log.info("INSIDE isUserSessionActive-- ActiveUsersController.. ");
		
		
//		String dt = convertToLocalDateTimeViaSqlTimestamp(request.getExpiry()) + "";
//		String d = dt.replace("T", " ");
//		log.info(d);
//		log.info("''''''''''''''''''''''''''''''''''''''''''''''");
		
		ActiveUserResponse isUserSessionActive = activeUsersService.isUserSessionActive(request.getUsername(), request.getToken(), 
							request.getDcryptKey());
		
		log.info("RESPONSE : "+isUserSessionActive);
		
		return new ResponseEntity<ActiveUserResponse>(isUserSessionActive, HttpStatus.OK);
	}
	
	// Date conversion-methods Start:: : : :
		LocalDateTime convertToLocalDateTimeViaSqlTimestamp(Date dateToConvert) {
			return new java.sql.Timestamp(dateToConvert.getTime()).toLocalDateTime();
		}

}
