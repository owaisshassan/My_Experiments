package com.ndml.user_module.model;

import java.time.LocalDateTime;



public class AppRoleModel {
	

	private long roleId;
	private String roleName;
	private String roleDescription;
	private LocalDateTime crtdDt;
	private LocalDateTime updtDt;

	public AppRoleModel() {
		// TODO Auto-generated constructor stub
	}

	public AppRoleModel(long roleId, String roleName, String roleDescription, LocalDateTime crtdDt,
			LocalDateTime updtDt) {
		super();
		this.roleId = roleId;
		this.roleName = roleName;
		this.roleDescription = roleDescription;
		this.crtdDt = crtdDt;
		this.updtDt = updtDt;
	}

	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleDescription() {
		return roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	public LocalDateTime getCrtdDt() {
		return crtdDt;
	}

	public void setCrtdDt(LocalDateTime crtdDt) {
		this.crtdDt = crtdDt;
	}

	public LocalDateTime getUpdtDt() {
		return updtDt;
	}

	public void setUpdtDt(LocalDateTime updtDt) {
		this.updtDt = updtDt;
	}

	@Override
	public String toString() {
		return "RoleMaster [roleId=" + roleId + ", roleName=" + roleName + ", roleDescription=" + roleDescription
				+ ", crtdDt=" + crtdDt + ", updtDt=" + updtDt + "]";
	}

}
