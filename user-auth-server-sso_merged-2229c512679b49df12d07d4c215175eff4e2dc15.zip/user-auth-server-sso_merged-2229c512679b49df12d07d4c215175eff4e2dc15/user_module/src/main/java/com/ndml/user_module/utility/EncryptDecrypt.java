package com.ndml.user_module.utility;

import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.Security;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

//import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EncryptDecrypt {
	static Logger logger = LoggerFactory.getLogger(EncryptDecrypt.class);

	static {
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());

	}

	public static String encryptForPKCS7(String value, String key) {
		try {
			/**** Key Generation code is getAlphaNumericString() method ****/
			// String key = "aesEncryptionKey"; // 128 bit key
			byte[] iv = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };

			IvParameterSpec ivspec = new IvParameterSpec(iv);

			SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");
			Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
			cipher.init(Cipher.ENCRYPT_MODE, skeySpec, ivspec);

			byte[] encrypted = cipher.doFinal(value.getBytes());
			String encryptedvalue = new String(Base64.getEncoder().encode(encrypted));

			return encryptedvalue;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

//	public static String encrypt(String value, String key) {
//		try {
//			/**** Key Generation code is getAlphaNumericString() method ****/
//			// String key = "aesEncryptionKey"; // 128 bit key
//			String initVector = "encryptionIntVec"; // 16 bytes IV
//			IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
//			SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");
//
//			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
//			cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
//
//			byte[] encrypted = cipher.doFinal(value.getBytes());
//			String encryptedvalue = new String(Base64.getEncoder().encode(encrypted));
//
//			return encryptedvalue;
//		} catch (Exception ex) {
//			ex.printStackTrace();
//		}
//		return null;
//	}
//
//	public static String decrypt(String enc, String key) {
//		try {
//			String initVector = "encryptionIntVec";
//			IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
//			SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");
//
//			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
//			cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
//			byte[] original = cipher.doFinal(Base64.getDecoder().decode(enc));
//
//			return new String(original);
//		} catch (Exception ex) {
//			ex.printStackTrace();
//		}
//		return null;
//
//	}
	public static String decryptForPKCS7(String enc, String key) {
		try {
			byte[] iv = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
			IvParameterSpec ivspec = new IvParameterSpec(iv);
			SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7PADDING");

			// Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
			cipher.init(Cipher.DECRYPT_MODE, skeySpec, ivspec);
			byte[] original = cipher.doFinal(Base64.getDecoder().decode(enc));

			return new String(original);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;

	}

	private static String bytes2String(byte[] bytes) {
		StringBuffer stringBuffer = new StringBuffer();
		for (int i = 0; i < bytes.length; i++) {
			stringBuffer.append((char) bytes[i]);
		}
		return stringBuffer.toString();
	}

	static int stringLength = 66;

	public static String getAlphaNumericString(String dpName) {

		// chose a Character random from this String
		String AlphaNumericString = dpName + "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";

		// create StringBuffer size of AlphaNumericString
		StringBuilder sb = new StringBuilder(stringLength);

		for (int i = 0; i < stringLength; i++) {

			// generate a random number between
			// 0 to AlphaNumericString variable length
			int index = (int) (AlphaNumericString.length()); // * Math.random()

			// add Character one by one in end of sb
			sb.append(AlphaNumericString.charAt(index));
		}

		return sb.toString();
	}

	public static String matchHMacPdfHeader(String clientSecret, byte[] dataToMatch) {

		String dataHmac = "";

		try {
			Key sk = new SecretKeySpec(clientSecret.getBytes(), "HmacSHA256");
			Mac mac = Mac.getInstance(sk.getAlgorithm());
			mac.init(sk);
			final byte[] hmac = mac.doFinal(dataToMatch);
			dataHmac = new String(Base64.getEncoder().encode(hmac));

		} catch (NoSuchAlgorithmException e) {
			logger.error("matchHMacHeader method NoSuchAlgorithmException exception occured : " + e.getMessage());

		} catch (Exception e) {
			logger.error("matchHMacHeader method general exception occured : " + e.getMessage());

		}

		return dataHmac;
	}

	// *************************************************************************

	// String Key:- PiiAe173g4k6jiDj
	public static String encryptData(String key, String data) throws Exception {
		byte[] iv = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
		IvParameterSpec ivspec = new IvParameterSpec(iv);

		SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF8"), "AES");
		Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec, ivspec);
		byte[] original = Base64.getEncoder().encode(cipher.doFinal(data.getBytes()));
		return new String(original);
	}

//	public static String decryptData(String key, String encData) {
//		byte[] original = null;
//		try {
//			byte[] iv = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
//			IvParameterSpec ivspec = new IvParameterSpec(iv);
//			SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF8"), "AES");
//			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
//			cipher.init(Cipher.DECRYPT_MODE, skeySpec, ivspec);
//			original = cipher.doFinal(Base64.getDecoder().decode(encData.getBytes()));
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		return new String(original).trim();
//	}
	public static String decryptData(String key, String encData) {
		byte[] original = null;
		try {
			byte[] iv = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
			IvParameterSpec ivspec = new IvParameterSpec(iv);
			SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF8"), "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
			cipher.init(Cipher.DECRYPT_MODE, skeySpec, ivspec);
			original = cipher.doFinal(Base64.getDecoder().decode(encData.getBytes()));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new String(original).trim();
	}

}
