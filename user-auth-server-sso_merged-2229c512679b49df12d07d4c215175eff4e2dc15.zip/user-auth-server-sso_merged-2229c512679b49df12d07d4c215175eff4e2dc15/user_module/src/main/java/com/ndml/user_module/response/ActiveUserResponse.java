package com.ndml.user_module.response;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ActiveUserResponse {
	
	
	private boolean isUserSessionActive;

}
