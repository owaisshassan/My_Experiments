package com.ndml.user_module.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "old_passwords_tbl")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OldPasswordsEntity {
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id", unique = true, updatable = false, nullable = false)
	private Integer id;

	
	@Column(name = "user_email",unique = true,nullable = false)
	private String passwordOwnerId;
	
	
	@Column(name = "pswd_01")
	private String encryptedPwrd_01;
	
	@Column(name = "pswd_01_crtd_dt")
	@Convert(converter = LocalDateTimeConverter.class)
	private LocalDateTime pswd_01_createdDate;
	
	@Column(name = "pswd_02")
	private String encryptedPwrd_02;
	
	@Column(name = "pswd_02_crtd_dt")
	@Convert(converter = LocalDateTimeConverter.class)
	private LocalDateTime pswd_02_createdDate;
	
	@Column(name = "pswd_03")
	private String encryptedPwrd_03;

	@Column(name = "pswd_03_crtd_dt")
	@Convert(converter = LocalDateTimeConverter.class)
	private LocalDateTime pswd_03_createdDate;
	

	

}
