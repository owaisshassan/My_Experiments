package com.ndml.user_module.model;

public class DualKey {

	private final String user;
	private final String capQuestion;

	public String getUser() {
		return user;
	}

	public String getCapQuestion() {
		return capQuestion;
	}

	public DualKey(String user, String capQuestion) {
		super();
		this.user = user;
		this.capQuestion = capQuestion;
	}

}
