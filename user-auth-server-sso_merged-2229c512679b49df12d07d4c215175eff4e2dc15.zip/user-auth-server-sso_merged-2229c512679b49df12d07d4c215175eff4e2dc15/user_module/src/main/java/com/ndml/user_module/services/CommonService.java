package com.ndml.user_module.services;

import com.ndml.user_module.model.OTPDetails;

public interface CommonService {

	OTPDetails checkResendOtpCount(String requestType, String mobileNo, String emailId);

}
