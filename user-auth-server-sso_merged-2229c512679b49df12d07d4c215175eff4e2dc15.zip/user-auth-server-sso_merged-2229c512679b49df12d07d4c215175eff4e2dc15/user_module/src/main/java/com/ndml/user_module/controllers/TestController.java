package com.ndml.user_module.controllers;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ndml.user_module.exceptions.DPMasterException;
import com.ndml.user_module.exceptions.EndPointException;
import com.ndml.user_module.exceptions.RoleException;
import com.ndml.user_module.exceptions.UserDetailsException;
import com.ndml.user_module.model.ApplicationMaster;
import com.ndml.user_module.model.DPMaster;
import com.ndml.user_module.model.RoleMaster;
import com.ndml.user_module.model.UserDetails;
import com.ndml.user_module.repositories.ApplicationMasterRepository;
import com.ndml.user_module.repositories.DPMasterRepository;
import com.ndml.user_module.repositories.RoleMasterRepository;
import com.ndml.user_module.repositories.UserRepository;
import com.ndml.user_module.request.DbEpRequest;

@CrossOrigin(origins = "*", maxAge = 3600)
//@RestController
@RequestMapping("/api/test")
public class TestController {
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private DPMasterRepository dpRepo;
	
	@Autowired
	private RoleMasterRepository roleRepo;
	
	@Autowired
	private ApplicationMasterRepository appRepo;

	private String currentUser;

	private Authentication authe;

	public Authentication getAuthe() {
		return authe;
	}

	public void setAuthe(Authentication authe) {
		this.authe = authe;
	}

	public String getCurrentUser() {
		return currentUser;
	}

	public void setCurrentUser(String currentUser) {
		this.currentUser = currentUser;
	}

//	@GetMapping("/all")
//	public String allAccess() {
//		return "Public Content.";
//	}
//
//	@GetMapping("/user")
//	@PreAuthorize("hasRole('user') or hasRole('maker') or hasRole('checker')")
//	public String userAccess() {
//		return "User Content.";
//	}
//
//	@GetMapping("/checker")
//	@PreAuthorize("hasRole('checker')")
//	public String moderatorAccess() {
//		return "Checker Board.";
//	}
//
//	@GetMapping("/maker")
//	@PreAuthorize("hasRole('maker')")
//	public String adminAccess() {
//		return "Maker Board.";
//	}
//	
//	
//	@GetMapping("/auth")
//	public Authentication getAuthobj() {
//		Authentication a = SecurityContextHolder.getContext().getAuthentication();
////		System.out.println(res);
//		return a;
//	}
//
//	@GetMapping("/hello")
//	public String hello() {
//		return "Hello from 8083";
//	}
	
	
	//dummy API for url check in database-> DP schema + applicationMaster :
	@PostMapping("/dbep")
	public ResponseEntity<?> roleBasedEndPointAccessHandler(@RequestBody DbEpRequest req, HttpServletRequest http){
		System.out.println("Inside <<<<<<<<<<<<<roleBasedEndPointAccessHandler>>>>>>>>>>.");
		UserDetails ud = userRepo.findByUseremailId(req.getEmail());
		if(ud == null) throw new UserDetailsException("No User found with this email!");
		Optional<DPMaster> dpOpt = dpRepo.findByDpID(ud.getDpID());
		if(!dpOpt.isPresent()) throw new DPMasterException("No DP found with this ID!");
//		if(! dp.getEndpointsList().contains(http.getRequestURI())) throw new EndPointException("Sorry! This User can't access this URL!");
		
		Optional<RoleMaster> rmOpt = roleRepo.findById(ud.getRoleId());
		if(!rmOpt.isPresent()) throw new RoleException("No Role Found!");
		RoleMaster rm = rmOpt.get();
		int firstIndexOf_ = rm.getRoleName().indexOf('_');
		String appNameFromRoleName = rm.getRoleName().substring(0,firstIndexOf_);
		
		Optional<ApplicationMaster> amOpt = appRepo.findById(ud.getApplicationid());
		ApplicationMaster am  = amOpt.get();
		if(!appNameFromRoleName.equals(am.getApplicationName())) throw new EndPointException("Sorry! This User can't access this URL!");
		
		return new ResponseEntity<String>("WELCOME!",HttpStatus.OK);
	}

}
