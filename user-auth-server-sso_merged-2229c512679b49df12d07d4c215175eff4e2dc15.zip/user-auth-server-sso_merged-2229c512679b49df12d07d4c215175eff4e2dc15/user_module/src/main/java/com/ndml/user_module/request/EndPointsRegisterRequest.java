package com.ndml.user_module.request;

public class EndPointsRegisterRequest {
	
	private String epName;
	
	private long applicationId;

	public String getEpName() {
		return epName;
	}

	public void setEpName(String epName) {
		this.epName = epName;
	}

	public long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}

	
	public EndPointsRegisterRequest() {
		// TODO Auto-generated constructor stub
	}
	public EndPointsRegisterRequest(String epName, long applicationId) {
		super();
		this.epName = epName;
		this.applicationId = applicationId;
	}

	@Override
	public String toString() {
		return "EndPointsRegisterRequest [epName=" + epName + ", applicationId=" + applicationId + "]";
	}
	
	

}
