package com.ndml.user_module.services.impl;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ndml.user_module.exceptions.AlreadyExistsException;
import com.ndml.user_module.exceptions.NotFoundException;
import com.ndml.user_module.model.ApplicationMaster;
import com.ndml.user_module.model.EndPointsMaster;
import com.ndml.user_module.repositories.ApplicationMasterRepository;
import com.ndml.user_module.repositories.EndPointsRepository;
import com.ndml.user_module.request.EndPointsRegisterRequest;
import com.ndml.user_module.services.EndPointsService;

@Service
public class EndPointsServiceImpl implements EndPointsService{
	
	
	@Autowired
	private EndPointsRepository epRepo;
	
	@Autowired
	private ApplicationMasterRepository appRepo;
	

	

	@Override
	public EndPointsMaster registerNewEndPoint(EndPointsRegisterRequest req) {
		// TODO Auto-generated method stub
		
		if((req.getEpName() == "") || (req.getEpName() == null)) 
								throw new NullPointerException("EndPoint name cannot be null");
		
		
		
		Optional<ApplicationMaster> apm =  appRepo.findById(req.getApplicationId());
		if(!apm.isPresent()) throw new NotFoundException("Please provide valid Application Id!");
		String lowerCaseAppName = apm.get().getApplicationName().toLowerCase();
		System.out.println("lowerCaseAppName : "+lowerCaseAppName );
		if(!req.getEpName().contains(lowerCaseAppName)) 
			throw new NotFoundException("This EndPoint can't be added to Application with ApplicationID :"
																					+ apm.get().getApplicationId());
		EndPointsMaster epm = epRepo.findByEndPointsMasterName(req.getEpName());
		if((epm != null) && (epm.getApplicationId() == apm.get().getApplicationId())) 
			throw new AlreadyExistsException("This EndPoint already exists in Application with ApplicationID : "
																		+apm.get().getApplicationId());
		
		
		EndPointsMaster response = new EndPointsMaster();
		response.setEpName(req.getEpName());
		response.setApplicationId(req.getApplicationId());
		response.setActive(true);
		response.setCrtdDt(new Date());
		
		epRepo.save(response);
		
		
		return response;
	}

}
