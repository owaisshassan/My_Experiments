package com.ndml.user_module.utility;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.stream.Collectors;

@Converter
public class DateArrayConverter implements AttributeConverter<Date[], String> {

    private static final String DELIMITER = ",";
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");

    @Override
    public String convertToDatabaseColumn(Date[] attribute) {
        if (attribute == null || attribute.length == 0) {
            return null;
        }
        return Arrays.stream(attribute)
                .map(date -> DATE_FORMAT.format(date))
                .collect(Collectors.joining(DELIMITER));
    }

    @Override
    public Date[] convertToEntityAttribute(String dbData) {
        if (dbData == null || dbData.isEmpty()) {
            return null;
        }
        String[] dateStrings = dbData.split(DELIMITER);
        return Arrays.stream(dateStrings)
                .map(dateString -> {
                    try {
                        return DATE_FORMAT.parse(dateString);
                    } catch (Exception e) {
                        return null;
                    }
                })
                .toArray(Date[]::new);
    }
}