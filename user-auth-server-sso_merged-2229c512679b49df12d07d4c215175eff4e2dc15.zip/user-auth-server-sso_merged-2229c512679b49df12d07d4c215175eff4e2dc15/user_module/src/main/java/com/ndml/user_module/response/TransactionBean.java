package com.ndml.user_module.response;

public class TransactionBean {

	private String txnProcessCode;
	private String txnProcessMessage;
	private String txnResultCode;
	private String txnResultMessage;

	public String getTxnProcessCode() {
		return txnProcessCode;
	}

	public void setTxnProcessCode(String txnProcessCode) {
		this.txnProcessCode = txnProcessCode;
	}

	public String getTxnProcessMessage() {
		return txnProcessMessage;
	}

	public void setTxnProcessMessage(String txnProcessMessage) {
		this.txnProcessMessage = txnProcessMessage;
	}

	public String getTxnResultCode() {
		return txnResultCode;
	}

	public void setTxnResultCode(String txnResultCode) {
		this.txnResultCode = txnResultCode;
	}

	public String getTxnResultMessage() {
		return txnResultMessage;
	}

	public void setTxnResultMessage(String txnResultMessage) {
		this.txnResultMessage = txnResultMessage;
	}

	@Override
	public String toString() {
		return "TransactionBean [txnProcessCode=" + txnProcessCode + ", txnProcessMessage=" + txnProcessMessage
				+ ", txnResultCode=" + txnResultCode + ", txnResultMessage=" + txnResultMessage + "]";
	}

}
