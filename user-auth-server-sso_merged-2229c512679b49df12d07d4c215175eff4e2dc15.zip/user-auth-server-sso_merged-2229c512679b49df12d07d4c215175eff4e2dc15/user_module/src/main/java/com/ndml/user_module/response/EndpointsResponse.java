package com.ndml.user_module.response;

import java.util.List;
import java.util.Map;

public class EndpointsResponse {

	Map<String, List<String>> epList;

	public Map<String, List<String>> getEpList() {
		return epList;
	}

	public void setEpList(Map<String, List<String>> epList) {
		this.epList = epList;
	}

	@Override
	public String toString() {
		return "EndpointsResponse [epList=" + epList + "]";
	}

}
