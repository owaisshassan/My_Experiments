package com.ndml.user_module.controllers;

import java.util.HashMap;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ndml.user_module.constants.SSOConstants;
import com.ndml.user_module.request.OTPRequestBean;
import com.ndml.user_module.request.OTPValidationRequestBean;
import com.ndml.user_module.response.FetchOtpDetailsResponse;
import com.ndml.user_module.response.OtpResponseBean;
import com.ndml.user_module.response.ValidateOtpResponse;
import com.ndml.user_module.services.OtpService;
import com.ndml.user_module.utility.RateLimitingUtil;
import com.ndml.user_module.utility.SSOUtilities;

@RestController
@RequestMapping("/auth")
public class OtpController {
	private static final Logger logger = LoggerFactory.getLogger(OtpController.class);

	@Autowired
	OtpService otpService;

	@Autowired
	MessageSource messageSource;
	
	@Value("${ndml.otp.count}")
	private Integer maxOtpCount;

	@PostMapping(path = "/get/otp", consumes = "application/json")
	public ResponseEntity<OtpResponseBean<Object>> fetchOtpDetails(@Valid @RequestBody OTPRequestBean requestBean,
						HttpServletRequest http) throws Exception {
		
		//Ip based Rate Limiting for OTP flooding  : 
		boolean isOtpGenAllowedForThisIP =  RateLimitingUtil.rateLimit(http,maxOtpCount);
		
		OtpResponseBean<Object> responseBean = null;

		HttpStatus statusCode = null;
		
		if(isOtpGenAllowedForThisIP) {
			
			FetchOtpDetailsResponse fetchOtpDetailsResponse  = otpService.fetchOtpDetails(requestBean);
//			boolean isSaved = true;

			if (fetchOtpDetailsResponse.isSaved()) {
				responseBean = SSOUtilities.getResponseBean(SSOConstants.OK, SSOConstants.SSO_SUCCESS_MESSAGE,
						SSOConstants.SSO_SUCCESS_CODE,
						messageSource.getMessage("success.otp.generate", null, Locale.ENGLISH), new HashMap<>());

				statusCode = HttpStatus.OK;
			}else if(!fetchOtpDetailsResponse.isSaved() && fetchOtpDetailsResponse.getErrorMsg().equalsIgnoreCase(SSOConstants.WRONG_CREDENTIALS)){
				logger.info(messageSource.getMessage("error.wrong.credentials", null, Locale.ENGLISH));
				responseBean = SSOUtilities.getResponseBean(SSOConstants.OK, SSOConstants.SSO_ERROR_MESSAGE,
						SSOConstants.SSO_ERROR_CODE, messageSource.getMessage("error.wrong.credentials", null, Locale.ENGLISH),
						new HashMap<>());

				statusCode = HttpStatus.OK;
			}else if(!fetchOtpDetailsResponse.isSaved() && fetchOtpDetailsResponse.getErrorMsg().contains("OTP limit exhausted!")){
				logger.info(messageSource.getMessage("error.otp.send", null, Locale.ENGLISH));
				responseBean = SSOUtilities.getResponseBean(SSOConstants.OK, SSOConstants.SSO_ERROR_MESSAGE,
						SSOConstants.SSO_ERROR_CODE, fetchOtpDetailsResponse.getErrorMsg(),
						new HashMap<>());

				statusCode = HttpStatus.OK;
			}
			else {
				logger.info(messageSource.getMessage("error.otp.send", null, Locale.ENGLISH));
				responseBean = SSOUtilities.getResponseBean(SSOConstants.OK, SSOConstants.SSO_ERROR_MESSAGE,
						SSOConstants.SSO_ERROR_CODE, messageSource.getMessage("error.otp.send", null, Locale.ENGLISH),
						new HashMap<>());

				statusCode = HttpStatus.OK;
			}
		}else {
			logger.info(messageSource.getMessage("error.otp.send", null, Locale.ENGLISH));
			responseBean = SSOUtilities.getResponseBean(SSOConstants.OK, SSOConstants.SSO_ERROR_MESSAGE,
					SSOConstants.SSO_ERROR_CODE, messageSource.getMessage("error.ratelimit.count", null, Locale.ENGLISH),
					new HashMap<>());

			statusCode = HttpStatus.OK;
		}
		
		logger.info("Fetch OTP Details Controller START");
		
		logger.info("Fetch OTP Details Controller END");
		return new ResponseEntity<OtpResponseBean<Object>>(responseBean, statusCode);
	}

	@PostMapping(path = "/validate/otp", consumes = "application/json")
	public ResponseEntity<OtpResponseBean<Object>> validateOtp(@Valid @RequestBody OTPValidationRequestBean requestBean) throws Exception {
		logger.info("Validate OTP Details Controller START");
		OtpResponseBean<Object> responseBean = null;
		HttpStatus statusCode = null;
		ValidateOtpResponse validateOtpResponse = otpService.validateOtp(requestBean);

		if (validateOtpResponse.isValid()) {
			responseBean = SSOUtilities.getResponseBean(SSOConstants.OK, SSOConstants.SSO_SUCCESS_MESSAGE,
					SSOConstants.SSO_SUCCESS_CODE, messageSource.getMessage("success.otp.valid", null, Locale.ENGLISH),
					new HashMap<>());

		}else if (!validateOtpResponse.isValid() && validateOtpResponse.getErrorMsg().equalsIgnoreCase(SSOConstants.ERROR_WRONG_OTP)) {
			responseBean = SSOUtilities.getResponseBean(SSOConstants.OK,SSOConstants.SSO_ERROR_MESSAGE,
					SSOConstants.SSO_ERROR_CODE,messageSource.getMessage("error.wrong.otp", null, Locale.ENGLISH),
					new HashMap<>());
		}else if (!validateOtpResponse.isValid() && validateOtpResponse.getErrorMsg().equalsIgnoreCase(SSOConstants.ERROR_OTP_TIMEOUT)) {
			responseBean = SSOUtilities.getResponseBean(SSOConstants.OK, SSOConstants.SSO_ERROR_MESSAGE,
					SSOConstants.SSO_ERROR_CODE,messageSource.getMessage("error.otp.timeout", null, Locale.ENGLISH),
					new HashMap<>());
		}else if (!validateOtpResponse.isValid() && validateOtpResponse.getErrorMsg().equalsIgnoreCase(SSOConstants.ERROR_RETRY_COUNT)) {
			responseBean = SSOUtilities.getResponseBean(SSOConstants.OK, SSOConstants.SSO_ERROR_MESSAGE,
					SSOConstants.SSO_ERROR_CODE,messageSource.getMessage("error.retry.count", null, Locale.ENGLISH),
					new HashMap<>());
		}
		else {
			logger.info(messageSource.getMessage("unsuccess.otp.valid", null, Locale.ENGLISH));
			responseBean = SSOUtilities.getResponseBean(SSOConstants.OK, SSOConstants.SSO_ERROR_MESSAGE,
					SSOConstants.SSO_ERROR_CODE, messageSource.getMessage("unsuccess.otp.valid", null, Locale.ENGLISH),
					new HashMap<>());

		}
		statusCode = HttpStatus.OK;
		
		logger.info("Fetch OTP Details Controller END");
		return new ResponseEntity<OtpResponseBean<Object>>(responseBean, statusCode);
	}

}
