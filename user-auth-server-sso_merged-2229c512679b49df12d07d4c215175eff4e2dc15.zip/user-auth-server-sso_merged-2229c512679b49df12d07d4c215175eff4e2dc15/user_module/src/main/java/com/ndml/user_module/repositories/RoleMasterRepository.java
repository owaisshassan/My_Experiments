package com.ndml.user_module.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ndml.user_module.model.RoleMaster;

@Repository
public interface RoleMasterRepository extends JpaRepository<RoleMaster, Long>{
	
	
	public Optional<RoleMaster> findByRoleName(String name);

}
