package com.ndml.user_module.request;

import javax.validation.constraints.NotBlank;

public class LogoutRequest {

	@NotBlank
	private String useremailId;

	public String getUseremailId() {
		return useremailId;
	}

	public void setUseremailId(String useremailId) {
		this.useremailId = useremailId;
	}

	@Override
	public String toString() {
		return "LogoutRequest [email=" + useremailId + "]";
	}

}
