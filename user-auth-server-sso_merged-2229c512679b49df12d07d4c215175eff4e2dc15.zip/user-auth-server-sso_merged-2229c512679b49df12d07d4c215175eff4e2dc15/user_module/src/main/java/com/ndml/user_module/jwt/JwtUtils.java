package com.ndml.user_module.jwt;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import com.ndml.user_module.configuration.SecurityConstants;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.IOException;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtils {

	Logger log = Logger.getLogger(JwtUtils.class.getName());

	@Value("${ndml.app.jwtSecret}")
	private String jwtSecret;

	private long jwtExpirationInMs;

	@Value("${ndml.jwt.expiry}")
	public void setJwtExpirationInMs(long jwtExpirationInMs) {
		this.jwtExpirationInMs = jwtExpirationInMs;
	}

	private boolean isGenerateTkn;

	@Value("${ndml.jwt.generateTkn}")
	public void setIsGenerateTkn(boolean isGenerateTkn) {
		this.isGenerateTkn = isGenerateTkn;
	}

	private long refreshExpirationDateInMs;

	@Value("${ndml.jwt.refreshExpirationDateInMs}")
	public void setRefreshExpirationDateInMs(long refreshExpirationDateInMs) {
		this.refreshExpirationDateInMs = refreshExpirationDateInMs;
	}

//	@Autowired
//	private CustomAuthenticationProvider authenticationProvider;

	// *****
	private String currentJwt;

	public String getCurrentJwt() {
		return currentJwt;
	}

	public String generateJwtToken(Authentication authentication,String dpID, String dpName) {

		System.out.println("inside generator of JWTUtils, auth.getName() : " + authentication.getName());
		System.out.println(
				"inside generator of JWTUtils, auth.getAuthorities() : " + authentication.getAuthorities().toString());
		System.out.println("inside generator of JWTUtils, auth.getCredentials() : " + authentication.getCredentials());
		// UserDetailsImpl userPrincipal = (UserDetailsImpl)
		// authentication.getPrincipal();

		System.out.println("444444444444444444444444444444444444444444444444");
		System.out.println("**************************");
		System.out.println("**************************");

		if (isGenerateTkn && authentication != null) {
			log.info("inside JWT builder... i.e. isGenerateTkn = true");

			SecretKey secret = Keys.hmacShaKeyFor(SecurityConstants.JWT_KEY.getBytes());

			String jwt = Jwts.builder()
					// .setSubject((userPrincipal.getUsername()))
					.setSubject("JWT Token").setHeaderParam("typ", "JWT").setIssuer("ndml")
					.claim("dpID", dpID).claim("dpName", dpName)
					.claim("user", authentication).claim("username", authentication.getName())
					.claim("authorities", populateAuthorities(authentication.getAuthorities()))
					.claim("roles", getRole(authentication.getAuthorities())).setIssuedAt(new Date())
					.setExpiration(new Date((new Date()).getTime() + jwtExpirationInMs)).signWith(secret) // RS256

					.compact();

			// response.setHeader(SecurityConstants.JWT_HEADER, jwt);

			currentJwt = jwt;

			log.info("JWT generated successfully!");

			return jwt;
		} else
			throw new IOException("Token built failed!");
	}

//custom method to generate String result from
	// 'authentication.getAuthorities()' collection
	// to be passed in '.claim()' of 'jwts.builder()' for jwt generation.
	private String populateAuthorities(Collection<? extends GrantedAuthority> collection) {

		Set<String> authoritiesSet = new HashSet<>();

		for (GrantedAuthority authority : collection) {
			authoritiesSet.add(authority.getAuthority());
		}

		return String.join(",", authoritiesSet);
	}

	// *********

	public String doGenerateRefreshToken(Map<String, Object> claims, String subject) {

		SecretKey secret = Keys.hmacShaKeyFor(SecurityConstants.JWT_KEY.getBytes());

		return Jwts.builder().setIssuer("ndml").setClaims(claims).setSubject(subject).setIssuedAt(new Date())
				.setExpiration(new Date(new Date().getTime() + refreshExpirationDateInMs)).signWith(secret).compact();

	}

	public String returnCurrentJwt() {
		return getCurrentJwt();
	}

	private String getRole(Collection<? extends GrantedAuthority> collection) {

		String role = "";
		for (GrantedAuthority ga : collection) {
			role = ga.getAuthority();
		}

		System.out.println("INSIDE 'getRole' of 'JWTGen'...");
		System.out.println("ROLE : " + role);

		return role;
	}

}
