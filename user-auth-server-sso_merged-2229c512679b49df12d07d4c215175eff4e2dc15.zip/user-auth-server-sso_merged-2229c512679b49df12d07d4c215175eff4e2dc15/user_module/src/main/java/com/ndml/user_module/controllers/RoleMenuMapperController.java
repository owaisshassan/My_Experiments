package com.ndml.user_module.controllers;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.cache.annotation.EnableCaching;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ndml.user_module.model.RoleMenuMapper;
import com.ndml.user_module.request.RoleMenuMapperRequest;
import com.ndml.user_module.services.RoleMenuMapperService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/mapper")
//@EnableCaching
public class RoleMenuMapperController {

	@Autowired
	private RoleMenuMapperService mapperService;

//  localhost:8083/mapper/register
	@PostMapping("/register")
	public ResponseEntity<RoleMenuMapper>registerNewApplicationHandler(@RequestBody RoleMenuMapperRequest request){
		RoleMenuMapper registered =  mapperService.addNewRoleMenuMapper(request);
		
		return new ResponseEntity<RoleMenuMapper>(registered,HttpStatus.OK);
	}

}
