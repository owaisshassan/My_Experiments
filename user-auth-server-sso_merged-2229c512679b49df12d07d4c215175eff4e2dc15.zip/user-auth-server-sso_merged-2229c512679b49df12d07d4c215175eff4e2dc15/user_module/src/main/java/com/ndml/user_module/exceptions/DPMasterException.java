package com.ndml.user_module.exceptions;

public class DPMasterException extends RuntimeException{
	
	public DPMasterException() {
		// TODO Auto-generated constructor stub
	}
	
	public DPMasterException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
