package com.ndml.user_module.response;

import java.util.Date;
import java.util.List;

public class RefreshTokenResponse {

	private String refreshToken;
	
	private String expDt;

	
	public String getExpDt() {
		return expDt;
	}

	public void setExpDt(String expDt) {
		this.expDt = expDt;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public RefreshTokenResponse() {
		// TODO Auto-generated constructor stub
	}

	public RefreshTokenResponse(String refreshToken, String expDt) {
		super();
		this.refreshToken = refreshToken;
		this.expDt = expDt;
	}

	@Override
	public String toString() {
		return "RefreshTokenResponse [refreshToken=" + refreshToken + ", expDt=" + expDt + "]";
	}


	

}
