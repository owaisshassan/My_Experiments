package com.ndml.user_module.utility;

import java.util.Objects;

import javax.crypto.SecretKey;

public class CustomJwtSecretKeyPair {

	private String tokenKey;
	private String secretKeyForToken;

	public String getTokenKey() {
		return tokenKey;
	}

	public void setTokenKey(String tokenKey) {
		this.tokenKey = tokenKey;
	}

	public String getSecretKeyForToken() {
		return secretKeyForToken;
	}

	public void setSecretKeyForToken(String secretKeyForToken) {
		this.secretKeyForToken = secretKeyForToken;
	}

	@Override
	public String toString() {
		return "CustomCachekey [tokenKey=" + tokenKey + ", secretKeyForToken=" + secretKeyForToken + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(secretKeyForToken, tokenKey);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomJwtSecretKeyPair other = (CustomJwtSecretKeyPair) obj;
		return Objects.equals(secretKeyForToken, other.secretKeyForToken) && Objects.equals(tokenKey, other.tokenKey);
	}

}
