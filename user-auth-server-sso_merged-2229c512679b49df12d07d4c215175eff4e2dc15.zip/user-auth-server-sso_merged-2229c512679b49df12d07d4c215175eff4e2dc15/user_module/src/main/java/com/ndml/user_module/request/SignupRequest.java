package com.ndml.user_module.request;

public class SignupRequest {
//	@NotBlank
//	@Size(min = 3, max = 20)
	private String username;

//	@NotBlank
//	@Size(max = 50)
//	@Email
	private String useremailId;

	private String usermobileNumber;

//	@NotBlank
//	@Size(min = 6, max = 40)
	private String password;

	private String dpID;

	private long applicationId;

	private long roleId;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUseremailId() {
		return useremailId;
	}

	public void setUseremailId(String useremailId) {
		this.useremailId = useremailId;
	}

	public String getUsermobileNumber() {
		return usermobileNumber;
	}

	public void setUsermobileNumber(String usermobileNumber) {
		this.usermobileNumber = usermobileNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDpID() {
		return dpID;
	}

	public void setDpID(String dpID) {
		this.dpID = dpID;
	}

	public long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}

	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	@Override
	public String toString() {
		return "SignupRequest [username=" + username + ", useremailId=" + useremailId + ", usermobileNumber="
				+ usermobileNumber + ", password=" + password + ", dpID=" + dpID + ", applicationId=" + applicationId
				+ ", roleId=" + roleId + "]";
	}

}
