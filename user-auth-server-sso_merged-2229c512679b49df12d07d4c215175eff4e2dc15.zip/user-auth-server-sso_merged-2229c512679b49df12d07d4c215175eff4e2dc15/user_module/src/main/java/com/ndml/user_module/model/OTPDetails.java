package com.ndml.user_module.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sso_otp_dtl")
public class OTPDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "sso_otp_dtl_id", unique = true)
	private long otpDetailsId;

	@Column(name = "sso_crtd_tsp")
	private Timestamp createdTimestamp;

	@Column(name = "sso_updt_tsp")
	private Timestamp updatedTimestamp;

	@Column(name = "sso_email_id")
	private String emailId;

	@Column(name = "sso_mob_no")
	private String mobileNumber;

	@Column(name = "sso_otp")
	private String oneTimePassword;

	@Column(name = "sso_otp_gnt_cnt")
	private int otpGenerationCount;

	@Column(name = "sso_otp_req_typ")
	private String otpRequestType;

	@Column(name = "sso_otp_tmp")
	private long otpTimestamp;

	@Column(name = "sso_validate_flg")
	private String validateFlg;

	@Column(name = "sso_err_otp_gnt_cnt")
	private int errOtpGenerationCount;

	public long getOtpDetailsId() {
		return otpDetailsId;
	}

	public void setOtpDetailsId(long otpDetailsId) {
		this.otpDetailsId = otpDetailsId;
	}

	public Timestamp getCreatedTimestamp() {
		return createdTimestamp;
	}

	public void setCreatedTimestamp(Timestamp createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}

	public Timestamp getUpdatedTimestamp() {
		return updatedTimestamp;
	}

	public void setUpdatedTimestamp(Timestamp updatedTimestamp) {
		this.updatedTimestamp = updatedTimestamp;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getOneTimePassword() {
		return oneTimePassword;
	}

	public void setOneTimePassword(String oneTimePassword) {
		this.oneTimePassword = oneTimePassword;
	}

	public int getOtpGenerationCount() {
		return otpGenerationCount;
	}

	public void setOtpGenerationCount(int otpGenerationCount) {
		this.otpGenerationCount = otpGenerationCount;
	}

	public String getOtpRequestType() {
		return otpRequestType;
	}

	public void setOtpRequestType(String otpRequestType) {
		this.otpRequestType = otpRequestType;
	}

	public long getOtpTimestamp() {
		return otpTimestamp;
	}

	public void setOtpTimestamp(long otpTimestamp) {
		this.otpTimestamp = otpTimestamp;
	}

	public String getValidateFlg() {
		return validateFlg;
	}

	public void setValidateFlg(String validateFlg) {
		this.validateFlg = validateFlg;
	}

	public int getErrOtpGenerationCount() {
		return errOtpGenerationCount;
	}

	public void setErrOtpGenerationCount(int errOtpGenerationCount) {
		this.errOtpGenerationCount = errOtpGenerationCount;
	}

	@Override
	public String toString() {
		return "OTPDetails [otpDetailsId=" + otpDetailsId + ", createdTimestamp=" + createdTimestamp + ", emailId="
				+ emailId + ", mobileNumber=" + mobileNumber + ", oneTimePassword=" + oneTimePassword
				+ ", otpGenerationCount=" + otpGenerationCount + ", otpRequestType=" + otpRequestType
				+ ", otpTimestamp=" + otpTimestamp + ", validateFlg=" + validateFlg + ", errOtpGenerationCount="
				+ errOtpGenerationCount + "]";
	}

}
