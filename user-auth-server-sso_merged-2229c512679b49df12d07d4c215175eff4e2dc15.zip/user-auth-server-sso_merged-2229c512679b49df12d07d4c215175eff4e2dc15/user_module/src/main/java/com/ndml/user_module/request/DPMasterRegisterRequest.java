package com.ndml.user_module.request;

import java.util.List;

public class DPMasterRegisterRequest {

	private String DPName;

	private String DPAddress;

	private String enckey;

//	private List<String> eplist;

//	public List<String> getEplist() {
//		return eplist;
//	}

//	public void setEplist(List<String> eplist) {
//		this.eplist = eplist;
//	}

	public String getDPName() {
		return DPName;
	}

	public void setDPName(String dPName) {
		DPName = dPName;
	}

	public String getDPAddress() {
		return DPAddress;
	}

	public void setDPAddress(String dPAddress) {
		DPAddress = dPAddress;
	}

	public String getEnckey() {
		return enckey;
	}

	public void setEnckey(String enckey) {
		this.enckey = enckey;
	}

	@Override
	public String toString() {
		return "DPMasterRegisterRequest [DPName=" + DPName + ", DPAddress=" + DPAddress + ", enckey=" + enckey + "]";
	}

	

}
