package com.ndml.user_module.controllers;


import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class EPRoleController {
	

	
	
	//dac
		@PostMapping("/d/d/dac/1/csearch")
		public ResponseEntity<?> dacCheckerSearchEPHandler(HttpServletRequest http){

			return new ResponseEntity<String>("dacCheckerSearchEPHandler UNLOCKED!",HttpStatus.OK);
		}
		@PostMapping("/d/d/dac/1/cview")
		public ResponseEntity<?> dacCheckerViewEPHandler(HttpServletRequest http){

			return new ResponseEntity<String>("dacCheckerViewEPHandler UNLOCKED!",HttpStatus.OK);
		}
		
		@PostMapping("/d/d/dac/2/msearch")
		public ResponseEntity<?> dacMakerSearchEPHandler(HttpServletRequest http){

			return new ResponseEntity<String>("dacMakerSearchEPHandler UNLOCKED!",HttpStatus.OK);
		}
		@PostMapping("/d/d/dac/2/mview")
		public ResponseEntity<?> dacMakerViewEPHandler(HttpServletRequest http){

			return new ResponseEntity<String>("dacMakerViewEPHandler UNLOCKED!",HttpStatus.OK);
		}
		
		
		
		//instigo
		@PostMapping("/i/i/instigo/1/csearch")
		public ResponseEntity<?> instigoCheckerSearchEPHandler(HttpServletRequest http){

			return new ResponseEntity<String>("instigoCheckerSearchEPHandler UNLOCKED!",HttpStatus.OK);
		}
		@PostMapping("/i/i/instigo/1/cview")
		public ResponseEntity<?> instigoCheckerViewEPHandler(HttpServletRequest http){

			return new ResponseEntity<String>("instigoCheckerViewEPHandler UNLOCKED!",HttpStatus.OK);
		}
		
		@PostMapping("/i/i/instigo/2/msearch")
		public ResponseEntity<?> instigoMakerSearchEPHandler(HttpServletRequest http){

			return new ResponseEntity<String>("instigoMakerSearchEPHandler UNLOCKED!",HttpStatus.OK);
		}
		@PostMapping("/i/i/instigo/2/mview")
		public ResponseEntity<?> instigoMakerViewEPHandler(HttpServletRequest http){

			return new ResponseEntity<String>("instigoMakerViewEPHandler UNLOCKED!",HttpStatus.OK);
		}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	//dac
	@PostMapping("/dac/1/csearch")
	public ResponseEntity<?> dCheckerSearchEPHandler(HttpServletRequest http){
		//setConfigDynamicAuth(http);
		
//		System.out.println(config.getDacRole());
		return new ResponseEntity<String>("dacCheckerSearchEPHandler UNLOCKED!",HttpStatus.OK);
	}
	@PostMapping("/dac/1/cview")
	public ResponseEntity<?> daCheckerViewEPHandler(HttpServletRequest http){
//		setConfigDynamicAuth(http);
//		System.out.println(config.getDacRole());
		return new ResponseEntity<String>("dacCheckerViewEPHandler UNLOCKED!",HttpStatus.OK);
	}
	
	@PostMapping("/dac/2/msearch")
	public ResponseEntity<?> daMakerSearchEPHandler(HttpServletRequest http){
//		setConfigDynamicAuth(http);
//		System.out.println(config.getDacRole());
		return new ResponseEntity<String>("dacMakerSearchEPHandler UNLOCKED!",HttpStatus.OK);
	}
	@PostMapping("/dac/2/mview")
	public ResponseEntity<?> daMakerViewEPHandler(HttpServletRequest http){
//		setConfigDynamicAuth(http);
//		System.out.println(config.getDacRole());
		return new ResponseEntity<String>("dacMakerViewEPHandler UNLOCKED!",HttpStatus.OK);
	}
	
	
	
//	//instigo
	@PostMapping("/instigo/1/csearch")
	public ResponseEntity<?> instCheckerSearchEPHandler(HttpServletRequest http){
//		setConfigDynamicAuth(http);
//		System.out.println(config.getInstigoRole());
		return new ResponseEntity<String>("instigoCheckerSearchEPHandler UNLOCKED!",HttpStatus.OK);
	}
	@PostMapping("/instigo/1/cview")
	public ResponseEntity<?> instgoCheckerViewEPHandler(HttpServletRequest http){
//		setConfigDynamicAuth(http);
//		System.out.println(config.getInstigoRole());
		return new ResponseEntity<String>("instigoCheckerViewEPHandler UNLOCKED!",HttpStatus.OK);
	}
	
	@PostMapping("/instigo/2/msearch")
	public ResponseEntity<?> instMakerSearchEPHandler(HttpServletRequest http){
//		setConfigDynamicAuth(http);
//		System.out.println(config.getInstigoRole());
		return new ResponseEntity<String>("instigoMakerSearchEPHandler UNLOCKED!",HttpStatus.OK);
	}
	@PostMapping("/instigo/2/mview")
	public ResponseEntity<?> instiMakerViewEPHandler(HttpServletRequest http){
//		setConfigDynamicAuth(http);
//		System.out.println(config.getInstigoRole());
		return new ResponseEntity<String>("instigoMakerViewEPHandler UNLOCKED!",HttpStatus.OK);
	}
//	
//	
//	private void setConfigDynamicAuth(HttpServletRequest req) {
//		String requestURI = req.getRequestURI();
//		if(requestURI.contains("/dac/1"))
//		{
//			config.setDacRole("DAC_checker");
//			config.setDacURL(requestURI);
//		}else if(requestURI.contains("/dac/2"))
//		{
//			config.setDacRole("DAC_maker");
//			config.setDacURL(requestURI);
//		}else if(requestURI.contains("/instigo/1"))
//		{
//			config.setInstigoRole("INSTIGO_checker");
//			config.setDacURL(requestURI);
//		}else if(requestURI.contains("/instigo/2")){
//			config.setInstigoRole("INSTIGO_checker");
//			config.setDacURL(requestURI);
//		}else {
//			config.setDacRole("DUMMY");
//			config.setInstigoRole("DUMMY");
//			config.setRtaRole("DUMMY");
//			config.setRtaURL(requestURI);
//			config.setInstigoURL(requestURI);
//			config.setDacURL(requestURI);
//		}
//	}
//	


}
