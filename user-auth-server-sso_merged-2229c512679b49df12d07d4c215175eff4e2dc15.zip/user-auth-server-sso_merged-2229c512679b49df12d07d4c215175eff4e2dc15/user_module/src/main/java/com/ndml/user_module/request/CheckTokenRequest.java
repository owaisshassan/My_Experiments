package com.ndml.user_module.request;

public class CheckTokenRequest {

	private String encryptedToken;
	private String decKey;

	public String getEncryptedToken() {
		return encryptedToken;
	}

	public void setEncryptedToken(String encryptedToken) {
		this.encryptedToken = encryptedToken;
	}

	public String getDecKey() {
		return decKey;
	}

	public void setDecKey(String decKey) {
		this.decKey = decKey;
	}

	@Override
	public String toString() {
		return "CheckTokenRequest [encryptedToken=" + encryptedToken + ", decKey=" + decKey + "]";
	}

}
