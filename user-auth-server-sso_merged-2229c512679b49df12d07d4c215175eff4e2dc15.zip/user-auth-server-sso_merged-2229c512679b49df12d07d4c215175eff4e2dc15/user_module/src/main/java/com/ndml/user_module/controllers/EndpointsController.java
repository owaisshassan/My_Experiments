package com.ndml.user_module.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ndml.user_module.model.EndPointsMaster;
import com.ndml.user_module.request.EndPointsRegisterRequest;
import com.ndml.user_module.services.EndPointsService;


@RestController
@RequestMapping("/ep")
public class EndpointsController {
	
	@Autowired
	private EndPointsService epService;
	
	@PostMapping("/register")
	public ResponseEntity<?> registerNewEndpointHandler(@RequestBody EndPointsRegisterRequest req){
		EndPointsMaster epm = epService.registerNewEndPoint(req);
		
		return new ResponseEntity<EndPointsMaster>(epm,HttpStatus.OK);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// 1: for user role only
	// 2 : maker role only
	// 3: checker role only
	
	//USER_ROLE :
	
//	@PostMapping("/1")
//	public ResponseEntity<String> endPointCheck1(){
//		return new ResponseEntity<String>("Unlocked!",HttpStatus.OK);
//	}
//	
//	@PostMapping("/1/dummy")
//	public ResponseEntity<String> endPointCheck2(){
//		return new ResponseEntity<String>("Unlocked!",HttpStatus.OK);
//	}
//	
//	@PostMapping("/1/hello")
//	public ResponseEntity<String> endPointCheck3(){
//		return new ResponseEntity<String>("Unlocked!",HttpStatus.OK);
//	}
//	
//	// MAKER_ROLE :
//	
//	@PostMapping("/2")
//	public ResponseEntity<String> endPointCheck4(){
//		return new ResponseEntity<String>("Unlocked!",HttpStatus.OK);
//	}
//	
//	@PostMapping("/2/dummy")
//	public ResponseEntity<String> endPointCheck5(){
//		return new ResponseEntity<String>("Unlocked!",HttpStatus.OK);
//	}
//	
//	@PostMapping("/2/dpm")
//	public ResponseEntity<String> endPointCheck6(){
//		return new ResponseEntity<String>("Unlocked!",HttpStatus.OK);
//	}
//	
//	
//	// CHECKER_ROLE :
//	
//	@PostMapping("/3")
//	public ResponseEntity<String> endPointCheck7(){
//		return new ResponseEntity<String>("Unlocked!",HttpStatus.OK);
//	}
//	
//	@PostMapping("/3/dummy")
//	public ResponseEntity<String> endPointCheck8(){
//		return new ResponseEntity<String>("Unlocked!",HttpStatus.OK);
//	}
//	
//	@PostMapping("/3/dpm/download")
//	public ResponseEntity<String> endPointCheck9(){
//		return new ResponseEntity<String>("Unlocked!",HttpStatus.OK);
//	}
//	
	
	
	
	
}
