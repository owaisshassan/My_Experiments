package com.ndml.user_module.exceptions;

public class InvalidPasswordException extends RuntimeException{
	
	public InvalidPasswordException() {
		// TODO Auto-generated constructor stub
	}
	
	public InvalidPasswordException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
