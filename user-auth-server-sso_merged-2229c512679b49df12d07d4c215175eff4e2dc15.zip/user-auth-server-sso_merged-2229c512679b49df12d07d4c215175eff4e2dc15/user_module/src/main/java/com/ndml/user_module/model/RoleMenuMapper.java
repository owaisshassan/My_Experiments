package com.ndml.user_module.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class RoleMenuMapper {

	@Id
	private long roleId;
	
	@Column(name = "menulist", columnDefinition = "jsonb")
	private String menulist;
	
	private long applicationId;
	private Date crtdDt;
	private Date updtDt;
	
	@Column(name = "ep_list", columnDefinition = "jsonb")
	private String epList;

	
	public long getRoleId() {
		return roleId;
	}
	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}
	
	public long getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}
	public Date getCrtdDt() {
		return crtdDt;
	}
	public void setCrtdDt(Date crtdDt) {
		this.crtdDt = crtdDt;
	}
	public Date getUpdtDt() {
		return updtDt;
	}
	public void setUpdtDt(Date updtDt) {
		this.updtDt = updtDt;
	}
	
	
	
	
	public List<String> getMenulist() {
		if (menulist == null) {
			return new ArrayList<>();
		}
		return Arrays.asList(menulist.replaceAll("\"", "").split(","));
	}
	
	public void setMenulist(List<String> menulist) {
		this.menulist = String.join(",", menulist);
	}
	
	public List<String> getEpList() {
		if (epList == null) {
			return new ArrayList<>();
		}
		return Arrays.asList(epList.replaceAll("\"", "").split(","));
	}
	public void setEpList(List<String> epList) {
		this.epList = String.join(",", epList);
	}
	
	public RoleMenuMapper() {
		// TODO Auto-generated constructor stub
	}
	

	public RoleMenuMapper(long roleId, List<String> menulist, long applicationId, Date crtdDt, Date updtDt, List<String> epList) {
		super();
		this.roleId = roleId;
		this.menulist = menulist.stream().collect(Collectors.joining(","));
		this.applicationId = applicationId;
		this.crtdDt = crtdDt;
		this.updtDt = updtDt;
		this.epList = epList.stream().collect(Collectors.joining(","));
	}
	
	
	
	
	
}
