package com.ndml.user_module.constants;

public class SSOConstants {

	public static final String TIMESTAMP_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";

	public static final String NOTIFICATION = "NOTIFICATION";
	
	public static final String RESETPASS_OTP = "password-reset";
	
	public static final String EXISTING_NOTIFICATION = "EXISTING_NOTIFICATION";
	
	public static final String USER_LOCKED = "USER_LOCKED";
	
	public static final String SSO_WEB = "SSO_WEB";
	
	public static final String OTP_MATCHED = "OTP_MATCHED";
	
	public static final String INSTIGO_DAC = "INSTIGO_DAC";
	
	public static final String INSTIGO_DIY = "INSTIGO_DIY";

	/* Generic Error Codes */

	public static final String OK = "200";

	public static final String BAD_REQUEST = "400";

	public static final String NOT_FOUND = "404";

	public static final String METHOD_NOT_ALLOWED = "405";

	public static final String CONFLICT = "409";

	public static final String INTERNAL_SERVER_ERROR = "500";

	/* SSO Transaction Status Messages */

	public static final String SSO_SUCCESS_MESSAGE = "SUCCESS";

	public static final String SSO_ERROR_MESSAGE = "ERROR";
	
	public static final String ERROR_OTP_TIMEOUT = "ERROR_OTP_TIMEOUT";
	
	public static final String ERROR_RETRY_COUNT = "ERROR_RETRY_COUNT";
	
	public static final String ERROR_WRONG_OTP = "ERROR_WRONG_OTP";
	
	public static final String WRONG_CREDENTIALS= "WRONG_CREDENTIALS";
	
	public static final String INVALID_RESET_TOKEN = "INVALID_RESET_TOKEN";
	
	public static final String RESET_TOKEN_EXPIRED = "RESET_TOKEN_EXPIRED";
	
	public static final String OLD_PASSWORDS_ERROR = "OLD_PASSWORDS_ERROR";
	

	/* SSO Error Codes */

	public static final String SSO_EXCEPTION = "9999";

	public static final String SSO_ERROR_CODE = "1000";

	public static final String SSO_SUCCESS_CODE = "2000";

	public static final String SSO_CUSTOM_EXCEPTION = "1001";

	public static final String SSO_VALIDATION_FAILURE = "1003";

	public static final String SSO_FETCH_ERROR = "1002";

}
