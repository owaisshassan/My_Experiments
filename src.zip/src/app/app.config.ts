
import { LocationStrategy } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class AppConfig {
  ssoCoreUrl: string;
  ssoWebUrl: string;
  constructor(private http: HttpClient, private locationStrategy: LocationStrategy) {
  }

  public load() {
    console.log("base href : "+this.locationStrategy.getBaseHref());
    return this.http.get(this.locationStrategy.getBaseHref() + 'assets/resources/sso.json').toPromise().then(response => {
      this.ssoCoreUrl = response['ssoCoreUrl'];
      this.ssoWebUrl = response['ssoWebUrl'];
    });
  }

  get GetSsoCoreUrl(): string {
    return this.ssoCoreUrl
  }

  get GetSsoWebUrl(): string {
    return this.ssoWebUrl
  }

}
