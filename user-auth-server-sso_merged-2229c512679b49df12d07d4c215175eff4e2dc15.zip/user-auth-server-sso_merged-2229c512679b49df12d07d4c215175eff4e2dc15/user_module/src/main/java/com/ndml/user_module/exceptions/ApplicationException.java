package com.ndml.user_module.exceptions;

public class ApplicationException extends RuntimeException{
	
	public ApplicationException() {
		// TODO Auto-generated constructor stub
	}
	
	public ApplicationException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
