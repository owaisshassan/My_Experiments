package com.ndml.user_module.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ndml.user_module.services.RoleMasterService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/role")
public class RoleMasterController {

	@Autowired
	private RoleMasterService roleService;

	// localhost:8083/role/app09roles
//	@PostMapping("/dacroles")
//	public ResponseEntity<String> addApp09RolesRoleHandler() throws Exception {
//
//		String r = roleService.addApp09UserRole();
//		String r2 = roleService.addApp09CheckerRole();
//		String r3 = roleService.addApp09MakerRole();
//		return new ResponseEntity<>(r+r2+r3, HttpStatus.OK);
//	}
//	
//	// localhost:8083/role/app10roles
//		@PostMapping("/instigoroles")
//		public ResponseEntity<String> addApp10RolesRoleHandler() throws Exception {
//
//			String r = roleService.addApp10UserRole();
//			String r2 = roleService.addApp10CheckerRole();
//			String r3 = roleService.addApp10MakerRole();
//			return new ResponseEntity<>(r+r2+r3, HttpStatus.OK);
//		}
//		
//		// localhost:8083/role/app11roles
//		@PostMapping("/rtaroles")
//		public ResponseEntity<String> addApp11RolesRoleHandler() throws Exception {
//
//			String r = roleService.addApp11UserRole();
//			String r2 = roleService.addApp11CheckerRole();
//			String r3 = roleService.addApp11MakerRole();
//			return new ResponseEntity<>(r+r2+r3, HttpStatus.OK);
//		}

//	// localhost:8083/role/checkerrole
//	@PostMapping("/checkerrole")
//	public ResponseEntity<String> addCheckerRoleHandler() throws Exception {
//
//		String r = roleService.addCheckerRole();
//		return new ResponseEntity<>(r, HttpStatus.OK);
//	}
//
//	// localhost:8083/role/makerrole
//	@PostMapping("/makerrole")
//	public ResponseEntity<String> addMakerRoleHandler() throws Exception {
//
//		String r = roleService.addMakerRole();
//		return new ResponseEntity<>(r, HttpStatus.OK);
//	}
//	
//	// localhost:8083/role/adminrole
//	@PostMapping("/adminrole")
//	public ResponseEntity<String> addAdminRoleHandler() throws Exception {
//
//		String r = roleService.addAdminRole();
//		return new ResponseEntity<>(r, HttpStatus.OK);
//	}


}
