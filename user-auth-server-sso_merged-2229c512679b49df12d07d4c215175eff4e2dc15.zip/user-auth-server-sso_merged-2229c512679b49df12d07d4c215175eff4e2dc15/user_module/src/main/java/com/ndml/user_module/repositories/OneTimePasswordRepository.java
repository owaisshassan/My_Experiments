package com.ndml.user_module.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.repository.query.Param;

import com.ndml.user_module.model.OTPDetails;

@Repository
public interface OneTimePasswordRepository extends JpaRepository<OTPDetails, Long> {

	@Query(value = "select * from sso_otp_dtl where sso_otp_req_typ =:requestType And sso_mob_no =:mobileNumber and sso_email_id =:emailId", nativeQuery = true)
	OTPDetails findByOtpRequestTypeEmailIdAndMobileNumber(@Param("requestType") String requestType,
			@Param("mobileNumber") String mobileNumber, @Param("emailId") String emailId);

}
