package com.ndml.user_module.services;

import com.ndml.user_module.exceptions.DPMasterException;
import com.ndml.user_module.model.DPMaster;
import com.ndml.user_module.request.DPMasterRegisterRequest;

public interface DPMasterService {
	
	public DPMaster addNewDPMaster(DPMasterRegisterRequest request) throws DPMasterException;

}
