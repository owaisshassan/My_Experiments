export const environment = {
  production: true,
  authentication:true
};
