import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material/dialog';
import { UserService } from 'src/app/service/user.service';
import { GlobalConstants } from 'src/app/shared/global-constants';
import { ResetPasswordComponent } from '../reset-password/reset-password.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Observable, interval } from 'rxjs';
import { takeWhile } from 'rxjs/operators';

import { ConfirmPasswordValidator } from 'src/app/shared/confirm-password.validator';
import { sha512 } from 'js-sha512';
import { AppConfig } from 'src/app/app.config';
import { passValidator, phoneNumberValidator } from 'src/app/service/validator';
// import { HttpService } from 'src/app/service/httpservice';
// import { API_COMMON } from 'src/app/service/api-common';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {

  forgotPasswordForm: any = FormGroup;
  resetPasswordForm: any = FormGroup;
  responseMessage: any;
  displayOtpDiv : boolean = false;
  displayEmailAndOtp : boolean = true;
  otpForm: any = FormGroup;
  showProcedd : boolean = true;
  showOtp : boolean = false;
  timer: number = 120; 
  display: any;
  type = "forgot";
  emailOtp : any;
  sms : any;
  otpVerified : boolean = false;
  emailDisabled = false;
  hideN = true;
  hideC = true;
  otpAttemptCount = 0;
  email;
  mobile;
  intervalId: any;
  intervalId1: any;
  startTimer : boolean = false;

  // tslint:disable-next-line: variable-name

  constructor(private dialog: MatDialog,
    private formBuilder: FormBuilder,
    private userService: UserService,
    private cdr: ChangeDetectorRef,
    private config: AppConfig,
    // private httpService:HttpService,
    public dialogRef: MatDialogRef<ForgotPasswordComponent>,
    private snackbar: MatSnackBar
  ) {
   }

  ngOnInit(): void {
    this.forgotPasswordForm = this.formBuilder.group({
      email: [{ value: '', disabled: this.emailDisabled }, [Validators.required, Validators.pattern(GlobalConstants.emailRegex)]],
      mobile:  ['', [Validators.required, phoneNumberValidator()]],
    });

    this.otpForm = this.formBuilder.group({
      otp : ['', [Validators.required, Validators.minLength(6)]],
      sms : ['', [Validators.required, Validators.minLength(6)]],
    });

    this.resetPasswordForm = this.formBuilder.group({
      newPassword: [null, [Validators.required,passValidator(),
                    Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/)
      ]],
      confirmPassword: [null, [Validators.required,passValidator()]]
    },
    {
      validator: ConfirmPasswordValidator("newPassword", "confirmPassword")
    });
  }

  handleSubmit() {
    // var formData = this.forgotPasswordForm.value;
    var formData = this.forgotPasswordForm.value;
    var data = {
      email: this.email
    }
      this.userService.forgotPassword(data).subscribe({
        next: (resp: any) => {
          // this.dialogRef.close();
          console.log("respresp " , resp)
          if([400].includes(resp.status)) {
            this.snackbar.open("Please enter correct credentials!", 'Dismiss', {
              duration: 3000,
            });
          }
          if (!resp.startsWith("Please")) {
          
            localStorage.setItem('resetPasswordToken', resp);
            this.validateOtp();
          }
          else {
            this.snackbar.open(resp, 'Dismiss', {
              duration: 3000,
            });
          }

          
        },
        error: (error) => {
          console.log(error.message);

          // window.location.reload();
          this.userService.goToSSOPage()
        }

       
      })

      
  }

  handleSubmit2(){
    var formData = this.forgotPasswordForm.value;
    console.log("formData.email " , formData.email)
    this.email = formData.email;
    this.mobile = formData.mobile;

   
    const payload = {
      mobile: this.mobile,
      email: this.email,
      requestType: "password-reset"
    };
    console.log('payload', payload);

    this.userService.getOtp(payload, '/auth/get/otp').subscribe((res: any) => {
      console.log("data " , res.response)
           this.openSnackBar(res.response);
          // if(res.response==="Email Not Present"){
          //   this.displayOtpDiv = false;
          //   this.showProcedd = true;
          //   this.showOtp = false;
          // }
          if(res.response.txnResultMessage==="OTP generated successfully."){
            this.displayOtpDiv = true;
            this.showProcedd = false;
            this.showOtp = true;
            this.displayEmailAndOtp = false;
            this.otpTimer();
          }else{
            console.log("ERROR in OTP generation..");
            this.displayOtpDiv = false;
            this.showProcedd = true;
            this.showOtp = false;
          }

   
          this.openSnackBar(res.response.txnResultMessage);
    
    })

  }
  
  openSnackBar(message: string) {
    this.snackbar.open(message, 'Close', {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'bottom',
    });
  }

  // now pasw change and otp validate in one method
 validateOtp() {
    var formData = this.resetPasswordForm.value;
    console.log("formData.email " , formData.email)
   console.log("this.resetPasswordForm.newPassword.valid " , this.resetPasswordForm.controls.newPassword.valid)

   //password validation :
   if(!this.validatePassword(formData.newPassword)){
    this.dialogRef.close();

    this.userService.goToSSOPage()
  }

    if(this.resetPasswordForm.controls.newPassword.valid && this.resetPasswordForm.controls.confirmPassword.valid){
    
      
    var data = {
      email : this.email,
      mobile : this.mobile,
      newPassword: sha512(formData.newPassword),
      resetPasswordToken: localStorage.getItem('resetPasswordToken'),
      // emailOtp : this.otpForm.value.otp,
      mobileOtp : this.otpForm.value.sms,
      requestType: 'password-reset'
    }

    console.log(data);

      this.userService.resetPassword(data).subscribe({
        next: (resp:any) => {
          //  this.dialogRef.close();
          console.log("resetP : ", resp);
       

          // if(resp==="Password reset successfully."){
          //   this.dialogRef.close();
          //   this.snackbar.open("Password reset successfully. Please relogin with new password.", 'Dismiss', {
          //     duration: 3000,
          //   });
          // }

          if(resp === "" || resp === null){
            this.dialogRef.close();
            this.snackbar.open("Something went wrong. Please try again.", 'Dismiss', {
              duration: 3000,
            });
          }
          else if(resp.includes("You have exceeded time limit!")   
                || resp.includes("OTP limit exhausted!")
                || resp.includes("OTP verification timeout reached!")
                || resp.includes("You have exceeded maximum attempts.")
                || resp.includes("You have exceeded limit")
                || resp.includes("Please enter correct OTP")){
            this.dialogRef.close();
            this.openSnackBar(resp);

            this.userService.goToSSOPage()
            // window.location.reload();
          }
          else{
            this.dialogRef.close();
            this.snackbar.open("Password reset successfully. Please relogin with new password.", 'Dismiss', {
              duration: 3000,
            });
          }
          console.log();
          
          this.openSnackBar(resp);
          
        },
        error: (error) => {
          
          this.dialogRef.close();
          // window.location.reload();
          console.log("ERROR : RELOADING...")
          this.userService.goToSSOPage()
        }
      });

    }
    else{
      this.openSnackBar("Please Enter Valid Password ex - Abcd@123");
    }
    
    // this.userService.validateEmailOtp(formData.email,formData.mobile,this.type,this.otp,this.sms).subscribe({
    //   next: (resp: any) => {
     
    //     if(resp){
    //       if(resp==="Otp match successfull"){
    //         this.openSnackBar(resp);
    //         this.handleSubmit();
    //       }
    //       if(resp==="Incorrect otp"){
    //         // this.openSnackBar(resp);
    //         this.otpAttemptCount++;
    //         if(this.otpAttemptCount==1){
    //           this.openSnackBar(resp + ' Two More Attempt left ');
    //         }
    //         if(this.otpAttemptCount==2){
    //           this.openSnackBar(resp + ' One More Attempt left ');
    //         }
    //         if(this.otpAttemptCount==3){
    //           this.openSnackBar(resp + ' Exceed attemps ');
    //           this.dialogRef.close();
    //         }
    //       }
    //     }
    //   },
    //   error: (error) => {
    //     console.log(error.message);
    //   }
    // })
  }

  otpTimer(){
    let currentDate = new Date();
  
  // Add 5 minutes to the current time
  currentDate.setTime(currentDate.getTime() + 5 * 60000); // 5 minutes * 60000 milliseconds per minute
  
  console.log(currentDate);
  // Set the date we're counting down to
  let countDownDate = new Date(currentDate).getTime();
  
  // Update the count down every 1 second
  this.intervalId = setInterval(function() {
  
    // Get today's date and time
    var now = new Date().getTime();
  
    // Find the distance between now and the count down date
    var distance = countDownDate - now;
  
    // Time calculations for days, hours, minutes and seconds
    // var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    // var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
  
    var minutes1 = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds1 = Math.floor((distance % (1000 * 60)) / 1000);
  
    // Display the result in the element with id="demo"
    // document.getElementById("demo").innerHTML =  minutes + "m " + seconds + "s ";
    document.getElementById("demo1").innerHTML =  minutes1 + "m " + seconds1 + "s ";
    // this.yourFunction();
    // If the count down is finished, write some text
    // if (distance < 0) {
    //   clearInterval(x);
    //   this.openSnackBar("Please Re-Enter Valid password");
    //   document.getElementById("demo").innerHTML = "EXPIRED";
    // }
    // this.yourFunction();
  }, 1000);
  
  
    this.intervalId1 = setInterval(() => {
      // this.yourFunction();
      this.yourFunction1();
    }, 1000);
  
  
  }
  
  // yourFunction() {
  // let time =  document.getElementById("demo").innerText;
  // console.log("time is " , time)
  //   if(time==="0m 0s"){
  //     this.openSnackBar("Time Expired");
  //     window.location.reload();
  //   }
  //   // Add your logic here
  // }
  
  yourFunction1() {
    let time =  document.getElementById("demo1").innerText;
    // console.log("time is " , time)
      if(time==="0m 0s"){

        this.openSnackBar("Time limit reached! Please try again.");
        // window.location.reload();
        this.userService.goToSSOPage()
      }

      if(time < "0m 0s"){
        this.openSnackBar("Time limit reached! Please try again.");
        // window.location.reload();
        this.userService.goToSSOPage();
      }
    }
  
  
  close(){
    console.log("closed")
    this.startTimer = false;
    clearInterval(this.intervalId);
    clearInterval(this.intervalId1);
  }


  //password validation : 
  validatePassword(password: string): boolean {
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,16}$/;
    return regex.test(password);
  }

}


