package com.ndml.user_module.request;

public class OTPRequestBean {

	private String email;
	private String mobile;
	private String requestType;

	public String getMobileNo() {
		return mobile;
	}

	public void setMobile(String mobileNo) {
		this.mobile = mobileNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String emailId) {
		this.email = emailId;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	@Override
	public String toString() {
		return "OTPRequestBean [email=" + email + ", mobile=" + mobile + ", requestType=" + requestType + "]";
	}

}
