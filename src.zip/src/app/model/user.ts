export class User {
    useremail: string;
    capQues:string;
    capAns:string;
}