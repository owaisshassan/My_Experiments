import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SnackbarMessageboxComponent } from './snackbar-messagebox.component';

describe('SnackbarMessageboxComponent', () => {
  let component: SnackbarMessageboxComponent;
  let fixture: ComponentFixture<SnackbarMessageboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SnackbarMessageboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SnackbarMessageboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
