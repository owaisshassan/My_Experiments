package com.ndml.user_module.request;

public class OTPValidationRequestBean {

	private String mobileNo;
	private String emailId;
	private String requestType;
	private String otp;
	private String validateFlag;

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public String getValidateFlag() {
		return validateFlag;
	}

	public void setValidateFlag(String validateFlag) {
		this.validateFlag = validateFlag;
	}

	@Override
	public String toString() {
		return "OTPValidationRequestBean [mobileNo=" + mobileNo + ", emailId=" + emailId + ", requestType="
				+ requestType + ", otp=" + otp + ", validateFlag=" + validateFlag + "]";
	}

}
