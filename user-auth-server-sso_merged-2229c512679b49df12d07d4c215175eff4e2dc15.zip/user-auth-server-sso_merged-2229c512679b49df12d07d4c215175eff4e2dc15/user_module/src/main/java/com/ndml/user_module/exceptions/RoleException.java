package com.ndml.user_module.exceptions;

public class RoleException extends RuntimeException{
	
	public RoleException() {
		// TODO Auto-generated constructor stub
	}
	
	public RoleException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
	
	

}
