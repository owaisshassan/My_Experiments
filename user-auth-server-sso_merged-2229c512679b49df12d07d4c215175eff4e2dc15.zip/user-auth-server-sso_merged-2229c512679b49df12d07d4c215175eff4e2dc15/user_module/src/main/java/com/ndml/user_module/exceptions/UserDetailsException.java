package com.ndml.user_module.exceptions;

public class UserDetailsException extends RuntimeException{
	
	public UserDetailsException() {
		// TODO Auto-generated constructor stub
	}
	
	public UserDetailsException(String m) {
		// TODO Auto-generated constructor stub
		super(m);
	}

}
