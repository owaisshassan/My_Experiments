package com.ndml.user_module.request;

public class AddUrlRequest {

//	private String userEmail;

	private String newUrl;

	private String urlDescription;

	public String getNewUrl() {
		return newUrl;
	}

	public void setNewUrl(String newUrl) {
		this.newUrl = newUrl;
	}

	public String getUrlDescription() {
		return urlDescription;
	}

	public void setUrlDescription(String urlDescription) {
		this.urlDescription = urlDescription;
	}

	public AddUrlRequest(String newUrl, String urlDescription) {
		super();
		this.newUrl = newUrl;
		this.urlDescription = urlDescription;
	}

	@Override
	public String toString() {
		return "AddUrlRequest [newUrl=" + newUrl + ", urlDescription=" + urlDescription + "]";
	}

}
