package com.ndml.user_module.request;

public class RefreshTokenRequest {

	private String jwt;

	private String email;

	public String getJwt() {
		return jwt;
	}

	public void setJwt(String jwt) {
		this.jwt = jwt;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "RefreshTokenRequest [jwt=" + jwt + ", email=" + email + "]";
	}

}
