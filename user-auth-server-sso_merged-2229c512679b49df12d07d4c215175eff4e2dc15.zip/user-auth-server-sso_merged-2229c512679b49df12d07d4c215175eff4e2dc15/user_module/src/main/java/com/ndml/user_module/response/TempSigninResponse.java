package com.ndml.user_module.response;

import java.util.Date;
import java.util.List;

public class TempSigninResponse {

	private long userid;

	private String useremail;

	private String username;

	private String roleName;

	private String roleDescription;

	private String application_name;

	private List<CustomResponseMenuMaster> menuList;

	private String accessToken;

	private Date tokenExpDate;

	private String sessionKey;

	public Date getTokenExpDate() {
		return tokenExpDate;
	}

	public void setTokenExpDate(Date tokenExpDate) {
		this.tokenExpDate = tokenExpDate;
	}

	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}

	public String getUseremail() {
		return useremail;
	}

	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleDescription() {
		return roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	public String getApplication_name() {
		return application_name;
	}

	public void setApplication_name(String application_name) {
		this.application_name = application_name;
	}

//	public List<TempMenuClass> getMenuList() {
//		return menuList;
//	}
//
//	public void setMenuList(List<TempMenuClass> menuList) {
//		this.menuList = menuList;
//	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getSessionKey() {
		return sessionKey;
	}

	public void setSessionKey(String sessionKey) {
		this.sessionKey = sessionKey;
	}

	public TempSigninResponse(long userid, String useremail, String username, String roleName, String roleDescription,
			String application_name, List<CustomResponseMenuMaster> menuList, String accessToken, String sessionKey) {
		super();
		this.userid = userid;
		this.useremail = useremail;
		this.username = username;
		this.roleName = roleName;
		this.roleDescription = roleDescription;
		this.application_name = application_name;
		this.menuList = menuList;
		this.accessToken = accessToken;
		this.sessionKey = sessionKey;
	}

	public TempSigninResponse(long userid, String useremail, String username, String roleName, String roleDescription,
			String application_name, List<CustomResponseMenuMaster> menuList, String accessToken, Date tokenExpDate,
			String sessionKey) {
		super();
		this.userid = userid;
		this.useremail = useremail;
		this.username = username;
		this.roleName = roleName;
		this.roleDescription = roleDescription;
		this.application_name = application_name;
		this.menuList = menuList;
		this.accessToken = accessToken;
		this.tokenExpDate = tokenExpDate;
		this.sessionKey = sessionKey;
	}

//	public TempSigninResponse(long userid, String useremail, String username, String roleName, String roleDescription,
//			String application_name, List<TempMenuClass> menuList, String accessToken, String sessionKey) {
//		super();
//		this.userid = userid;
//		this.useremail = useremail;
//		this.username = username;
//		this.roleName = roleName;
//		this.roleDescription = roleDescription;
//		this.application_name = application_name;
//		this.menuList = menuList;
//		this.accessToken = accessToken;
//		this.sessionKey = sessionKey;
//	}

	public List<CustomResponseMenuMaster> getMenuList() {
		return menuList;
	}

	public void setMenuList(List<CustomResponseMenuMaster> menuList) {
		this.menuList = menuList;
	}

	@Override
	public String toString() {
		return "TempSigninResponse [userid=" + userid + ", useremail=" + useremail + ", username=" + username
				+ ", roleName=" + roleName + ", roleDescription=" + roleDescription + ", application_name="
				+ application_name + ", menuList=" + menuList + ", accessToken=" + accessToken + ", tokenExpDate="
				+ tokenExpDate + ", sessionKey=" + sessionKey + "]";
	}

}
