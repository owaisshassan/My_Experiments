package com.ndml.user_module.services;



import com.ndml.user_module.response.ActiveUserResponse;


public interface ActiveUsersService {
	
	public ActiveUserResponse isUserSessionActive(String username,String sessionToken, String decryptKey);

}
