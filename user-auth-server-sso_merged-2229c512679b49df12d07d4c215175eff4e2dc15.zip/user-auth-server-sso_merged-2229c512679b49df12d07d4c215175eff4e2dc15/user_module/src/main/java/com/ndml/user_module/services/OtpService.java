package com.ndml.user_module.services;

import org.springframework.stereotype.Service;

import com.ndml.user_module.request.OTPRequestBean;
import com.ndml.user_module.request.OTPValidationRequestBean;
import com.ndml.user_module.response.FetchOtpDetailsResponse;
import com.ndml.user_module.response.ValidateOtpResponse;

@Service
public interface OtpService {

	FetchOtpDetailsResponse fetchOtpDetails(OTPRequestBean requestBean) throws Exception;

	ValidateOtpResponse validateOtp(OTPValidationRequestBean requestBean) throws Exception;

}
