package com.ndml.user_module.services;

import javax.servlet.http.HttpServletRequest;

import com.ndml.user_module.exceptions.ApplicationException;
import com.ndml.user_module.request.ApplicationRegisterRequest;

public interface ApplicationMasterService {
	
	public String addNewApplication(ApplicationRegisterRequest appRegisterRequest,HttpServletRequest http) throws ApplicationException;
	
	public String updateApplicationName(String oldAppName, String newAppName) throws ApplicationException;

}
