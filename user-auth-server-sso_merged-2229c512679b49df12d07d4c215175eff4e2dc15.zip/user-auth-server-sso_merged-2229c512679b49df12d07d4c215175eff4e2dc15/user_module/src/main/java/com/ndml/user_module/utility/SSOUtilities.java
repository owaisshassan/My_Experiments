package com.ndml.user_module.utility;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.UUID;

import com.ndml.user_module.constants.SSOConstants;
import com.ndml.user_module.response.OtpResponseBean;
import com.ndml.user_module.response.TransactionBean;

public class SSOUtilities {

	public static <T> OtpResponseBean<T> getResponseBean(String txnProcessCode, String txnProcessMessage,
			String txnResultCode, String txnResultMessage, T data) {
		OtpResponseBean<T> responseBean = new OtpResponseBean<T>();
		TransactionBean transactionBean = new TransactionBean();
		transactionBean.setTxnProcessCode(txnProcessCode);
		transactionBean.setTxnProcessMessage(txnProcessMessage);
		transactionBean.setTxnResultCode(txnResultCode);
		transactionBean.setTxnResultMessage(txnResultMessage);
		responseBean.setResponse(transactionBean);
		responseBean.setData(data);
		return responseBean;
	}

	public static String showRandomInteger() {
		Calendar cal = Calendar.getInstance();
		cal.setTime(new java.util.Date());
		int d = cal.get(Calendar.DAY_OF_MONTH);
		int m = cal.get(Calendar.MINUTE);
		int s = cal.get(Calendar.SECOND);
		int ms = cal.get(Calendar.MILLISECOND);
		int v = (m % 10) * 1235 + s * 79 + ms * 982 + d;
		return String.format("%06d", v);
	}

	public static String generateTimestamp() {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(SSOConstants.TIMESTAMP_FORMAT);
		return simpleDateFormat.format(new java.util.Date());
	}
	
	public static String generateUniqueKeyUsingUUID() {
		return UUID.randomUUID().toString();
	}

}
