package com.ndml.user_module.services.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Logger;

import javax.crypto.SecretKey;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
//import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.stereotype.Service;

import com.ndml.user_module.configuration.SecurityConstants;
import com.ndml.user_module.exceptions.ApplicationException;
import com.ndml.user_module.exceptions.MenuMasterException;
import com.ndml.user_module.exceptions.RoleException;
import com.ndml.user_module.exceptions.RoleMenuMapperException;
import com.ndml.user_module.exceptions.UserDetailsException;
import com.ndml.user_module.model.ApplicationMaster;
import com.ndml.user_module.model.MenuMaster;
import com.ndml.user_module.model.RoleMenuMapper;
import com.ndml.user_module.model.UserDetails;
import com.ndml.user_module.repositories.ApplicationMasterRepository;
import com.ndml.user_module.repositories.MenuMasterRepository;
import com.ndml.user_module.repositories.RoleMenuMapperRepository;
import com.ndml.user_module.repositories.UserRepository;
import com.ndml.user_module.request.GetMenuDetailsRequest;
import com.ndml.user_module.request.MenuMasterRegisterRequest;
import com.ndml.user_module.services.MenuMasterService;
import com.ndml.user_module.utility.JwtCacheUtil;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Service
public class MenuMasterServiceImpl implements MenuMasterService {

	Logger log = Logger.getLogger(MenuMasterServiceImpl.class.getName());

	@Autowired
	private MenuMasterRepository menuMasterRepo;

	@Autowired
	private ApplicationMasterRepository applicationMasterRepo;

	@Autowired
	private UserRepository userRepo;


	@Autowired
	private RoleMenuMapperRepository roleMenuMapperRepo;
//
//	@Autowired
//	private static CustomPasswordEncoder encoder;

	@Value("${ndml.menumaster.isActive}")
	private boolean isMenumasterActive;

	@Value("${ndml.app.jwtSecret}")
	private String jwtSecret;

	@Override
	public MenuMaster addNewMenu(MenuMasterRegisterRequest request) throws MenuMasterException {

		String upperCaseMenu = request.getMenuName().toUpperCase();

		Optional<MenuMaster> opt = menuMasterRepo.findByMenuName(upperCaseMenu);
		if (opt.isPresent())
			throw new MenuMasterException("This Menu already exists! Try Again!");

		Optional<ApplicationMaster> appMasterOpt = applicationMasterRepo.findById(request.getApplicationId());

		log.info("application id from request : " + request.getApplicationId());

		if (!appMasterOpt.isPresent())
			throw new ApplicationException("Please enter valid ApplicationID.");

		if (!appMasterOpt.get().isActive())
			throw new ApplicationException("Application with '" + request.getApplicationId() + "' is not Active.");

		// checking if Menu is present for provided parentID :
		log.info("parentid: " + request.getMenuParentId());
		log.info("desc: " + request.getMenuDescription());
		log.info("do: " + request.getDisplayOrder());
//	if(request.getMenuParentId() != 0)
		Optional<MenuMaster> check = menuMasterRepo.findById(request.getMenuParentId());
		if (!check.isPresent())
			throw new MenuMasterException("Please Provide a valid ParentID..");

		// check for duplicate display-order :
		List<MenuMaster> menuListOfParentIds = menuMasterRepo.findByMenuParentId(request.getMenuParentId());
		log.info("check point..");
		System.out.println(menuListOfParentIds);
		for (int i = 0; i < menuListOfParentIds.size(); i++) {

			if (menuListOfParentIds.get(i).getDisplayOrder() == request.getDisplayOrder()
					&& menuListOfParentIds.get(i).getApplicationId() == request.getApplicationId()) {
				throw new MenuMasterException("Display order is already taken.. Try another one..");
			}

		}

		// if Application is active, then only we can proceed to add Menu:
		MenuMaster menuMaster = new MenuMaster(upperCaseMenu, request.getMenuDisplayName(), request.getMenuParentId(),
				request.getMenuDescription(), request.getApplicationId(), appMasterOpt.get().isActive());
		menuMaster.setDisplayOrder(request.getDisplayOrder());
		menuMaster.setRoutingUrl(appMasterOpt.get().getApplicationName() + "/home");
		menuMaster.setCrtdDt(new Date());
		menuMasterRepo.save(menuMaster);

		return menuMaster;
	}

	@Override
	// @Cacheable(value = "menudetails", key = "#request.getEmail()")
	public List<MenuMaster> getMenuDetailsThroughRoleMenuMapper(GetMenuDetailsRequest request)
			throws MenuMasterException, RoleMenuMapperException, RoleException, UserDetailsException {
		// TODO Auto-generated method stub

		// doWait();

		log.info("Inside 'getMenuDetailsThroughRoleMenuMapper' ... ");
		List<MenuMaster> result = new ArrayList<>();

		UserDetails user = userRepo.findByUseremailId(request.getEmail());
		
		if (user == null)
			throw new UserDetailsException("No user found with this Email!");

		if (user.isLocked())
			throw new UserDetailsException("Sorry this user is currently unavailable!");

		Optional<ApplicationMaster> appOpt = applicationMasterRepo.findById(user.getApplicationid());
		if (!appOpt.get().isActive())
			throw new MenuMasterException("");

		log.info(user.getUseremailId());
//	
//			if(!encoder.matches(request.getPassword(), user.getPassword()))
//				throw new BadCredentialsException("Please check your password!");

		Optional<RoleMenuMapper> roleMenuMapperOpt = roleMenuMapperRepo.findById(user.getRoleId());
		if (!roleMenuMapperOpt.isPresent())
			throw new RoleMenuMapperException("No Menu has been assigned to this Role.");

		RoleMenuMapper roleMenuMapper = roleMenuMapperOpt.get();
		if (roleMenuMapper.getMenulist().size() == 0)
			throw new RoleMenuMapperException("Currently, this Role has no Menu assigned to it.");
		for (String i : roleMenuMapper.getMenulist()) {
			long id=Long.parseLong(i);  
			Optional<MenuMaster> mm = menuMasterRepo.findById(id);
			
			if (mm.isPresent()) {
				MenuMaster menuMaster = mm.get();
				System.out.println("Menu-List for this Role :");
				System.out.println(menuMaster);
				result.add(menuMaster);
			}else System.out.println("No menu present with id : "+id);
				
		}

		return result;
	}

	private void doWait() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// Custom method for checking if the user is logged out ? / to check Session
	// expiry :

	public boolean isLoggedOut(String email, HttpServletRequest http) {

		boolean loggedOutBool = false;

		String jwt = http.getHeader(SecurityConstants.JWT_HEADER);

		log.info("JWT in 'isLoggedOut' = " + jwt);

		try {
			// extracting the word 'Bearer':
			jwt = jwt.substring(7);

			log.info("JWT without bearer in 'isLoggedOut' = " + jwt);
			// SecretKey key = Keys.hmacShaKeyFor(SecurityConstants.JWT_KEY.getBytes());
			SecretKey key = Keys.hmacShaKeyFor(Decoders.BASE64.decode(jwtSecret));

			Claims claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(jwt).getBody();

			String username = String.valueOf(claims.get("username"));

			log.info("Username from claims in 'isLoggedOut' = " + username);

			if (email.equals(username)) {
				log.info("username & Email matches!!!!!");

				Map<String, Map<String, Date>> mapper = JwtCacheUtil.getUserNameJwtMapper();
				if (mapper.containsKey(email)) {
					log.info("Email is present in mapper -- ('isLoggedOut')");
					Map<String, Date> jwtDateMapper = mapper.get(email);
					if (jwtDateMapper.containsKey(jwt)) {
						log.info("USER_JWT mapper CACHE Still Present, Not logged Out!");
					} else
						loggedOutBool = true;
				} else
					loggedOutBool = true;

			} else
				throw new Exception("Provided Email doesn't match!");

		} catch (Exception e) {
			throw new BadCredentialsException("Invalid Token received!");
		}

		return loggedOutBool;

	}
}
