package com.ndml.user_module.services;

public interface RoleMasterService {
	
	public String addApp09UserRole() throws Exception;
	
	public String addApp09CheckerRole() throws Exception;
	
	public String addApp09MakerRole() throws Exception;
	
	public String addApp10UserRole() throws Exception;
	
	public String addApp10CheckerRole() throws Exception;
	
	public String addApp10MakerRole() throws Exception;
	
	public String addApp11UserRole() throws Exception;
	
	public String addApp11CheckerRole() throws Exception;
	
	public String addApp11MakerRole() throws Exception;


}
