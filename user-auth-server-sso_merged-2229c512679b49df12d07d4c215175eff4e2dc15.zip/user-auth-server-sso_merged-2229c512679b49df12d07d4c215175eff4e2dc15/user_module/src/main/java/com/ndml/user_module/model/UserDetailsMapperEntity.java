package com.ndml.user_module.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@NoArgsConstructor
@ToString
public class UserDetailsMapperEntity {

	@Id
	@Column(unique = true)
	private String userEmail;
	private String mobileNumber;
	private String dpId;
	private long applicationId;
	private long roleId;
	private int loginAttempts;

	@Column(name = "last_login_list")
	private String lastLoginList;

	@Column(name = "jwt_list")
	private String jwtList;

	@Column(name = "token_expiry_list")
	private String tokenExpiryList;

	private String crtdDt;

	@Column(name = "updt_dt_list")
	private String updtDtList;

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getDpId() {
		return dpId;
	}

	public void setDpId(String dpId) {
		this.dpId = dpId;
	}

	public long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}

	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public int getLoginAttempts() {
		return loginAttempts;
	}

	public void setLoginAttempts(int loginAttempts) {
		this.loginAttempts = loginAttempts;
	}

	public List<String> getJwtList() {
		if (jwtList == null) {
			return new ArrayList<>();
		}
		return Arrays.asList(jwtList.replaceAll("\"", "").split(","));
	}

	public void setJwtList(List<String> jwtList) {
		this.jwtList = String.join(",", jwtList);
	}

	public List<String> getTokenExpiryList() {
		if (tokenExpiryList == null) {
			return new ArrayList<>();
		}
		return Arrays.asList(tokenExpiryList.replaceAll("\"", "").split(","));
	}

	public void setTokenExpiryList(List<String> tokenExpiryList) {
		this.tokenExpiryList = String.join(",", tokenExpiryList);
	}

	public String getCrtdDt() {
		return crtdDt;
	}

	public void setCrtdDt(String crtdDt) {
		this.crtdDt = crtdDt;
	}

	public List<String> getLastLoginList() {
		if (lastLoginList == null) {
			return new ArrayList<>();
		}
		return Arrays.asList(lastLoginList.replaceAll("\"", "").split(","));
	}

	public void setLastLoginList(List<String> lastLoginList) {
		this.lastLoginList = String.join(",", lastLoginList);
	}

	public List<String> getUpdtDtList() {
		if (updtDtList == null) {
			return new ArrayList<>();
		}
		return Arrays.asList(updtDtList.replaceAll("\"", "").split(","));
	}

	public void setUpdtDtList(List<String> updtDtList) {
		this.updtDtList = String.join(",", updtDtList);
	}

	public UserDetailsMapperEntity(String userEmail, String mobileNumber, String dpId, long applicationId, long roleId,
			int loginAttempts, List<String> lastLoginList, List<String> jwtList, List<String> tokenExpiryList,
			String crtdDt, List<String> updtDtList) {
		super();
		this.userEmail = userEmail;
		this.mobileNumber = mobileNumber;
		this.dpId = dpId;
		this.applicationId = applicationId;
		this.roleId = roleId;
		this.loginAttempts = loginAttempts;
		this.lastLoginList = lastLoginList.stream().collect(Collectors.joining(","));
		this.jwtList = jwtList.stream().collect(Collectors.joining(","));
		this.tokenExpiryList = tokenExpiryList.stream().collect(Collectors.joining(","));
		;
		this.crtdDt = crtdDt;
		this.updtDtList = updtDtList.stream().collect(Collectors.joining(","));
		;
	}

}
