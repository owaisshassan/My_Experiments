package com.ndml.user_module.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ndml.user_module.model.UserDetailsMapperEntity;

public interface UserDetailsMapperRepository extends JpaRepository<UserDetailsMapperEntity, String>{

	@Query(value = "select * from user_details_mapper_entity u where u.user_email = ?1", nativeQuery = true)
	public UserDetailsMapperEntity findByUserEmail(String userEmail);
	
	
}
