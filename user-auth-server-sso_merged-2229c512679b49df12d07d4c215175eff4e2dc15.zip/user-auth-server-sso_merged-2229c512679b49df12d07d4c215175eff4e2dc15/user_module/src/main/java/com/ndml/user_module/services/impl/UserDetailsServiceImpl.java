package com.ndml.user_module.services.impl;

import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import javax.crypto.SecretKey;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.ndml.user_module.configuration.SecurityConstants;
import com.ndml.user_module.constants.SSOConstants;
import com.ndml.user_module.exceptions.ApplicationException;
import com.ndml.user_module.exceptions.LoginException;
import com.ndml.user_module.exceptions.LogoutException;
import com.ndml.user_module.exceptions.NotFoundException;
import com.ndml.user_module.exceptions.PasswordExpiryException;
import com.ndml.user_module.exceptions.RoleException;
import com.ndml.user_module.exceptions.RoleMenuMapperException;
import com.ndml.user_module.exceptions.UserDetailsException;
import com.ndml.user_module.jwt.JwtUtils;
import com.ndml.user_module.model.ApplicationMaster;
import com.ndml.user_module.model.DPMaster;
import com.ndml.user_module.model.EndPointsMaster;
import com.ndml.user_module.model.MenuMaster;
import com.ndml.user_module.model.OTPDetails;
//import com.ndml.user_module.model.OldPasswords;
import com.ndml.user_module.model.OldPasswordsEntity;
import com.ndml.user_module.model.RoleMaster;
import com.ndml.user_module.model.RoleMenuMapper;
import com.ndml.user_module.model.UserDetails;
import com.ndml.user_module.model.UserDetailsMapperEntity;
import com.ndml.user_module.repositories.ApplicationMasterRepository;
import com.ndml.user_module.repositories.DPMasterRepository;
import com.ndml.user_module.repositories.EndPointsRepository;
import com.ndml.user_module.repositories.MenuMasterRepository;
import com.ndml.user_module.repositories.OldPasswordsRepository;
import com.ndml.user_module.repositories.OneTimePasswordRepository;
import com.ndml.user_module.repositories.RoleMasterRepository;
import com.ndml.user_module.repositories.RoleMenuMapperRepository;
import com.ndml.user_module.repositories.UserDetailsMapperRepository;
import com.ndml.user_module.repositories.UserRepository;
import com.ndml.user_module.request.ForgotPasswordRequest;
import com.ndml.user_module.request.GetMenuDetailsRequest;
import com.ndml.user_module.request.LoginRequest;
import com.ndml.user_module.request.OTPValidationRequestBean;
import com.ndml.user_module.request.RequestNewResetPassword;
import com.ndml.user_module.response.CustomResponseMenuMaster;
import com.ndml.user_module.response.GetPwrdSaltResponseBean;
import com.ndml.user_module.response.GetUserDetailsResponse;
import com.ndml.user_module.response.ResetPasswordResponseBean;
import com.ndml.user_module.response.SigninResponse;
import com.ndml.user_module.response.SigninResponseBean;
import com.ndml.user_module.response.ValidateOtpResponse;
import com.ndml.user_module.services.MenuMasterService;
import com.ndml.user_module.services.OtpService;
import com.ndml.user_module.services.UserDetailsService;
import com.ndml.user_module.utility.CustomJwtSecretKeyPair;
import com.ndml.user_module.utility.EncryptDecrypt;
import com.ndml.user_module.utility.JwtCacheUtilWithEncryptKey;
import com.ndml.user_module.utility.JwtExtractorUtil;
import com.ndml.user_module.utility.SSOUtilities;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	Logger logger = Logger.getLogger(UserDetailsServiceImpl.class.getName());

	@Autowired
	private UserRepository userRepository;

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	private DPMasterRepository dpRepo;

	@Autowired
	private RoleMasterRepository roleMasterRepo;

	@Autowired
	private RoleMenuMapperRepository rmmRepo;

	@Autowired
	private MenuMasterService menuMasterService;

	@Autowired
	private ApplicationMasterRepository applicationMasterRepo;

	@Autowired
	private MenuMasterRepository menuMasterRepo;

	@Autowired
	private UserDetailsMapperRepository udmRepo;

	@Autowired
	private EndPointsRepository epRepo;

	@Autowired
	private JwtUtils jwtUtils;

	protected static int numberOfLoginAttempts = 0;

	protected static Date userLoginLockedTime;

	@Value("${ndml.app.jwtSecret}")
	private String jwtSecret;

	@Value("${ndml.app.passExpiryDate}")
	private long passExpDateMS; 
	
	@Value("${ndml.app.userLockTime}")
	private long userLockTime;
	
	@Value("${ndml.app.maxLoginsAllowed}")
	private long maxLoginsAllowed;

	@Value("${ndml.app.maxLoginAttemptsAllowed}")
	private long maxLoginAttemptsAllowed;
	
	
	@Autowired
	MessageSource messageSource;

	
	@Autowired
	private OldPasswordsRepository oldPasswordRepo;
	
	@Autowired
	private OtpService otpValidatorService;
	
	@Override
	public SigninResponseBean dacLogin(LoginRequest loginRequest, HttpServletRequest http, HttpServletResponse response)
			throws Exception {

		logger.info("loginReq email : " + loginRequest.getEmail());
		logger.info("loginReq pass : " + loginRequest.getPassword());

		if (!userRepository.existsByUseremailId(loginRequest.getEmail()))
			throw new LoginException("Please check your email!");

		UserDetails user = userRepository.findByUseremailId(loginRequest.getEmail());

		logger.info("db pass :" + user.getPassword());
		
		String loginHashedPassword = loginRequest.getPassword().substring(0,loginRequest.getPassword().length()-16);
		String pwd_salt = loginRequest.getPassword().substring(loginRequest.getPassword().length()-16,loginRequest.getPassword().length());
		
//		String loginHashedPassword =  get512Hash(loginRequest.getPassword());
		System.out.println("loginHashedPassword below : ");
		System.out.println(loginHashedPassword);
		System.out.println("pwd_salt below : ");
		System.out.println(pwd_salt);
		
		//checking pwd_salt in db : 
		if(user.getPasswordSalt() != null && !user.getPasswordSalt().equals(pwd_salt))
			throw new LoginException("Please check your email!");
		

		
		if (user.isLocked())
		throw new LoginException(messageSource.getMessage("error.user.locked", null, Locale.ENGLISH));
		
		if (!loginHashedPassword.equals(user.getPassword())) {
			
			String userUpdtDate = convertToLocalDateTimeViaSqlTimestamp(new Date()).toString();
			System.out.println("userUpdtDate :" + userUpdtDate); // 2023-08-24T17:45:09.505
			String userNewUpdtDate = userUpdtDate.replace("T", " ");
			logger.info("Setting new userUpdtDate in db..");
			
			user.setLoginAttempt(user.getLoginAttempt() + 1);
			
			
			user.setUpdtDt(userNewUpdtDate);
			userRepository.save(user);
			
			if(user.getLoginAttempt() >= maxLoginAttemptsAllowed) {
				user.setLocked(true);
				user.setUpdtDt(userNewUpdtDate);
				userRepository.save(user);
				throw new LoginException("Maximum attempts reached! User is locked.");
			}
			
			
			
			long attemptsLeft = maxLoginAttemptsAllowed - user.getLoginAttempt();
			
			String msg = "";
			if(attemptsLeft == 1) {
				msg = "Incorrect login credential! Only " +attemptsLeft + " attempt left now.";
			}else {
				msg = "Incorrect login credential! Only " +attemptsLeft + " attempts left now.";
			}
			
			
			
			throw new LoginException(msg);
		}


//		Authentication authentication = authenticationManager.authenticate(
//				new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword()));
		
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginHashedPassword));

		UserDetails uv = userRepository.findByUseremailId(loginRequest.getEmail());
		logger.info("user : " + uv);
		long roleid = uv.getRoleId();
		logger.info(" roleId : " + roleid);
		RoleMaster rr = roleMasterRepo.findById(roleid).get();
		logger.info(" Role : " + rr);

		RoleMaster role = roleMasterRepo.findById(userRepository.findByUseremailId(loginRequest.getEmail()).getRoleId())
				.get();

		String appName = applicationMasterRepo.findById(user.getApplicationid()).get().getApplicationName();

		String appRole = appName + "_" + role.getRoleName();
		String appRoleDesc = role.getRoleDescription();
		Collection<? extends GrantedAuthority> userGrantedAuths = getAuthorities(appRole, appRoleDesc);


		logger.info("authorities from 'userDetailsimpl' : " + userGrantedAuths);

		authentication = new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), "", userGrantedAuths);

		SecurityContext context = SecurityContextHolder.createEmptyContext();
		context.setAuthentication(authentication);
		SecurityContextHolder.setContext(context);

		// SecurityContextHolder.getContext().setAuthentication(authentication);

		logger.info("jwt generation STARTS , inside controller");

		Optional<DPMaster> dp = dpRepo.findByDpID(user.getDpID());
		String dpName = dp.get().getDPName();

		String jwt = jwtUtils.generateJwtToken(authentication, user.getDpID(), dpName);

		logger.info("jwt generation ENDS , inside controller");

		DecodedJWT decodedJWT = JWT.decode(jwt);
		Date date = decodedJWT.getExpiresAt();

		logger.info("EXPIRY DATE : " + date);
		logger.info("CLAIMS : " + decodedJWT.getClaims());
		logger.info("authentication principal : " + authentication.getPrincipal());

		String dt = convertToLocalDateTimeViaSqlTimestamp(date) + "";
		String d = dt.replace("T", " ");
		logger.info(d);
		logger.info("''''''''''''''''''''''''''''''''''''''''''''''");

		// ----------------AES encryption STARTS-----------------
		logger.info("AES encryption STARTS");
		Optional<DPMaster> dpOpt = dpRepo.findByDpID(user.getDpID());
		String encKeyFromUserDpId = dpOpt.get().getEnckey();
		logger.info("ENC-KEY : :  : : :  " + encKeyFromUserDpId);

		String emailPlusJwt = loginRequest.getEmail()+" "+jwt;
		String encryptedJwt = EncryptDecrypt.encryptData(encKeyFromUserDpId, emailPlusJwt);
//		String encryptedJwt = EncryptDecrypt.encryptData(encKeyFromUserDpId, jwt);

		logger.info("AES encryption ENDS");
		// ----------------AES encryption ENDS-----------------

		// ================================================================

		/// response.setHeader(SecurityConstants.JWT_HEADER, hashedJWT);
		CustomJwtSecretKeyPair jwtAndSecretKey = new CustomJwtSecretKeyPair();
		jwtAndSecretKey.setSecretKeyForToken(encKeyFromUserDpId);
		jwtAndSecretKey.setTokenKey(encryptedJwt);
		JwtCacheUtilWithEncryptKey.currentUserjwtCacheDetailsWithkey(authentication.getName(), jwtAndSecretKey, date);

		// Collection<? extends GrantedAuthority> ga = authentication.getAuthorities();

//		UserDetailsImpl userDetails = new UserDetailsImpl(user.getUserid(), user.getUsername(), user.getUseremailId(),
//				user.getPassword(), ga);

		List<String> roles = authentication.getAuthorities().stream().map(item -> item.getAuthority())
				.collect(Collectors.toList());

		logger.info("roles-------- : " + roles);

		// checking if the locked in time has reached to an end :

		String userLastL = convertToLocalDateTimeViaSqlTimestamp(new Date()).toString();
//		String userLastLogin = new Date().toString();
		System.out.println("userLastLogin :" + userLastL); // 2023-08-24T17:45:09.505
		String userLastLogin = userLastL.replace("T", " ");
		if (user.getLastLogin() == null || user.getLastLogin().equals("")) {
			logger.info("Setting new lastLogin in db..");
			user.setLastLogin(userLastLogin);
		}

		logger.info("userLastLogin after replacing T : " + userLastLogin);
		Date currentDate = new Date();
		// 2023-08-07 14:50:46.027
		System.out.println("###########################");
//		SimpleDateFormat formatter = new SimpleDateFormat("EE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);  //Thu Aug 24 17:10:29 IST 2023
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd' 'hh:mm:ss.SSS", Locale.ENGLISH);
		System.out.println("###########################");
		System.out.println("hhbhh: "+user.getLastLogin());
		System.out.println("###########################");
		System.out.println("hhbhh len : "+user.getLastLogin().length());
		String uLL = "";
		Date lastL = formatter.parse(user.getLastLogin());
//		if(user.getLastLogin().length() == 19) {
//			uLL = user.getLastLogin() + "1";
//			lastL = formatter.parse(uLL);
//		}else {
//			lastL = formatter.parse(user.getLastLogin());
//		}
		
		System.out.println("LastL : " + lastL);
//		  SimpleDateFormat print = new SimpleDateFormat("MMM d, yyyy HH:mm:ss"); 
//		  System.out.println(print.format(lastL));
//		 System.out.println("LastLogin : "+lastL);
		logger.info("Current time :  " + currentDate.getTime());
		logger.info("LastLoginTime : " + lastL.getTime());

		logger.info("DIFF :" + (currentDate.getTime() - lastL.getTime()));
		long time_difference = currentDate.getTime() - lastL.getTime();
		logger.info("time_difference : " + time_difference);
		long minutes_difference = (time_difference / (1000 * 60)) % 60;
		logger.info("minutes_difference : " + minutes_difference);
		
//		if ((minutes_difference > userLockTime) && (user.getLoginAttempt() > (maxLoginsAllowed-1))) {
//			user.setLocked(false);
//			user.setLoginAttempt(0);
//			logger.info("user locked --ohb-- false");
//		}
//
//		user.setLocked(false);
//
//			if (user.getLoginAttempt() == maxLoginsAllowed) {
//				user.setLocked(true);
//				user.setActive(false);
//				logger.info("user locked --ohb-- true");
//				logger.info("user active -- false");
//			}
//
//		if (user.isLocked())
//			throw new LoginException("Please try again after " + userLockTime + " minute/s!");

		user.setLoginAttempt(user.getLoginAttempt() + 1);
		logger.info("NUMBER OF LOGIN ATTEMPTS = " + user.getLoginAttempt());
		user.setActive(true);

		String userLLogin = convertToLocalDateTimeViaSqlTimestamp(new Date()).toString();
//		String userLastLogin = new Date().toString();
		System.out.println("userLastLogin :" + userLLogin); // 2023-08-24T17:45:09.505
		String userLastLoginn = userLastL.replace("T", " ");
		user.setLastLogin(userLastLoginn);
		userRepository.save(user);

//		Setting up UserDetailsMapperEntity in db : 
		UserDetailsMapperEntity udmm = udmRepo.findByUserEmail(user.getUseremailId());
		System.out.println("UDMM L308: " + udmm);
		String trimmedEncryptedJwt = (encryptedJwt.substring(0, 6))
				+ (encryptedJwt.substring(encryptedJwt.length() - 6, encryptedJwt.length()));
		if (udmm != null) {
//			System.out.println(udmm.getTokenExpiryList());
			System.out.println("L312 --------------");
			List<String> tokenListFromUdm = udmm.getJwtList();
			if (tokenListFromUdm == null) {
				System.out.println("L315 --------------");
				List<String> newTokenList = new ArrayList<>();
				newTokenList.add(trimmedEncryptedJwt);
				udmm.setJwtList(newTokenList);
			} else {
				System.out.println("L320 --------------");
				System.out.println(tokenListFromUdm);
				System.out.println("trimmedEncryptedJwt : " + trimmedEncryptedJwt);
				List<String> newTokenList = new ArrayList<>();
				for (String tkn : tokenListFromUdm) {
					newTokenList.add(tkn);
				}
				newTokenList.add(trimmedEncryptedJwt);
//					tokenListFromUdm.add(trimmedEncryptedJwt+",");
				udmm.setJwtList(newTokenList);
				System.out.println(newTokenList);
			}
			System.out.println("L321 --------------");

			List<String> expiryListFromUdm = udmm.getTokenExpiryList();
			System.out.println(expiryListFromUdm);
			if (expiryListFromUdm == null) {
				List<String> newExpListUdm = new ArrayList<>();
				newExpListUdm.add(d);
				System.out.println("EXP DATE #1: " + d);
				udmm.setTokenExpiryList(newExpListUdm);
			} else {
				List<String> newExpListUdm = new ArrayList<>();
				for (String dateStr : expiryListFromUdm) {
					newExpListUdm.add(dateStr);
				}
				newExpListUdm.add(d);
				udmm.setTokenExpiryList(newExpListUdm);
				System.out.println("EXP DATE #2.1: " + date);
			}

			List<String> lastLoginListFromUdm = udmm.getLastLoginList();
			if (lastLoginListFromUdm == null) {
				List<String> newLoginListUdm = new ArrayList<>();
				newLoginListUdm.add(userLastLogin);
				udmm.setLastLoginList(newLoginListUdm);
			} else {
				List<String> newLoginListUdm = new ArrayList<>();
				for (String loginStr : lastLoginListFromUdm) {
					newLoginListUdm.add(loginStr);
				}
				newLoginListUdm.add(userLastLogin);
				udmm.setLastLoginList(newLoginListUdm);
			}

			udmm.setLoginAttempts(udmm.getLoginAttempts() + 1);

			List<String> updtDtListFromUdm = udmm.getUpdtDtList();
			if (updtDtListFromUdm == null) {
				List<String> newUpdtDtListUdm = new ArrayList<>();
				newUpdtDtListUdm.add(user.getUpdtDt());
				udmm.setUpdtDtList(newUpdtDtListUdm);
			} else {
				List<String> newUpdtDtListUdm = new ArrayList<>();
				for (String updtStr : updtDtListFromUdm) {
					newUpdtDtListUdm.add(updtStr);
				}
				newUpdtDtListUdm.add(user.getUpdtDt());
				udmm.setUpdtDtList(newUpdtDtListUdm);
			}

			udmRepo.save(udmm);
		} else {
			UserDetailsMapperEntity udm = new UserDetailsMapperEntity();
			udm.setUserEmail(user.getUseremailId());
			udm.setMobileNumber(user.getUsermobileNumber());
			udm.setApplicationId(user.getApplicationid());
			udm.setCrtdDt(user.getCrtdDt());
			udm.setDpId(user.getDpID());
			udm.setRoleId(user.getRoleId());
			List<String> tokenListFromUdm = new ArrayList<>();
			tokenListFromUdm.add(trimmedEncryptedJwt);
			udm.setJwtList(tokenListFromUdm);
			List<String> expiryListUdm = new ArrayList<>();
			expiryListUdm.add(d);
			udm.setTokenExpiryList(expiryListUdm);
			List<String> lastLoginListUdm = new ArrayList<>();
			lastLoginListUdm.add(userLastLogin);
			udm.setLastLoginList(lastLoginListUdm);
			udm.setLoginAttempts(1);
			List<String> updtDtListFromUdm = new ArrayList<>();
			updtDtListFromUdm.add(user.getUpdtDt());
			udm.setUpdtDtList(updtDtListFromUdm);
			udmRepo.save(udm);
		}

		// signin response :
		Optional<ApplicationMaster> amOPt = applicationMasterRepo.findById(user.getApplicationid());
		ApplicationMaster am = amOPt.get();
		String redirectURL = am.getRedirectURL();

		System.out.println(convertToLocalDateViaInstant(date));
		System.out.println(convertToLocalDateViaMilisecond(date));
		System.out.println(convertToLocalDateTimeViaSqlTimestamp(date));
		
		String randomHash = RandomStringUtils.random(16, encryptedJwt);
		
		String t1 = encryptedJwt.substring(0, 100);
		String t2 = encryptedJwt.substring(100, 200);
		String t3 = encryptedJwt.substring(200, 300);
		String t4 = encryptedJwt.substring(300, 400);
		String t5 = encryptedJwt.substring(400, 500);
		String t6 = encryptedJwt.substring(500, encryptedJwt.length())+randomHash;
		
		
		logger.info("encryptedJwt below :");
		logger.info(encryptedJwt);
		System.out.println(encryptedJwt.length());
		
		String mergedToken = t1.trim()+t2.trim()+t3.trim()+t4.trim()+t5.trim()+t6.trim();
		logger.info("mergedToken below :");
		logger.info(mergedToken);
		System.out.println(mergedToken.length());
		
		logger.info("ARE EQUAL : "+encryptedJwt.equals(mergedToken));

		SigninResponseBean res = new SigninResponseBean(t1,t2,t3,t4,t5,t6, redirectURL, d, user.getUseremailId());
		
		//updating oldPasswordsTable :
		OldPasswordsEntity oldPasswordsEntity = oldPasswordRepo.findByPasswordOwnerId(user.getUseremailId());
		
		if(oldPasswordsEntity == null) {
			OldPasswordsEntity oldPasswordsEntity_fresh = new OldPasswordsEntity();
			oldPasswordsEntity_fresh.setPasswordOwnerId(user.getUseremailId());
			oldPasswordsEntity_fresh.setEncryptedPwrd_01(user.getPassword());
			oldPasswordsEntity_fresh.setPswd_01_createdDate(LocalDateTime.now());
			oldPasswordRepo.save(oldPasswordsEntity_fresh);
		}

		return res;
	}
	
	// SELF-SERVICE LOGIN SERVICE :

	@Override
	public SigninResponseBean selfServiceLogin(LoginRequest loginRequest, HttpServletRequest http,
			HttpServletResponse response) throws Exception {


		logger.info("loginReq email : " + loginRequest.getEmail());
		logger.info("loginReq pass : " + loginRequest.getPassword());

		if (!userRepository.existsByUseremailId(loginRequest.getEmail()))
			throw new LoginException("Please check your email!");

		
		UserDetails user = userRepository.findByUseremailId(loginRequest.getEmail());
		
		if (!loginRequest.getPassword().equals(user.getPassword()))
			throw new LoginException("Please check your password!");

		logger.info("db pass :" + user.getPassword());

		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword()));
		

		UserDetails uv = userRepository.findByUseremailId(loginRequest.getEmail());
		logger.info("user : " + uv);
		long roleid = uv.getRoleId();
		logger.info(" roleId : " + roleid);
		RoleMaster rr = roleMasterRepo.findById(roleid).get();
		logger.info(" Role : " + rr);

		RoleMaster role = roleMasterRepo.findById(userRepository.findByUseremailId(loginRequest.getEmail()).getRoleId())
				.get();

		String appName = applicationMasterRepo.findById(user.getApplicationid()).get().getApplicationName();

		String appRole = appName + "_" + role.getRoleName();
		String appRoleDesc = role.getRoleDescription();
		Collection<? extends GrantedAuthority> userGrantedAuths = getAuthorities(appRole, appRoleDesc);


		logger.info("authorities from 'userDetailsimpl' : " + userGrantedAuths);

		authentication = new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), "", userGrantedAuths);

		SecurityContext context = SecurityContextHolder.createEmptyContext();
		context.setAuthentication(authentication);
		SecurityContextHolder.setContext(context);

		// SecurityContextHolder.getContext().setAuthentication(authentication);

		logger.info("jwt generation STARTS , inside controller");

		Optional<DPMaster> dp = dpRepo.findByDpID(user.getDpID());
		String dpName = dp.get().getDPName();

		String jwt = jwtUtils.generateJwtToken(authentication, user.getDpID(), dpName);

		logger.info("jwt generation ENDS , inside controller");

		DecodedJWT decodedJWT = JWT.decode(jwt);
		Date date = decodedJWT.getExpiresAt();

		logger.info("EXPIRY DATE : " + date);
		logger.info("CLAIMS : " + decodedJWT.getClaims());
		logger.info("authentication principal : " + authentication.getPrincipal());

		String dt = convertToLocalDateTimeViaSqlTimestamp(date) + "";
		String d = dt.replace("T", " ");
		logger.info(d);
		logger.info("''''''''''''''''''''''''''''''''''''''''''''''");

		// ----------------AES encryption STARTS-----------------
		logger.info("AES encryption STARTS");
		Optional<DPMaster> dpOpt = dpRepo.findByDpID(user.getDpID());
		String encKeyFromUserDpId = dpOpt.get().getEnckey();
		logger.info("ENC-KEY : :  : : :  " + encKeyFromUserDpId);

		String emailPlusJwt = loginRequest.getEmail()+" "+jwt;
		String encryptedJwt = EncryptDecrypt.encryptData(encKeyFromUserDpId, emailPlusJwt);
//		String encryptedJwt = EncryptDecrypt.encryptData(encKeyFromUserDpId, jwt);

		logger.info("AES encryption ENDS");
		// ----------------AES encryption ENDS-----------------

		// ================================================================

		/// response.setHeader(SecurityConstants.JWT_HEADER, hashedJWT);
		CustomJwtSecretKeyPair jwtAndSecretKey = new CustomJwtSecretKeyPair();
		jwtAndSecretKey.setSecretKeyForToken(encKeyFromUserDpId);
		jwtAndSecretKey.setTokenKey(encryptedJwt);
		JwtCacheUtilWithEncryptKey.currentUserjwtCacheDetailsWithkey(authentication.getName(), jwtAndSecretKey, date);

		// Collection<? extends GrantedAuthority> ga = authentication.getAuthorities();

//		UserDetailsImpl userDetails = new UserDetailsImpl(user.getUserid(), user.getUsername(), user.getUseremailId(),
//				user.getPassword(), ga);

		List<String> roles = authentication.getAuthorities().stream().map(item -> item.getAuthority())
				.collect(Collectors.toList());

		logger.info("roles-------- : " + roles);

		// checking if the locked in time has reached to an end :

		String userLastL = convertToLocalDateTimeViaSqlTimestamp(new Date()).toString();
//		String userLastLogin = new Date().toString();
		System.out.println("userLastLogin :" + userLastL); // 2023-08-24T17:45:09.505
		String userLastLogin = userLastL.replace("T", " ");
		if (user.getLastLogin() == null || user.getLastLogin().equals("")) {
			logger.info("Setting new lastLogin in db..");
			user.setLastLogin(userLastLogin);
		}

		logger.info("userLastLogin after replacing T : " + userLastLogin);
		Date currentDate = new Date();
		// 2023-08-07 14:50:46.027
		System.out.println("###########################");
//		SimpleDateFormat formatter = new SimpleDateFormat("EE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);  //Thu Aug 24 17:10:29 IST 2023
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd' 'hh:mm:ss.SSS", Locale.ENGLISH);
		System.out.println("###########################");
		System.out.println("hhbhh: "+user.getLastLogin());
		System.out.println("###########################");
		System.out.println("hhbhh len : "+user.getLastLogin().length());
		String uLL = "";
		Date lastL = formatter.parse(user.getLastLogin());
//		if(user.getLastLogin().length() == 19) {
//			uLL = user.getLastLogin() + "1";
//			lastL = formatter.parse(uLL);
//		}else {
//			lastL = formatter.parse(user.getLastLogin());
//		}
		
		System.out.println("LastL : " + lastL);
//		  SimpleDateFormat print = new SimpleDateFormat("MMM d, yyyy HH:mm:ss"); 
//		  System.out.println(print.format(lastL));
//		 System.out.println("LastLogin : "+lastL);
		logger.info("Current time :  " + currentDate.getTime());
		logger.info("LastLoginTime : " + lastL.getTime());

		logger.info("DIFF :" + (currentDate.getTime() - lastL.getTime()));
		long time_difference = currentDate.getTime() - lastL.getTime();
		logger.info("time_difference : " + time_difference);
		long minutes_difference = (time_difference / (1000 * 60)) % 60;
		logger.info("minutes_difference : " + minutes_difference);
		

		user.setLoginAttempt(user.getLoginAttempt() + 1);
		logger.info("NUMBER OF LOGIN ATTEMPTS = " + user.getLoginAttempt());
		user.setActive(true);

		String userLLogin = convertToLocalDateTimeViaSqlTimestamp(new Date()).toString();
//		String userLastLogin = new Date().toString();
		System.out.println("userLastLogin :" + userLLogin); // 2023-08-24T17:45:09.505
		String userLastLoginn = userLastL.replace("T", " ");
		user.setLastLogin(userLastLoginn);
		userRepository.save(user);

//		Setting up UserDetailsMapperEntity in db : 
		UserDetailsMapperEntity udmm = udmRepo.findByUserEmail(user.getUseremailId());
		System.out.println("UDMM L308: " + udmm);
		String trimmedEncryptedJwt = (encryptedJwt.substring(0, 6))
				+ (encryptedJwt.substring(encryptedJwt.length() - 6, encryptedJwt.length()));
		if (udmm != null) {
//			System.out.println(udmm.getTokenExpiryList());
			System.out.println("L312 --------------");
			List<String> tokenListFromUdm = udmm.getJwtList();
			if (tokenListFromUdm == null) {
				System.out.println("L315 --------------");
				List<String> newTokenList = new ArrayList<>();
				newTokenList.add(trimmedEncryptedJwt);
				udmm.setJwtList(newTokenList);
			} else {
				System.out.println("L320 --------------");
				System.out.println(tokenListFromUdm);
				System.out.println("trimmedEncryptedJwt : " + trimmedEncryptedJwt);
				List<String> newTokenList = new ArrayList<>();
				for (String tkn : tokenListFromUdm) {
					newTokenList.add(tkn);
				}
				newTokenList.add(trimmedEncryptedJwt);
//					tokenListFromUdm.add(trimmedEncryptedJwt+",");
				udmm.setJwtList(newTokenList);
				System.out.println(newTokenList);
			}
			System.out.println("L321 --------------");

			List<String> expiryListFromUdm = udmm.getTokenExpiryList();
			System.out.println(expiryListFromUdm);
			if (expiryListFromUdm == null) {
				List<String> newExpListUdm = new ArrayList<>();
				newExpListUdm.add(d);
				System.out.println("EXP DATE #1: " + d);
				udmm.setTokenExpiryList(newExpListUdm);
			} else {
				List<String> newExpListUdm = new ArrayList<>();
				for (String dateStr : expiryListFromUdm) {
					newExpListUdm.add(dateStr);
				}
				newExpListUdm.add(d);
				udmm.setTokenExpiryList(newExpListUdm);
				System.out.println("EXP DATE #2.1: " + date);
			}

			List<String> lastLoginListFromUdm = udmm.getLastLoginList();
			if (lastLoginListFromUdm == null) {
				List<String> newLoginListUdm = new ArrayList<>();
				newLoginListUdm.add(userLastLogin);
				udmm.setLastLoginList(newLoginListUdm);
			} else {
				List<String> newLoginListUdm = new ArrayList<>();
				for (String loginStr : lastLoginListFromUdm) {
					newLoginListUdm.add(loginStr);
				}
				newLoginListUdm.add(userLastLogin);
				udmm.setLastLoginList(newLoginListUdm);
			}

			udmm.setLoginAttempts(udmm.getLoginAttempts() + 1);

			List<String> updtDtListFromUdm = udmm.getUpdtDtList();
			if (updtDtListFromUdm == null) {
				List<String> newUpdtDtListUdm = new ArrayList<>();
				newUpdtDtListUdm.add(user.getUpdtDt());
				udmm.setUpdtDtList(newUpdtDtListUdm);
			} else {
				List<String> newUpdtDtListUdm = new ArrayList<>();
				for (String updtStr : updtDtListFromUdm) {
					newUpdtDtListUdm.add(updtStr);
				}
				newUpdtDtListUdm.add(user.getUpdtDt());
				udmm.setUpdtDtList(newUpdtDtListUdm);
			}

			udmRepo.save(udmm);
		} else {
			UserDetailsMapperEntity udm = new UserDetailsMapperEntity();
			udm.setUserEmail(user.getUseremailId());
			udm.setMobileNumber(user.getUsermobileNumber());
			udm.setApplicationId(user.getApplicationid());
			udm.setCrtdDt(user.getCrtdDt());
			udm.setDpId(user.getDpID());
			udm.setRoleId(user.getRoleId());
			List<String> tokenListFromUdm = new ArrayList<>();
			tokenListFromUdm.add(trimmedEncryptedJwt);
			udm.setJwtList(tokenListFromUdm);
			List<String> expiryListUdm = new ArrayList<>();
			expiryListUdm.add(d);
			udm.setTokenExpiryList(expiryListUdm);
			List<String> lastLoginListUdm = new ArrayList<>();
			lastLoginListUdm.add(userLastLogin);
			udm.setLastLoginList(lastLoginListUdm);
			udm.setLoginAttempts(1);
			List<String> updtDtListFromUdm = new ArrayList<>();
			updtDtListFromUdm.add(user.getUpdtDt());
			udm.setUpdtDtList(updtDtListFromUdm);
			udmRepo.save(udm);
		}

		// signin response :
		Optional<ApplicationMaster> amOPt = applicationMasterRepo.findById(user.getApplicationid());
		ApplicationMaster am = amOPt.get();
		String redirectURL = am.getRedirectURL();

		System.out.println(convertToLocalDateViaInstant(date));
		System.out.println(convertToLocalDateViaMilisecond(date));
		System.out.println(convertToLocalDateTimeViaSqlTimestamp(date));
		
		//
		
		String randomHash = RandomStringUtils.random(16, encryptedJwt);
		
		String t1 = encryptedJwt.substring(0, 100);
		String t2 = encryptedJwt.substring(100, 200);
		String t3 = encryptedJwt.substring(200, 300);
		String t4 = encryptedJwt.substring(300, 400);
		String t5 = encryptedJwt.substring(400, 500);
		String t6 = encryptedJwt.substring(500, encryptedJwt.length())+randomHash;
		
		
		logger.info("encryptedJwt below :");
		logger.info(encryptedJwt);
		System.out.println(encryptedJwt.length());
		
		String mergedToken = t1.trim()+t2.trim()+t3.trim()+t4.trim()+t5.trim()+t6.trim();
		logger.info("mergedToken below :");
		logger.info(mergedToken);
		System.out.println(mergedToken.length());
		
		logger.info("ARE EQUAL : "+encryptedJwt.equals(mergedToken));

		SigninResponseBean res = new SigninResponseBean(t1,t2,t3,t4,t5,t6, "", d, user.getUseremailId(),"");
		
		//updating oldPasswordsTable :
		OldPasswordsEntity oldPasswordsEntity = oldPasswordRepo.findByPasswordOwnerId(user.getUseremailId());
		
		if(oldPasswordsEntity == null) {
			OldPasswordsEntity oldPasswordsEntity_fresh = new OldPasswordsEntity();
			oldPasswordsEntity_fresh.setPasswordOwnerId(user.getUseremailId());
			oldPasswordsEntity_fresh.setEncryptedPwrd_01(user.getPassword());
			oldPasswordsEntity_fresh.setPswd_01_createdDate(LocalDateTime.now());
			oldPasswordRepo.save(oldPasswordsEntity_fresh);
		}

		return res;
	
	}
	
	

	@Override
	public GetUserDetailsResponse getUserDetails(HttpServletRequest http) throws Exception {
		// TODO Auto-generated method stub

		String encryptedJWTfromRequestHeader = http.getHeader(SecurityConstants.JWT_HEADER);

		encryptedJWTfromRequestHeader = encryptedJWTfromRequestHeader.substring(7);

		String jwt = JwtExtractorUtil.tokenDecryptionHelper(http);

		GetUserDetailsResponse response = new GetUserDetailsResponse();

		try {

			logger.info("JWT IN getUserDetails SERVICE  :");
			logger.info(jwt);
			SecretKey key = Keys.hmacShaKeyFor(SecurityConstants.JWT_KEY.getBytes());

			Claims claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(jwt).getBody();

			String username = String.valueOf(claims.get("username"));

			String dateFromClaims = String.valueOf(claims.get("exp"));
			logger.info(
					"EXPIRYYYYYYYYYYYYYYYYYYYYYYYYYY ----------------------DATE--------------------CLAIMSSSSSS--------");
			logger.info(dateFromClaims);

			UserDetails user = userRepository.findByUseremailId(username);
			logger.info("USER IN getUserDetails SERVICE  :");
			System.out.println(user);

			String appName = applicationMasterRepo.findById(user.getApplicationid()).get().getApplicationName();
			logger.info("APP-NAME IN getUserDetails SERVICE  :");
			logger.info(appName);

			GetMenuDetailsRequest req = new GetMenuDetailsRequest();
			req.setEmail(username);
			List<MenuMaster> menuList = menuMasterService.getMenuDetailsThroughRoleMenuMapper(req);
			logger.info("MenuList : " + menuList);

			Optional<RoleMaster> optt = roleMasterRepo.findById(user.getRoleId());
			RoleMaster userRole = optt.get();

			List<CustomResponseMenuMaster> menuListTemp = new ArrayList<>();
			for (int k = 0; k < menuList.size(); k++) {
				long id = menuList.get(k).getMenuId();
				String text = menuList.get(k).getMenuName();
				long menuFatherId = menuList.get(k).getMenuParentId();
				String routingUrl = menuList.get(k).getRoutingUrl();
				int displayOrder = menuList.get(k).getDisplayOrder();
				String icon = menuList.get(k).getMenuIcon();
				CustomResponseMenuMaster crmm = new CustomResponseMenuMaster(id, icon, text, "", menuFatherId, "",
						routingUrl, displayOrder);

				Optional<MenuMaster> mmOpt = menuMasterRepo.findById(menuFatherId);
				if (mmOpt.isPresent()) {
					if (crmm.getMenuFatherId() != 0) {
						crmm.setAction("/action"); // because fatherId is valid
					}
					Set<CustomResponseMenuMaster> menuListByRecursion = recursiveMenuListFinder(menuListTemp,
							menuFatherId);
					menuListTemp.addAll(menuListByRecursion);
				}
				menuListTemp.add(crmm);
			}

			// List to set to get unique entries:
			Set<CustomResponseMenuMaster> menuListSet = new HashSet<>(menuListTemp);

			// Set to List :
			List<CustomResponseMenuMaster> finalList = menuListSet.stream().collect(Collectors.toList());
			System.out.println(finalList);

			// DECODING JWT to get token Expiry & Username :
			DecodedJWT decodedJWT = JWT.decode(jwt);
			String userName = decodedJWT.getClaim("username").toString();
			Date date = decodedJWT.getExpiresAt();
			logger.info("username from JWT : " + userName);
			logger.info("tkn expiresAt : " + date);

			response.setUseremail(username);
			response.setUsername(user.getUsername());
			response.setRoleName(userRole.getRoleName());
			response.setApplication_name(appName);
			response.setMenuList(finalList);
			response.setRoleDescription(userRole.getRoleDescription());
			response.setAccessToken(encryptedJWTfromRequestHeader);
			response.setDpId(user.getDpID());
			Optional<DPMaster> dp = dpRepo.findByDpID(user.getDpID());
			response.setDpName(dp.get().getDPName());
			String d = convertToLocalDateTimeViaSqlTimestamp(date) + "";
			logger.info(d);
			response.setExpDt(d);
			Optional<RoleMenuMapper> rmmOpt = rmmRepo.findById(user.getRoleId());
			if (rmmOpt.isPresent()) {
				RoleMenuMapper rmm = rmmOpt.get();
				List<EndPointsMaster> epList = new ArrayList<>();
				for (String epId : rmm.getEpList()) {
					long l = Long.parseLong(epId);
					Optional<EndPointsMaster> epm = epRepo.findById(l);
					if (epm.isPresent())
						epList.add(epm.get());
				}
				response.setEpList(epList);
			}

		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		System.out.println("Response of getuserdetails : \n"+response.toString());
		return response;
	}

	// recursive code for finding menuList and each menu-parent if their parent id
	// is valid
	public Set<CustomResponseMenuMaster> recursiveMenuListFinder(List<CustomResponseMenuMaster> list, long id) {

		Optional<MenuMaster> mmOpt = menuMasterRepo.findById(id);

		Set<CustomResponseMenuMaster> test = new HashSet<>(list);

		if (!mmOpt.isPresent())
			return test;

		MenuMaster mm = mmOpt.get();
		System.out.println("RECURSIVELY gotten menu : ");
		System.out.println(mm);
		CustomResponseMenuMaster crmm = new CustomResponseMenuMaster(mm.getMenuId(), mm.getMenuIcon(), mm.getMenuName(),
				"", mm.getMenuParentId(), "", mm.getRoutingUrl(), mm.getDisplayOrder());
		if (crmm.getMenuFatherId() != 0) {
			crmm.setAction("/action"); // because fatherId is valid
		}

		list.add(crmm);

		return recursiveMenuListFinder(list, mm.getMenuParentId());
	}

	@Override
	public List<UserDetails> getAllUsers(String email) throws UserDetailsException, RoleException {
		// TODO Auto-generated method stub

		UserDetails user = userRepository.findByUseremailId(email);
		if (user == null)
			throw new UserDetailsException("Please provide a valid Email!");
		if (user.getPwdexpdt().before(new Date()))
			throw new PasswordExpiryException("Password Expired! Please Update your Password first!");

		List<UserDetails> userList = userRepository.findAll();

		return userList;
	}

	@Override
	public String logoutUser(String email, HttpServletRequest http) throws Exception {
		logger.info("'USER_JWT mapper with SecretKey' before deleting CACHE : ");
		System.out.println(JwtCacheUtilWithEncryptKey.getUserNameJwtMapperWithKey());
		logger.info("EMAIL: ---  :  " + email);
		UserDetails user = userRepository.findByUseremailId(email);

		if (user == null)
			throw new Exception("No User registered with this Email / User account not found!");

		String encryptedJWTfromRequestHeader = http.getHeader(SecurityConstants.JWT_HEADER);

		encryptedJWTfromRequestHeader = encryptedJWTfromRequestHeader.substring(7);
		
	

		String jwt = JwtExtractorUtil.tokenDecryptionHelper(http);

		Map<String, Map<CustomJwtSecretKeyPair, Date>> mapper = JwtCacheUtilWithEncryptKey
				.getUserNameJwtMapperWithKey();

		logger.info(jwt);

		try {
			// extracting the word 'Bearer':
			// jwt = jwt.substring(7);

			logger.info("JWT IN LOGOUT SERVICE  :");
			logger.info(jwt);
			SecretKey key = Keys.hmacShaKeyFor(SecurityConstants.JWT_KEY.getBytes());

			Claims claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(jwt).getBody();

			String username = String.valueOf(claims.get("username"));
			logger.info("username from Claims : " + username);
			if (email.equals(username)) {
				logger.info("username & Email matches!!!!!");

				CustomJwtSecretKeyPair jwtSecretkeyPair = new CustomJwtSecretKeyPair();
//				String secretKeyFromHeader = http.getHeader("KEY");
				String encKey = dpRepo.findByDpID(userRepository.findByUseremailId(email).getDpID()).get().getEnckey();
				logger.info("encKey in LogoutService : " + encKey);
				jwtSecretkeyPair.setSecretKeyForToken(encKey);
				jwtSecretkeyPair.setTokenKey(encryptedJWTfromRequestHeader);

				if (mapper.containsKey(email)) {
					Map<CustomJwtSecretKeyPair, Date> customObjDateMapper = mapper.get(email);

					if (customObjDateMapper.containsKey(jwtSecretkeyPair)) {
						customObjDateMapper.remove(jwtSecretkeyPair);
						logger.info("USER_JWT mapper CACHE DELETED!");
					} else
						throw new LogoutException("UnAuthorized token!");
					logger.info("USER_JWT mapper after deleting CACHE : ");
					System.out.println(JwtCacheUtilWithEncryptKey.getUserNameJwtMapperWithKey());
				} else
					throw new LogoutException("No such email present in Cache!");

			} else
				throw new Exception("Provided Email doesn't match!");

		} catch (Exception e) {
			throw new BadCredentialsException("Invalid Token/Credentials!");
		}

		user.setActive(false);
		user.setLoginAttempt(0);
		userRepository.save(user);

		return "Logged Out !";
	}

	public Map<String, Object> getMapFromIoJsonwebtokenClaims(Claims claims) {
		Map<String, Object> expectedMap = new HashMap<String, Object>();
		for (Entry<String, Object> entry : claims.entrySet()) {
			expectedMap.put(entry.getKey(), entry.getValue());
		}
		return expectedMap;
	}

	private Collection<? extends GrantedAuthority> getAuthorities(String roleName, String appRoleDesc) {
		List<GrantedAuthority> authorities = new ArrayList<>();

		authorities.add(new SimpleGrantedAuthority(appRoleDesc));
		authorities.add(new SimpleGrantedAuthority(roleName));

		return authorities;
	}

	// Date conversion-methods Start:: : : :
	LocalDateTime convertToLocalDateTimeViaSqlTimestamp(Date dateToConvert) {
		return new java.sql.Timestamp(dateToConvert.getTime()).toLocalDateTime();
	}

	public LocalDate convertToLocalDateViaInstant(Date dateToConvert) {
		return dateToConvert.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	}

	public LocalDate convertToLocalDateViaMilisecond(Date dateToConvert) {
		return Instant.ofEpochMilli(dateToConvert.getTime()).atZone(ZoneId.systemDefault()).toLocalDate();
	}

	@Override
	public String logoutFromAllDevices(String email, HttpServletRequest http) throws Exception {
		logger.info("'USER_JWT mapper with SecretKey' before deleting CACHE : ");
		System.out.println(JwtCacheUtilWithEncryptKey.getUserNameJwtMapperWithKey());
		logger.info("EMAIL: ---  :  " + email);
		UserDetails user = userRepository.findByUseremailId(email);

		if (user == null)
			throw new Exception("No User registered with this Email / User account not found!");

		String encryptedJWTfromRequestHeader = http.getHeader(SecurityConstants.JWT_HEADER);
		encryptedJWTfromRequestHeader = encryptedJWTfromRequestHeader.substring(7);

		String jwt = JwtExtractorUtil.tokenDecryptionHelper(http);

		Map<String, Map<CustomJwtSecretKeyPair, Date>> mapper = JwtCacheUtilWithEncryptKey
				.getUserNameJwtMapperWithKey();

		logger.info(jwt);

		try {

			logger.info("JWT IN LOGOUT SERVICE  :");
			logger.info(jwt);
			SecretKey key = Keys.hmacShaKeyFor(SecurityConstants.JWT_KEY.getBytes());

			Claims claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(jwt).getBody();

			String username = String.valueOf(claims.get("username"));
			logger.info("username from Claims : " + username);
			if (email.equals(username)) {
				logger.info("username & Email matches!!!!!");

				CustomJwtSecretKeyPair jwtSecretkeyPair = new CustomJwtSecretKeyPair();
				String encKey = dpRepo.findByDpID(userRepository.findByUseremailId(email).getDpID()).get().getEnckey();
				logger.info("encKey in LogoutService : " + encKey);
				jwtSecretkeyPair.setSecretKeyForToken(encKey);
				jwtSecretkeyPair.setTokenKey(encryptedJWTfromRequestHeader);

				if (mapper.containsKey(email)) {
					mapper.remove(email);
					logger.info("USER_JWT mapper after deleting CACHE : ");
					System.out.println(JwtCacheUtilWithEncryptKey.getUserNameJwtMapperWithKey());
				} else
					throw new LogoutException("No such email could be found!");

			} else
				throw new Exception("Provided Email doesn't match any current records!");

		} catch (Exception e) {
			throw new BadCredentialsException("Invalid Token/Credentials!");
		}

		user.setActive(false);
		user.setLoginAttempt(0);
		userRepository.save(user);

		return "Logged Out from all devices successfully!";
	}

	@Override
	public Map<String, List<String>> getAllEndpointsBasedOnAppId(Long appId) {

		Optional<ApplicationMaster> app = applicationMasterRepo.findById(appId);
		if (!app.isPresent()) {
			throw new ApplicationException("Application id not found");
		}

		List<RoleMenuMapper> rm = rmmRepo.findByApplicationId(appId);

		if (rm.size() == 0) {
			throw new RoleMenuMapperException("Role with Application not found");
		}
		Map<String, List<String>> epsBasedOnRole = new HashMap<>();
		for (RoleMenuMapper roleMenuMapper : rm) {
			System.out.println("ohb - rm : "+ roleMenuMapper.getRoleId());
			RoleMenuMapper rmm = rmmRepo.findByRoleId(roleMenuMapper.getRoleId());
			List<String> eps = rmm.getEpList();
			List<String> urls = new ArrayList<>();
			for (String epm : eps) {
				Long i = Long.parseLong(epm);
				logger.info("ENDPOINT  ID : "+i);
				String url = epRepo.findById(i).get().getEpName();
				logger.info("ENDPOINT : "+url);
				urls.add(url);
			}
			String roleName = roleMasterRepo.findById(rmm.getRoleId()).get().getRoleName();
			logger.info("roleName : "+roleName);
			String roleDesc = roleMasterRepo.findById(rmm.getRoleId()).get().getRoleDescription();
			logger.info("roleDesc : "+roleDesc);
			epsBasedOnRole.put(roleName + ":" + roleDesc, urls);
		}
		
		logger.info("Result : "+epsBasedOnRole.toString());
		return epsBasedOnRole;

	}
	
	@Override
	public String forgotPassword(ForgotPasswordRequest request) throws UserDetailsException {
		// TODO Auto-generated method stub
		Optional<UserDetails> userOptional = Optional.ofNullable(userRepository.findByUseremailId(request.getEmail()));

		if (!userOptional.isPresent()) {
			return "Please enter correct credentials!";
		}

		UserDetails user = userOptional.get();
		String resetPassToken = generateToken();
		user.setResetPasswordToken(resetPassToken);
		user.setTokenCreationDate(LocalDateTime.now());
		logger.info("Reset Password Token CreationDate : " + user.getTokenCreationDate());

		user = userRepository.save(user);

		return resetPassToken;
	}



	
	@Override
	public ResetPasswordResponseBean resetPassword(RequestNewResetPassword req) throws UserDetailsException {
		
		ResetPasswordResponseBean resetPasswordResponseBean = new ResetPasswordResponseBean();
		
		Optional<UserDetails> userOptionalCheck = userRepository.findByUseremailIdAndMobile(req.getEmail(),req.getMobile());
		
		if (!userOptionalCheck.isPresent()) {
			resetPasswordResponseBean.setResponse(SSOConstants.SSO_ERROR_MESSAGE);
			resetPasswordResponseBean.setResponseMsg(messageSource.getMessage("error.wrong.credentials", null, Locale.ENGLISH));
			return resetPasswordResponseBean;
		}
		
			 ValidateOtpResponse validateOtpResponse = null;
			OTPValidationRequestBean otpValidationRequestBean =  new OTPValidationRequestBean();
			 otpValidationRequestBean.setEmailId(req.getEmail());
			 otpValidationRequestBean.setMobileNo(req.getMobile());
			 otpValidationRequestBean.setOtp(req.getMobileOtp());
			 otpValidationRequestBean.setRequestType(req.getRequestType());
			 
			 try {
				validateOtpResponse = otpValidatorService.validateOtp(otpValidationRequestBean);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 
		boolean isUnclockUser = true;
		 if(validateOtpResponse.isValid()) {
			// TODO Auto-generated method stub
				Optional<UserDetails> userOptional = userRepository.findByResetPasswordToken(req.getResetPasswordToken());
 
				if (!userOptional.isPresent()) {
					isUnclockUser = false;
					resetPasswordResponseBean.setResponse(SSOConstants.SSO_ERROR_MESSAGE);
					resetPasswordResponseBean.setResponseMsg(SSOConstants.INVALID_RESET_TOKEN);
					return resetPasswordResponseBean;
				}
 
				LocalDateTime tokenCreationDate = userOptional.get().getTokenCreationDate();
 
				if (!isResetPasswordTokenExpired(tokenCreationDate)) {
					isUnclockUser = false;
					resetPasswordResponseBean.setResponse(SSOConstants.SSO_ERROR_MESSAGE);
					resetPasswordResponseBean.setResponseMsg(messageSource.getMessage("error.time.exceeded", null, Locale.ENGLISH));
					
					return resetPasswordResponseBean;
				}
 
				logger.info("Status of reset password token expired : " + isResetPasswordTokenExpired(tokenCreationDate));
 
				//OLD PASSWORDS LOGIC HERE : 
				UserDetails user = userOptional.get();
				boolean isSaveOldPasswords = saveOldPasswords(user,req.getEmail(),req.getNewPassword());
 
				if(!isSaveOldPasswords) {
					isUnclockUser = false;
					resetPasswordResponseBean.setResponse(SSOConstants.SSO_ERROR_MESSAGE);
					resetPasswordResponseBean.setResponseMsg(messageSource.getMessage("error.old.password", null, Locale.ENGLISH));
					return resetPasswordResponseBean;
				}
			
		 }
		 else {
			 	isUnclockUser = false;
			 	resetPasswordResponseBean.setResponse(SSOConstants.SSO_ERROR_MESSAGE);
				resetPasswordResponseBean.setResponseMsg(validateOtpResponse.getErrorMsg());
		 }
		 
		 
				UserDetails user = userOptionalCheck.get();
		 		
		 		String userUpdtDate = convertToLocalDateTimeViaSqlTimestamp(new Date()).toString();
				System.out.println("userUpdtDate :" + userUpdtDate); // 2023-08-24T17:45:09.505
				String userNewUpdtDate = userUpdtDate.replace("T", " ");
				if(isUnclockUser) {
					logger.info("Unlocking User & setting new userUpdtDate in db..");
					user.setLocked(false);
					user.setUpdtDt(userNewUpdtDate);
					user.setLoginAttempt(0);
					
					user.setPassword(req.getNewPassword());
			 		user.setResetPasswordToken(null);
			 		user.setTokenCreationDate(null);
			 		userRepository.save(user);
				}
				
		 		
		 
		 
		 return resetPasswordResponseBean;
	}
	
	
	private boolean saveOldPasswords(UserDetails user,String useremailId, String newPassword) {
		boolean allowToUpdateNewPassword = true;
		
		OldPasswordsEntity oldPasswordsEntity = oldPasswordRepo.findByPasswordOwnerId(useremailId);
		System.out.println("oldPasswordsEntity  ::;;");
		

		if(oldPasswordsEntity != null) {
			System.out.println(oldPasswordsEntity.toString());
			
			OldPasswordsEntity newOldPasswordsEntity = new OldPasswordsEntity();
			
			if((oldPasswordsEntity.getEncryptedPwrd_01() != null && oldPasswordsEntity.getEncryptedPwrd_01().equals(newPassword)) || 
					(oldPasswordsEntity.getEncryptedPwrd_02() != null && oldPasswordsEntity.getEncryptedPwrd_02().equals(newPassword)) ||
					(oldPasswordsEntity.getEncryptedPwrd_03() != null && oldPasswordsEntity.getEncryptedPwrd_03().equals(newPassword))) {
				
					allowToUpdateNewPassword = false;
				
			}else {
				
//				if(oldPasswordsEntity.getEncryptedPwrd_02() != null) {
//					oldPasswordsEntity.setEncryptedPwrd_03(oldPasswordsEntity.getEncryptedPwrd_02());
//					oldPasswordsEntity.setPswd_03_createdDate(oldPasswordsEntity.getPswd_02_createdDate());
//				}
//				
//				if(oldPasswordsEntity.getEncryptedPwrd_01() != null) {
//					oldPasswordsEntity.setEncryptedPwrd_02(oldPasswordsEntity.getEncryptedPwrd_01());
//					oldPasswordsEntity.setPswd_02_createdDate(oldPasswordsEntity.getPswd_01_createdDate());
//				}
//				
//				
//				oldPasswordsEntity.setEncryptedPwrd_01(newPassword);
//				oldPasswordsEntity.setPswd_01_createdDate(LocalDateTime.now());
//				
//				System.out.println("oldPasswordsEntity  AFTER::;;");
//				System.out.println(oldPasswordsEntity.toString());
				
//				oldPasswordRepo.save(oldPasswordsEntity);
				
				

				newOldPasswordsEntity.setPasswordOwnerId(useremailId);
				newOldPasswordsEntity.setEncryptedPwrd_01(newPassword);
				newOldPasswordsEntity.setPswd_01_createdDate(LocalDateTime.now());
				newOldPasswordsEntity.setEncryptedPwrd_02(oldPasswordsEntity.getEncryptedPwrd_01());
				newOldPasswordsEntity.setPswd_02_createdDate(oldPasswordsEntity.getPswd_01_createdDate());
				newOldPasswordsEntity.setEncryptedPwrd_03(oldPasswordsEntity.getEncryptedPwrd_02());
				newOldPasswordsEntity.setPswd_03_createdDate(oldPasswordsEntity.getPswd_02_createdDate());
				
				oldPasswordRepo.updateOldPasswords(useremailId,oldPasswordsEntity.getId());
				
				oldPasswordRepo.save(newOldPasswordsEntity);
				System.out.println("newOldPasswordsEntity  AFTER::;;");
				System.out.println(newOldPasswordsEntity.toString());
			}
		}else {
			OldPasswordsEntity oldPasswordsEntity_fresh = new OldPasswordsEntity();
			oldPasswordsEntity_fresh.setPasswordOwnerId(useremailId);
			oldPasswordsEntity_fresh.setEncryptedPwrd_01(newPassword);
			oldPasswordsEntity_fresh.setPswd_01_createdDate(LocalDateTime.now());
			oldPasswordRepo.save(oldPasswordsEntity_fresh);
		}
		

		
		
		return allowToUpdateNewPassword;
	}
	
	
	
	/**
	 * Generate unique token. You may add multiple parameters to create a strong
	 * token.
	 * 
	 * @return unique token
	 */
	private String generateToken() {
		StringBuilder token = new StringBuilder();

		return token.append(UUID.randomUUID().toString()).append(UUID.randomUUID().toString()).toString();
	}

	/**
	 * Check whether the created token expired or not.
	 * 
	 * @param tokenCreationDate
	 * @return true or false
	 */
	private boolean isResetPasswordTokenExpired(final LocalDateTime tokenCreationDate) {

		LocalDateTime now = LocalDateTime.now();
//		Boolean expired = tokenCreationDate.isBefore(now);
		Duration diff = Duration.between(tokenCreationDate, now);
		System.out.println("Difference between dates : " + diff.toMinutes());
//		System.out.println("Diff in min: " + expired);
		System.out.println("Expiry time: " + SecurityConstants.EXPIRE_TOKEN_AFTER_MINUTES);

		return diff.toMinutes() >= SecurityConstants.EXPIRE_TOKEN_AFTER_MINUTES;
	}

	
	
	@Override
	public GetPwrdSaltResponseBean getRandomPasswordSalt(LoginRequest req) throws Exception {
		// TODO Auto-generated method stub
		GetPwrdSaltResponseBean pwrdSaltResponseBean = new GetPwrdSaltResponseBean();
			//check if provided email is valid : 
			if (!userRepository.existsByUseremailId(req.getEmail()))
				throw new LoginException("Wrong email!");
		
				String concatedRequestString = req.getEmail() + " : "+req.getPassword();
				String response = RandomStringUtils.random(16, concatedRequestString);
				pwrdSaltResponseBean.setResponse(response);
				System.out.println("response from pwdSaltGenerator : "+response);
			    //setting/updating this random string salt in db for provided user : 
			    UserDetails user = userRepository.findByUseremailId(req.getEmail());
			    user.setPasswordSalt(response);
			    
			    String userUpdtDate = convertToLocalDateTimeViaSqlTimestamp(new Date()).toString();
				System.out.println("userUpdtDate :" + userUpdtDate); // 2023-08-24T17:45:09.505
				String userNewUpdtDate = userUpdtDate.replace("T", " ");
				logger.info("Setting new userUpdtDate in db + "+userNewUpdtDate);
			    user.setUpdtDt(userNewUpdtDate);
			    
			    userRepository.save(user);
			    
		return pwrdSaltResponseBean;
	}
	
	
	private static String get512Hash(String input) { 
		
        try { 
            // getInstance() method is called with algorithm SHA-512 
            MessageDigest md = MessageDigest.getInstance("SHA-512"); 
  
            
            byte[] messageDigest = md.digest(input.getBytes()); 
  
            // Convert byte array into signum representation 
            BigInteger no = new BigInteger(1, messageDigest); 
  
            // Convert message digest into hex value 
            String hashtext = no.toString(16); 
  
            // Add preceding 0s to make it 32 bit 
            while (hashtext.length() < 32) { 
                hashtext = "0" + hashtext; 
            } 
  
            // return the HashText 
            return hashtext;
            
        }catch (NoSuchAlgorithmException e) { 
            throw new RuntimeException(e); 
        } 
         
	
    }
	
	
	

//	@Override
//	public SigninResponse selfServiceLogin(LoginRequest loginRequest, HttpServletRequest http,
//			HttpServletResponse response) throws Exception {
//
//
//		logger.info("loginReq email : " + loginRequest.getEmail());
//		logger.info("loginReq pass : " + loginRequest.getPassword());
//
//		if (!userRepository.existsByUseremailId(loginRequest.getEmail()))
//			throw new LoginException("Please check your email!");
//
//		UserDetails user = userRepository.findByUseremailId(loginRequest.getEmail());
//
//		logger.info("db pass :" + user.getPassword());
//
//		Authentication authentication = authenticationManager.authenticate(
//				new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword()));
//		
//
//		UserDetails uv = userRepository.findByUseremailId(loginRequest.getEmail());
//		logger.info("user : " + uv);
//		long roleid = uv.getRoleId();
//		logger.info(" roleId : " + roleid);
//		RoleMaster rr = roleMasterRepo.findById(roleid).get();
//		logger.info(" Role : " + rr);
//
//		RoleMaster role = roleMasterRepo.findById(userRepository.findByUseremailId(loginRequest.getEmail()).getRoleId())
//				.get();
//
//		String appName = applicationMasterRepo.findById(user.getApplicationid()).get().getApplicationName();
//
//		String appRole = appName + "_" + role.getRoleName();
//		String appRoleDesc = role.getRoleDescription();
//		Collection<? extends GrantedAuthority> userGrantedAuths = getAuthorities(appRole, appRoleDesc);
//
//
//		logger.info("authorities from 'userDetailsimpl' : " + userGrantedAuths);
//
//		authentication = new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), "", userGrantedAuths);
//
//		SecurityContext context = SecurityContextHolder.createEmptyContext();
//		context.setAuthentication(authentication);
//		SecurityContextHolder.setContext(context);
//
//		// SecurityContextHolder.getContext().setAuthentication(authentication);
//
//		logger.info("jwt generation STARTS , inside controller");
//
//		Optional<DPMaster> dp = dpRepo.findByDpID(user.getDpID());
//		String dpName = dp.get().getDPName();
//
//		String jwt = jwtUtils.generateJwtToken(authentication, user.getDpID(), dpName);
//
//		logger.info("jwt generation ENDS , inside controller");
//
//		DecodedJWT decodedJWT = JWT.decode(jwt);
//		Date date = decodedJWT.getExpiresAt();
//
//		logger.info("EXPIRY DATE : " + date);
//		logger.info("CLAIMS : " + decodedJWT.getClaims());
//		logger.info("authentication principal : " + authentication.getPrincipal());
//
//		String dt = convertToLocalDateTimeViaSqlTimestamp(date) + "";
//		String d = dt.replace("T", " ");
//		logger.info(d);
//		logger.info("''''''''''''''''''''''''''''''''''''''''''''''");
//
//		// ----------------AES encryption STARTS-----------------
//		logger.info("AES encryption STARTS");
//		Optional<DPMaster> dpOpt = dpRepo.findByDpID(user.getDpID());
//		String encKeyFromUserDpId = dpOpt.get().getEnckey();
//		logger.info("ENC-KEY : :  : : :  " + encKeyFromUserDpId);
//
//		String emailPlusJwt = loginRequest.getEmail()+" "+jwt;
//		String encryptedJwt = EncryptDecrypt.encryptData(encKeyFromUserDpId, emailPlusJwt);
////		String encryptedJwt = EncryptDecrypt.encryptData(encKeyFromUserDpId, jwt);
//
//		logger.info("AES encryption ENDS");
//		// ----------------AES encryption ENDS-----------------
//
//		// ================================================================
//
//		/// response.setHeader(SecurityConstants.JWT_HEADER, hashedJWT);
//		CustomJwtSecretKeyPair jwtAndSecretKey = new CustomJwtSecretKeyPair();
//		jwtAndSecretKey.setSecretKeyForToken(encKeyFromUserDpId);
//		jwtAndSecretKey.setTokenKey(encryptedJwt);
//		JwtCacheUtilWithEncryptKey.currentUserjwtCacheDetailsWithkey(authentication.getName(), jwtAndSecretKey, date);
//
//		// Collection<? extends GrantedAuthority> ga = authentication.getAuthorities();
//
////		UserDetailsImpl userDetails = new UserDetailsImpl(user.getUserid(), user.getUsername(), user.getUseremailId(),
////				user.getPassword(), ga);
//
//		List<String> roles = authentication.getAuthorities().stream().map(item -> item.getAuthority())
//				.collect(Collectors.toList());
//
//		logger.info("roles-------- : " + roles);
//
//		// checking if the locked in time has reached to an end :
//
//		String userLastL = convertToLocalDateTimeViaSqlTimestamp(new Date()).toString();
////		String userLastLogin = new Date().toString();
//		System.out.println("userLastLogin :" + userLastL); // 2023-08-24T17:45:09.505
//		String userLastLogin = userLastL.replace("T", " ");
//		if (user.getLastLogin() == null || user.getLastLogin().equals("")) {
//			logger.info("Setting new lastLogin in db..");
//			user.setLastLogin(userLastLogin);
//		}
//
//		logger.info("userLastLogin after replacing T : " + userLastLogin);
//		Date currentDate = new Date();
//		// 2023-08-07 14:50:46.027
//		System.out.println("###########################");
////		SimpleDateFormat formatter = new SimpleDateFormat("EE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);  //Thu Aug 24 17:10:29 IST 2023
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd' 'hh:mm:ss.SSS", Locale.ENGLISH);
//		System.out.println("###########################");
//		System.out.println("hhbhh: "+user.getLastLogin());
//		System.out.println("###########################");
//		System.out.println("hhbhh len : "+user.getLastLogin().length());
//		String uLL = "";
//		Date lastL = formatter.parse(user.getLastLogin());
////		if(user.getLastLogin().length() == 19) {
////			uLL = user.getLastLogin() + "1";
////			lastL = formatter.parse(uLL);
////		}else {
////			lastL = formatter.parse(user.getLastLogin());
////		}
//		
//		System.out.println("LastL : " + lastL);
////		  SimpleDateFormat print = new SimpleDateFormat("MMM d, yyyy HH:mm:ss"); 
////		  System.out.println(print.format(lastL));
////		 System.out.println("LastLogin : "+lastL);
//		logger.info("Current time :  " + currentDate.getTime());
//		logger.info("LastLoginTime : " + lastL.getTime());
//
//		logger.info("DIFF :" + (currentDate.getTime() - lastL.getTime()));
//		long time_difference = currentDate.getTime() - lastL.getTime();
//		logger.info("time_difference : " + time_difference);
//		long minutes_difference = (time_difference / (1000 * 60)) % 60;
//		logger.info("minutes_difference : " + minutes_difference);
//		
//
//		user.setLoginAttempt(user.getLoginAttempt() + 1);
//		logger.info("NUMBER OF LOGIN ATTEMPTS = " + user.getLoginAttempt());
//		user.setActive(true);
//
//		String userLLogin = convertToLocalDateTimeViaSqlTimestamp(new Date()).toString();
////		String userLastLogin = new Date().toString();
//		System.out.println("userLastLogin :" + userLLogin); // 2023-08-24T17:45:09.505
//		String userLastLoginn = userLastL.replace("T", " ");
//		user.setLastLogin(userLastLoginn);
//		userRepository.save(user);
//
////		Setting up UserDetailsMapperEntity in db : 
//		UserDetailsMapperEntity udmm = udmRepo.findByUserEmail(user.getUseremailId());
//		System.out.println("UDMM L308: " + udmm);
//		String trimmedEncryptedJwt = (encryptedJwt.substring(0, 6))
//				+ (encryptedJwt.substring(encryptedJwt.length() - 6, encryptedJwt.length()));
//		if (udmm != null) {
////			System.out.println(udmm.getTokenExpiryList());
//			System.out.println("L312 --------------");
//			List<String> tokenListFromUdm = udmm.getJwtList();
//			if (tokenListFromUdm == null) {
//				System.out.println("L315 --------------");
//				List<String> newTokenList = new ArrayList<>();
//				newTokenList.add(trimmedEncryptedJwt);
//				udmm.setJwtList(newTokenList);
//			} else {
//				System.out.println("L320 --------------");
//				System.out.println(tokenListFromUdm);
//				System.out.println("trimmedEncryptedJwt : " + trimmedEncryptedJwt);
//				List<String> newTokenList = new ArrayList<>();
//				for (String tkn : tokenListFromUdm) {
//					newTokenList.add(tkn);
//				}
//				newTokenList.add(trimmedEncryptedJwt);
////					tokenListFromUdm.add(trimmedEncryptedJwt+",");
//				udmm.setJwtList(newTokenList);
//				System.out.println(newTokenList);
//			}
//			System.out.println("L321 --------------");
//
//			List<String> expiryListFromUdm = udmm.getTokenExpiryList();
//			System.out.println(expiryListFromUdm);
//			if (expiryListFromUdm == null) {
//				List<String> newExpListUdm = new ArrayList<>();
//				newExpListUdm.add(d);
//				System.out.println("EXP DATE #1: " + d);
//				udmm.setTokenExpiryList(newExpListUdm);
//			} else {
//				List<String> newExpListUdm = new ArrayList<>();
//				for (String dateStr : expiryListFromUdm) {
//					newExpListUdm.add(dateStr);
//				}
//				newExpListUdm.add(d);
//				udmm.setTokenExpiryList(newExpListUdm);
//				System.out.println("EXP DATE #2.1: " + date);
//			}
//
//			List<String> lastLoginListFromUdm = udmm.getLastLoginList();
//			if (lastLoginListFromUdm == null) {
//				List<String> newLoginListUdm = new ArrayList<>();
//				newLoginListUdm.add(userLastLogin);
//				udmm.setLastLoginList(newLoginListUdm);
//			} else {
//				List<String> newLoginListUdm = new ArrayList<>();
//				for (String loginStr : lastLoginListFromUdm) {
//					newLoginListUdm.add(loginStr);
//				}
//				newLoginListUdm.add(userLastLogin);
//				udmm.setLastLoginList(newLoginListUdm);
//			}
//
//			udmm.setLoginAttempts(udmm.getLoginAttempts() + 1);
//
//			List<String> updtDtListFromUdm = udmm.getUpdtDtList();
//			if (updtDtListFromUdm == null) {
//				List<String> newUpdtDtListUdm = new ArrayList<>();
//				newUpdtDtListUdm.add(user.getUpdtDt());
//				udmm.setUpdtDtList(newUpdtDtListUdm);
//			} else {
//				List<String> newUpdtDtListUdm = new ArrayList<>();
//				for (String updtStr : updtDtListFromUdm) {
//					newUpdtDtListUdm.add(updtStr);
//				}
//				newUpdtDtListUdm.add(user.getUpdtDt());
//				udmm.setUpdtDtList(newUpdtDtListUdm);
//			}
//
//			udmRepo.save(udmm);
//		} else {
//			UserDetailsMapperEntity udm = new UserDetailsMapperEntity();
//			udm.setUserEmail(user.getUseremailId());
//			udm.setMobileNumber(user.getUsermobileNumber());
//			udm.setApplicationId(user.getApplicationid());
//			udm.setCrtdDt(user.getCrtdDt());
//			udm.setDpId(user.getDpID());
//			udm.setRoleId(user.getRoleId());
//			List<String> tokenListFromUdm = new ArrayList<>();
//			tokenListFromUdm.add(trimmedEncryptedJwt);
//			udm.setJwtList(tokenListFromUdm);
//			List<String> expiryListUdm = new ArrayList<>();
//			expiryListUdm.add(d);
//			udm.setTokenExpiryList(expiryListUdm);
//			List<String> lastLoginListUdm = new ArrayList<>();
//			lastLoginListUdm.add(userLastLogin);
//			udm.setLastLoginList(lastLoginListUdm);
//			udm.setLoginAttempts(1);
//			List<String> updtDtListFromUdm = new ArrayList<>();
//			updtDtListFromUdm.add(user.getUpdtDt());
//			udm.setUpdtDtList(updtDtListFromUdm);
//			udmRepo.save(udm);
//		}
//
//		// signin response :
//		Optional<ApplicationMaster> amOPt = applicationMasterRepo.findById(user.getApplicationid());
//		ApplicationMaster am = amOPt.get();
//		String redirectURL = am.getRedirectURL();
//
//		System.out.println(convertToLocalDateViaInstant(date));
//		System.out.println(convertToLocalDateViaMilisecond(date));
//		System.out.println(convertToLocalDateTimeViaSqlTimestamp(date));
//
//		SigninResponse res = new SigninResponse(encryptedJwt, redirectURL, d, user.getUseremailId());
//		
//		//updating oldPasswordsTable :
//		OldPasswordsEntity oldPasswordsEntity = oldPasswordRepo.findByPasswordOwnerId(user.getUseremailId());
//		
//		if(oldPasswordsEntity == null) {
//			OldPasswordsEntity oldPasswordsEntity_fresh = new OldPasswordsEntity();
//			oldPasswordsEntity_fresh.setPasswordOwnerId(user.getUseremailId());
//			oldPasswordsEntity_fresh.setEncryptedPwrd_01(user.getPassword());
//			oldPasswordsEntity_fresh.setPswd_01_createdDate(LocalDateTime.now());
//			oldPasswordRepo.save(oldPasswordsEntity_fresh);
//		}
//
//		return res;
//	
//	}
	
	
	
////	@Override
//	public ResponseEntity<?> resetPasswordOld(RequestNewResetPassword req) throws UserDetailsException {
//		// TODO Auto-generated method stub
//		Optional<UserDetails> userOptional = userRepository.findByUseremailIdAndMobile(req.getEmail(),req.getMobile());
//
//		if (!userOptional.isPresent()) {
//			return new ResponseEntity<>("Invalid Request", HttpStatus.BAD_REQUEST);
//		}
//
////		LocalDateTime tokenCreationDate = userOptional.get().getTokenCreationDate();
////
////		if (!isResetPasswordTokenExpired(tokenCreationDate)) {
////			return new ResponseEntity<>("Token expired.", HttpStatus.BAD_REQUEST);
////
////		}
////
////		logger.info("Status of reset password token expired : " + isResetPasswordTokenExpired(tokenCreationDate));
//
////		for (OldPasswords oldPasswords : oldPasswordRepo.findByPasswordOwnerId(userOptional.get().getUseremailId())) {
////			System.out.println("OHB -- "+oldPasswords.getEncryptedPassword());
////			if (req.getNewPassword().equals(oldPasswords.getEncryptedPassword())) {
////				System.out.println("Inside reset pass if... equals....");
////				logger.info("Password already used.");
////				return new ResponseEntity<>("New password must not match previous 3 passwords! Please try again... ",
////						HttpStatus.BAD_REQUEST);
////			}
////
////		}
//		
//		
////		OldPasswords oldPasswords = new OldPasswords();
////		oldPasswords.setEncryptedPassword(req.getNewPassword());
////		oldPasswords.setPasswordOwnerId(userOptional.get().getUseremailId());
////		oldPasswords.setCreatedAt(LocalDateTime.now());
////		oldPasswordRepo.save(oldPasswords);
//		
//		
//		OldPasswordsEntity oldPasswordsEntity = oldPasswordRepo.findByPasswordOwnerId(userOptional.get().getUseremailId());
//
//		if(oldPasswordsEntity != null) {
//			if((oldPasswordsEntity.getEncryptedPwrd_01() != null && oldPasswordsEntity.getEncryptedPwrd_01().equals(req.getNewPassword())) || 
//					(oldPasswordsEntity.getEncryptedPwrd_02() != null && oldPasswordsEntity.getEncryptedPwrd_02().equals(req.getNewPassword())) ||
//					(oldPasswordsEntity.getEncryptedPwrd_03() != null && oldPasswordsEntity.getEncryptedPwrd_03().equals(req.getNewPassword()))) {
//				
//				return new ResponseEntity<>("New password must not match previous 3 passwords! Please try again... ",
//						HttpStatus.BAD_REQUEST);
//				
//			}else {
//				
//				if(oldPasswordsEntity.getEncryptedPwrd_02() != null) {
//					oldPasswordsEntity.setEncryptedPwrd_03(oldPasswordsEntity.getEncryptedPwrd_02());
//					oldPasswordsEntity.setPswd_03_createdDate(oldPasswordsEntity.getPswd_02_createdDate());
//				}
//				
//				if(oldPasswordsEntity.getEncryptedPwrd_01() != null) {
//					oldPasswordsEntity.setEncryptedPwrd_02(oldPasswordsEntity.getEncryptedPwrd_01());
//					oldPasswordsEntity.setPswd_02_createdDate(oldPasswordsEntity.getPswd_01_createdDate());
//				}
//				
//				
//				oldPasswordsEntity.setEncryptedPwrd_01(req.getNewPassword());
//				oldPasswordsEntity.setPswd_01_createdDate(LocalDateTime.now());
//				
//				
//				oldPasswordRepo.save(oldPasswordsEntity);
//			}
//		}else {
//			OldPasswordsEntity oldPasswordsEntity_fresh = new OldPasswordsEntity();
//			oldPasswordsEntity_fresh.setPasswordOwnerId(userOptional.get().getUseremailId());
//			oldPasswordsEntity_fresh.setEncryptedPwrd_01(req.getNewPassword());
//			oldPasswordsEntity_fresh.setPswd_01_createdDate(LocalDateTime.now());
//			oldPasswordRepo.save(oldPasswordsEntity_fresh);
//		}
//		
//
//		UserDetails user = userOptional.get();
//
//		user.setPassword(req.getNewPassword());
//		user.setResetPasswordToken(null);
//		user.setTokenCreationDate(null);
//
//		userRepository.save(user);
//
//		return new ResponseEntity<>("Password successfully updated.", HttpStatus.OK);
//	}
//
//	
	

}
