package com.ndml.user_module.controllers;

import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ndml.user_module.model.CaptchaSerttings;
import com.ndml.user_module.model.RequestCaptchaAnswer;
import com.ndml.user_module.utility.CaptchaGenerator;
import com.ndml.user_module.utility.CaptchaUtil;

import cn.apiclub.captcha.Captcha;

@RestController
@RequestMapping("/app/user")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CaptchaController {
	
	Logger logger = LoggerFactory.getLogger(CaptchaController.class);
	
//	public static ConcurrentHashMap<String, String> map = new ConcurrentHashMap<>();
	
	@PostMapping("/getcap")
	public String getCapHandler(@RequestBody String userEmail){	
		logger.info("INSIDE GET-CAPTCHA CONTROLLER..");
		String cap = genCaptcha(userEmail);
		return cap;
	}
	
	@PostMapping("/verifyCaptcha")
	public Boolean checkCaptcha(@RequestBody RequestCaptchaAnswer answer) {
		ConcurrentHashMap<String, String> captchaMap = CaptchaUtil.captchaMap;
		logger.info("########################################################################");
		logger.info("INSIDE VERIFY-CAPTCHA CONTROLLER..");
		logger.info("Captcha Requesting user : "+answer.getUser());
		logger.info("Captcha question : "+answer.getCapQue());
		logger.info("Correct captcha answer : "+captchaMap.get(answer.getUser()+"|"+answer.getCapQue()));
		logger.info("Entered captcha answer : "+answer.getAnswer());
		logger.info("Captcha Verification Result : "+answer.getAnswer().equals(captchaMap.get(answer.getUser()+"|"+answer.getCapQue())));
		logger.info("########################################################################");
		Boolean res = answer.getAnswer().equals(captchaMap.get(answer.getUser()+"|"+answer.getCapQue()));
		captchaMap.remove(answer.getUser()+"|"+answer.getCapQue());
		System.out.println("Captcha questions remaining to be verified : "+captchaMap.size());
		return res;
	}

	private String genCaptcha(String userEmail) {
		ConcurrentHashMap<String, String> captchaMap = CaptchaUtil.captchaMap;
		Captcha captcha = CaptchaGenerator.generateCaptcha(260, 80);
		CaptchaSerttings captchaSettings = new CaptchaSerttings();
		captchaSettings.setHiddenCaptcha(captcha.getAnswer());
		captchaSettings.setCaptcha("");
		captchaSettings.setRealCaptcha(CaptchaGenerator.encodeCaptchatoBinary(captcha));
//		System.out.println(captchaSettings.toString());
		captchaMap.put(userEmail+"|"+captchaSettings.getRealCaptcha(), captchaSettings.getHiddenCaptcha());
//		this.capAns=captchaSettings.getHiddenCaptcha();
		return captchaSettings.getRealCaptcha();
	}
}