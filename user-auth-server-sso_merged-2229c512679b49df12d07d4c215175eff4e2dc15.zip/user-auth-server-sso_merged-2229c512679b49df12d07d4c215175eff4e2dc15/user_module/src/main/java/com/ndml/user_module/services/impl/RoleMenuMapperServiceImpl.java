package com.ndml.user_module.services.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ndml.user_module.exceptions.ApplicationException;
import com.ndml.user_module.exceptions.MenuMasterException;
import com.ndml.user_module.exceptions.RoleException;
import com.ndml.user_module.exceptions.RoleMenuMapperException;
import com.ndml.user_module.model.MenuMaster;
import com.ndml.user_module.model.RoleMaster;
import com.ndml.user_module.model.RoleMenuMapper;
import com.ndml.user_module.repositories.ApplicationMasterRepository;
import com.ndml.user_module.repositories.MenuMasterRepository;
import com.ndml.user_module.repositories.RoleMasterRepository;
import com.ndml.user_module.repositories.RoleMenuMapperRepository;
import com.ndml.user_module.request.RoleMenuMapperRequest;
import com.ndml.user_module.services.RoleMenuMapperService;

@Service
public class RoleMenuMapperServiceImpl implements RoleMenuMapperService {

	Logger log = Logger.getLogger(RoleMenuMapperServiceImpl.class.getName());

	@Autowired
	private RoleMenuMapperRepository roleMenuMapperRepo;

	@Autowired
	private MenuMasterRepository menuMasterRepo;

	@Autowired
	private RoleMasterRepository roleMasterRepo;

	@Autowired
	private ApplicationMasterRepository applicationMasterRepo;

	@Override
	public RoleMenuMapper addNewRoleMenuMapper(RoleMenuMapperRequest request) throws RoleMenuMapperException {
		// TODO Auto-generated method stub

		Optional<RoleMaster> roleMasterOpt = roleMasterRepo.findById(request.getRoleId());
		if (!roleMasterOpt.isPresent())
			throw new RoleException("Please provide a valid Role ID.");

//		Optional<RoleMenuMapper> opt = roleMenuMapperRepo.findById(request.getRoleId());
//		if(opt.isPresent()) throw new RoleMenuMapperException("Menu-List is already mapped with this RoleId! Try updating it.");

		// menuList from request :
		List<Long> menuListFromRequest = request.getMenulist();
		log.info("menuListFromRequest before check : " + menuListFromRequest);

		// getting menuMasterList from DB:
		List<MenuMaster> menuMasterList = menuMasterRepo.findAll();

		// creating List of menuMasterIdList from db menuMasterList:
		List<Long> extractedMenuMasterIdList = new ArrayList<>();
		for (MenuMaster menu : menuMasterList) {
			extractedMenuMasterIdList.add(menu.getMenuId());
		}
		log.info("menuMasterIdList from DB :" + extractedMenuMasterIdList);

		// extracting invalid menu id's from request menuList :
		List<Long> invalidMenuIdList = new ArrayList<>();
		for (long i : menuListFromRequest) {
			if (!extractedMenuMasterIdList.contains(i)) {
				invalidMenuIdList.add(i);
			}
		}

		menuListFromRequest.removeAll(invalidMenuIdList); // removing all invalid menu-id's from request menu-Id-list

		log.info("invalidMenuIdList : " + invalidMenuIdList);
		log.info("menuListFromRequest after check : " + menuListFromRequest);

		if (menuListFromRequest.size() == 0)
			throw new MenuMasterException("Menu-List is empty after check! cannot assign Menu's to this RoleId.");

		if (!applicationMasterRepo.findById(request.getApplicationId()).isPresent())
			throw new ApplicationException("No ApplicationMaster present with this ApplicationID.");

//		RoleMenuMapper roleMenuMapper = new RoleMenuMapper(request.getRoleId(), menuListFromRequest,
//				request.getApplicationId());
		
		RoleMenuMapper roleMenuMapper = new RoleMenuMapper();
		
				
		roleMenuMapper.setCrtdDt(new Date());

		roleMenuMapperRepo.save(roleMenuMapper);

		return roleMenuMapper;
	}

}
