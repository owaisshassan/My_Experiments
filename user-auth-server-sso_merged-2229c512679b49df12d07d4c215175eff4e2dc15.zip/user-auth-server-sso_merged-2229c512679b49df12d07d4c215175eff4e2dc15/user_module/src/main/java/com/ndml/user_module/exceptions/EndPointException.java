package com.ndml.user_module.exceptions;

public class EndPointException extends RuntimeException{
	
	public EndPointException() {
		// TODO Auto-generated constructor stub
	}


	public EndPointException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
	

}
