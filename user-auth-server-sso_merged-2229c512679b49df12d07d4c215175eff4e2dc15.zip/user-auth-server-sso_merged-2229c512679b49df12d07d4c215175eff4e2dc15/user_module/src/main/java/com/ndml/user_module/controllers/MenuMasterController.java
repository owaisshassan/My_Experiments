package com.ndml.user_module.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.cache.annotation.EnableCaching;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ndml.user_module.exceptions.LoginException;
import com.ndml.user_module.model.MenuMaster;
import com.ndml.user_module.request.GetMenuDetailsRequest;
import com.ndml.user_module.request.MenuMasterRegisterRequest;
import com.ndml.user_module.services.MenuMasterService;
import com.ndml.user_module.utility.IsLoggedOutUtil;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/menu")
//@EnableCaching
public class MenuMasterController {

	
	@Autowired
	private MenuMasterService menuService;
	
	
	@Autowired
	private IsLoggedOutUtil isLoggedOutUtil;

	
	
//  localhost:8083/menu/register
	@PostMapping("/register")
	public ResponseEntity<MenuMaster>registerNewApplicationHandler(@RequestBody MenuMasterRegisterRequest request){
		MenuMaster registered =  menuService.addNewMenu(request);
		
		return new ResponseEntity<MenuMaster>(registered,HttpStatus.OK);
	}
	
	
//  localhost:8083/menu/details
	@PostMapping("/details")
	public ResponseEntity<List<MenuMaster>> getMenuDetailsThroughRoleMenuMapperHandler
				(@RequestBody GetMenuDetailsRequest request, HttpServletRequest http) throws Exception{
		
		if(isLoggedOutUtil.logoutStatusWithSecretEncKey (request.getEmail(), http)) throw new LoginException("Please Login first");
		
		List<MenuMaster> result = menuService.getMenuDetailsThroughRoleMenuMapper(request);
		
		return new ResponseEntity<List<MenuMaster>>(result,HttpStatus.OK);
	}
	
	
	
}
