package com.ndml.user_module;



import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = { "com.ndml.*" })
public class UserModuleApplication extends ServletInitializer{

	public static void main(String[] args) {
		SpringApplication.run(UserModuleApplication.class, args);  
		

		
//		String excelFilePath = "E:\\owaisbhat\\Countries.xlsx"; 
//		String excelFilePath = "E:\\Countries.xlsx"; 
//
//		 try (FileInputStream inputStream = new FileInputStream(excelFilePath);
//	             Workbook workbook = new XSSFWorkbook(inputStream)) {
//
//	            Sheet sheet = workbook.getSheetAt(0); 
//	            DataFormatter dataFormatter = new DataFormatter();
//
//	            Integer index = 73853;
//	            
//	            for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
//	                Row row = sheet.getRow(rowIndex);
//	                if (row != null) {
//	                    String column1 = dataFormatter.formatCellValue(row.getCell(1));
//	                    String column2 = dataFormatter.formatCellValue(row.getCell(0));
//	                    String column3 = dataFormatter.formatCellValue(row.getCell(2));
//
//	                 
////	                    INSERT into uatdac.dac_stc_code_mstr (dscm_stc_code_id, dscm_act_flg, dscm_code_desc, dscm_code_grp, dscm_code_id, dscm_code_val) VALUES(56015, 'Y', 'AFGHANISTAN', 'COUNTRY', '01', '001');
//	                    String sql = String.format("INSERT into uatdac.dac_stc_code_mstr (dscm_stc_code_id, dscm_act_flg, dscm_code_desc, dscm_code_grp, dscm_code_id, dscm_code_val) VALUES ( " +index+", 'Y', '%s','COUNTRY', '%s', '%s');",
//	                            sanitize(column1), sanitize(column2), sanitize(column3));
//	                    System.out.println(sql);
//	                    
//	                    index ++;
//	                }
//	            }
//
//	        } catch (IOException e) {
//	            e.printStackTrace();
//	        }
//	    }
//
//	    
//	    private static String sanitize(String value) {
//	     
//	        return value.replace("'", "''"); 
//	    

		
		
		
		//512  Hashes : 
		
//		String input = "Owaiss@123";
//		
//		try { 
//            // getInstance() method is called with algorithm SHA-512 
//            MessageDigest md = MessageDigest.getInstance("SHA-512"); 
//  
//            
//            byte[] messageDigest = md.digest(input.getBytes()); 
//  
//            // Convert byte array into signum representation 
//            BigInteger no = new BigInteger(1, messageDigest); 
//  
//            // Convert message digest into hex value 
//            String hashtext = no.toString(16); 
//  
//            // Add preceding 0s to make it 32 bit 
//            while (hashtext.length() < 32) { 
//                hashtext = "0" + hashtext; 
//            } 
//  
//           System.out.println("hashtext : "+hashtext);
//           
//           //Ndml@123
//           //8fc79bad2f19222ba21748a61741733ca18aa813fcb1c7ae9d48803595ae5de58ff04826e1dd2d315a2134f2f03f1362874485ef083f7818512439411e2ee663
//           //128
//           
//           //Maker@123
//           //cbe1906c54751483449d91b133a8cfd5407850a80f9864d18cc4ffe1e5fe5de7b03fd5b4d6400d092764579f919d1881ba56977cf9c6c737659d8ae107910b95
//           //128
//           
//           //Checker@123
//           //aaad49189f51d5151b515038cdfd4df56b548d106b4f6b0a60e04bc785177782398a4925e48a8deafa56f7abd0f64aa0ab0a0b27c336dedf40be1da8c43cf510
//           //128
//           System.out.println(hashtext.length());
//            
//        }catch (NoSuchAlgorithmException e) { 
//            throw new RuntimeException(e); 
//        } 
		
		
		
		
		
		}
		
	

}
