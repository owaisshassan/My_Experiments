import { Component } from '@angular/core';
import { DisableRightClickService } from './service/disable-right-click.service';
import { AppConfig } from './app.config';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'sso-web';

  constructor(private rightClickDisable: DisableRightClickService, private config: AppConfig) {
    this.rightClickDisable.disableRightClick();
    localStorage.clear();
    sessionStorage.clear();
  }

}
