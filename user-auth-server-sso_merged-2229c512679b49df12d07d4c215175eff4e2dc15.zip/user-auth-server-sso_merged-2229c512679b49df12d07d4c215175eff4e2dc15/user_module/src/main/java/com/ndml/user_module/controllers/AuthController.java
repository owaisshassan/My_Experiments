package com.ndml.user_module.controllers;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Optional;
import java.util.logging.Logger;

import javax.crypto.SecretKey;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
//import org.springframework.cache.annotation.Cacheable;
//import org.springframework.cache.annotation.EnableCaching;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.ndml.user_module.configuration.SecurityConstants;
import com.ndml.user_module.constants.SSOConstants;
import com.ndml.user_module.exceptions.ApplicationException;
import com.ndml.user_module.exceptions.DPMasterException;
import com.ndml.user_module.exceptions.RoleException;
import com.ndml.user_module.jwt.JwtUtils;
import com.ndml.user_module.model.ApplicationMaster;
import com.ndml.user_module.model.CaptchaSerttings;
import com.ndml.user_module.model.DPMaster;
import com.ndml.user_module.model.RequestCaptchaAnswer;
import com.ndml.user_module.model.RoleMaster;
import com.ndml.user_module.model.UserDetails;
import com.ndml.user_module.model.UserDetailsMapperEntity;
import com.ndml.user_module.repositories.ApplicationMasterRepository;
import com.ndml.user_module.repositories.DPMasterRepository;
import com.ndml.user_module.repositories.RoleMasterRepository;
import com.ndml.user_module.repositories.UserDetailsMapperRepository;
import com.ndml.user_module.repositories.UserRepository;
import com.ndml.user_module.request.ApplicationRequestBean;
import com.ndml.user_module.request.CheckTokenRequest;
import com.ndml.user_module.request.LoginRequest;
import com.ndml.user_module.request.LogoutRequest;
import com.ndml.user_module.request.SignupRequest;
import com.ndml.user_module.response.EndpointsResponse;
import com.ndml.user_module.response.GetUserDetailsResponse;
import com.ndml.user_module.response.MessageResponse;
import com.ndml.user_module.response.RefreshTokenResponse;
import com.ndml.user_module.response.SigninResponse;
import com.ndml.user_module.response.SigninResponseBean;
import com.ndml.user_module.services.UserDetailsService;
import com.ndml.user_module.utility.CaptchaGenerator;
import com.ndml.user_module.utility.CaptchaUtil;
import com.ndml.user_module.utility.CustomJwtSecretKeyPair;
import com.ndml.user_module.utility.EncryptDecrypt;
import com.ndml.user_module.utility.JwtCacheUtilWithEncryptKey;

import cn.apiclub.captcha.Captcha;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import jakarta.validation.Valid;

@CrossOrigin(origins = "*", maxAge = 3600, allowedHeaders = "*")
@RestController
@RequestMapping("/auth")
public class AuthController {

	Logger log = Logger.getLogger(AuthController.class.getName());

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	UserRepository userRepository;

	@Autowired
	RoleMasterRepository roleRepository;

	@Autowired
	private UserDetailsMapperRepository udmRepo;

	@Autowired
	private RoleMasterRepository roleMasterRepo;

	@Autowired
	private UserDetailsService userService;

	@Autowired
	private DPMasterRepository dpMasterRepo;

	@Autowired
	private ApplicationMasterRepository applicationMasterRepo;

	@Autowired
	private JwtUtils jwtUtils;

	protected static int numberOfLoginAttempts = 0;

	protected static Date userLoginLockedTime;

	@Value("${ndml.app.jwtSecret}")
	private String jwtSecret;

	@Value("${ndml.app.passExpiryDate}")
	private long passExpDateMS; // 408707229 approx. 5 days

	
	
	@PostMapping("/user/login")
	public ResponseEntity<?> authLoginUser(@Valid @RequestBody LoginRequest loginRequest, HttpServletRequest http,
			HttpServletResponse response) throws Exception {
		log.info("INSIDE LOGIN..");
		System.out.println("Request : "+loginRequest.toString());
		ConcurrentHashMap<String, String> captchaMap = CaptchaUtil.captchaMap;
		SigninResponseBean res =  new SigninResponseBean();;
		
		if(StringUtils.isNotBlank(loginRequest.getCapQue()) && StringUtils.isNotEmpty(loginRequest.getCapQue())
						&& loginRequest.getCapQue() != null ) {
			Boolean captchaFlag = loginRequest.getAnswer()
					.equals(captchaMap.get(loginRequest.getUser() + "|" + loginRequest.getCapQue()));
			System.out.println("captchaFlag : "+captchaFlag);
			captchaMap.remove(loginRequest.getUser() + "|" + loginRequest.getCapQue());
			System.out.println("Captcha questions remaining to be verified : " + captchaMap.size());
//			 res = new SigninResponseBean();
			try {
				if (captchaFlag) {
					log.info("DAC APPLICATION LOGIN..");
				res = userService.dacLogin(loginRequest, http, response);
				} else if (!captchaFlag) {
					res.setMessage("Invalid captcha!");
				}
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("inside stack tree");
				if(e.getMessage().equalsIgnoreCase("Please check your email!") ) {
					System.out.println("inside stack tree1");
					res.setMessage("Wrong Email!");
					System.out.println("old res is " + res);
				}
//				else if(e.getMessage().equalsIgnoreCase("Please check your password!")) {
//					System.out.println("inside stack tree1");
//					res.setMessage("Wrong password!");
//					System.out.println("old res is " + res);
//				}
				else {
					System.out.println("inside stack tree1");
					res.setMessage(e.getMessage());
					System.out.println("old res is " + res);
				}
			}
	 

			System.out.println("res is " + res);
		}else if((loginRequest.getCapQue() == null || loginRequest.getCapQue().equals("")) && StringUtils.isNotBlank(loginRequest.getAppName())
				&& StringUtils.isNotEmpty(loginRequest.getAppName()) && loginRequest.getAppName().equals(SSOConstants.INSTIGO_DIY) ) {
			log.info("SELF-SERVICE APPLICATION LOGIN..");
			res =  userService.selfServiceLogin(loginRequest, http, response);
		}else {
			res.setMessage("Request failed!");
		}
		
		
		return new ResponseEntity<SigninResponseBean>(res, HttpStatus.OK);
	}


	@PostMapping("/user/getallendpoints")
	public ResponseEntity<EndpointsResponse> getEndpointResponse(@RequestBody ApplicationRequestBean appreq)
			throws Exception {
		System.out.println("Inside getEndpointResponse...");
		System.out.println(appreq.getAppid());

		Map<String, List<String>> urls = userService.getAllEndpointsBasedOnAppId(Long.parseLong(appreq.getAppid()));
		EndpointsResponse ep1 = new EndpointsResponse();
		ep1.setEpList(urls);
		System.out.println("Response:- " + ep1.toString());
		return new ResponseEntity<EndpointsResponse>(ep1, HttpStatus.OK);
	}

	@PostMapping("/user/getuserdetails")
	public ResponseEntity<?> getUserDetailsResponseHandler(HttpServletRequest http) throws Exception {

		GetUserDetailsResponse res = userService.getUserDetails(http);

		return new ResponseEntity<GetUserDetailsResponse>(res, HttpStatus.OK);
	}

	@PostMapping("/user/signup")
	// @Cacheable("signupcache")
	public ResponseEntity<?> registerUser(@Valid @RequestBody SignupRequest signUpRequest) throws Exception {

		if (userRepository.existsByUsername(signUpRequest.getUsername())) {
			return ResponseEntity.badRequest().body(new MessageResponse("Error: Username is already taken!"));
		}

		if (userRepository.existsByUseremailId(signUpRequest.getUseremailId())) {
			return ResponseEntity.badRequest().body(new MessageResponse("Error: Email is already in use!"));
		}

		// check :
		Optional<DPMaster> dpOpt = dpMasterRepo.findByDpID(signUpRequest.getDpID());
		if (!dpOpt.isPresent())
			throw new DPMasterException("DPMaster with ID '" + signUpRequest.getDpID() + "' is not found!");

		Optional<ApplicationMaster> appMasterOpt = applicationMasterRepo.findById(signUpRequest.getApplicationId());
		if (!appMasterOpt.isPresent())
			throw new ApplicationException("Please Provide a valid ApplicationId!");

		Optional<RoleMaster> roleOpt = roleMasterRepo.findById(signUpRequest.getRoleId());
		System.out.println(roleOpt.get());
		if (!roleOpt.isPresent())
			throw new RoleException("Please provide a valid Role ID.");

		// Role & Application validation :
		String roleName = roleOpt.get().getRoleName().toLowerCase(); // INSTIGO_user
		String appName = appMasterOpt.get().getApplicationName().toLowerCase(); // INSTIGO

		String[] splittedRoleName = roleName.split("_");
		log.info("splittedRoleName : " + splittedRoleName[0]);
		log.info("appName : " + appName);

		if (!splittedRoleName[0].equals(appName))
			throw new Exception("Please provide a valid RoleId for provided ApplicationId..");
//		if((roleName.charAt(4) != appName.charAt(4))  
//							|| roleName.charAt(5) != appName.charAt(5)) {
//			throw new Exception("Please provide a valid RoleId for provided ApplicationId..");
//		}
//		
		// Create new user's account :
		UserDetails user = new UserDetails(signUpRequest.getUsername(), signUpRequest.getUseremailId(),
				signUpRequest.getUsermobileNumber(), signUpRequest.getPassword(), signUpRequest.getDpID(),
				signUpRequest.getApplicationId(), signUpRequest.getRoleId());

		Date pwdExpDate = new Date((new Date()).getTime() + passExpDateMS);
		user.setPwdexpdt(pwdExpDate);
		user.setCrtdDt((new Date().toString()));

		userRepository.save(user);

		return ResponseEntity.ok(new MessageResponse("User registered successfully!"));
	}

	@PostMapping("/user/logout")
	public ResponseEntity<String> logoutUserHandler(@RequestBody LogoutRequest request, HttpServletRequest http)
			throws Exception {

		log.info(request.getUseremailId());

		String loggedOut = userService.logoutUser(request.getUseremailId(), http);
		SecurityContextHolder.clearContext();
		log.info("Context cleared..");
		return new ResponseEntity<String>(loggedOut, HttpStatus.OK);

	}

	@PostMapping("/user/refreshtoken")
	public ResponseEntity<RefreshTokenResponse> refreshtokenHandler(HttpServletRequest request) throws Exception {

		log.info("inside refreshtoken HANDLER>>>>>>>>");

//		
		String encryptedJWTfromRequestHeader = request.getHeader(SecurityConstants.JWT_HEADER);
//		log.info("encJWT from header : "+encryptedJWTfromRequestHeader);
		encryptedJWTfromRequestHeader = encryptedJWTfromRequestHeader.substring(7);
		log.info("encJWT without bearer : " + encryptedJWTfromRequestHeader);
		// String encryptedJWTfromRequestHeader = refreshTknReq.getJwt();

		log.info("Deleting previous session token..");
		Map<String, Map<CustomJwtSecretKeyPair, Date>> usernameJwtMapper = JwtCacheUtilWithEncryptKey
				.getUserNameJwtMapperWithKey();

		for (String keys : usernameJwtMapper.keySet()) {
			Map<CustomJwtSecretKeyPair, Date> mapp = usernameJwtMapper.get(keys);
			Map<CustomJwtSecretKeyPair, Date> toBeDeletedData = new HashMap<>();
			for (CustomJwtSecretKeyPair pair : mapp.keySet()) {
				if (pair.getTokenKey().equals(encryptedJWTfromRequestHeader)) {
					log.info("FOUND!");
					log.info(pair.toString());
					toBeDeletedData.put(pair, mapp.get(pair));
				}
			}
			for (CustomJwtSecretKeyPair key : toBeDeletedData.keySet()) {
				mapp.remove(key);
			}
		}

//		String encKeyFromHeader = request.getHeader("enckey");
//		log.info("EncKey from Header : "+encKeyFromHeader);
		// String jwt = EncryptDecrypt.decryptData(encKeyFromHeader,
		// encryptedJWTfromRequestHeader);

//		String jwt = JwtExtractorUtil.tokenDecryptionHelper(request);

//		log.info("decryptedJWT : "+jwt);

//		SecretKey key = Keys.hmacShaKeyFor(SecurityConstants.JWT_KEY.getBytes());
		Claims claims = (Claims) request.getAttribute("claims");
//		Claims claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(jwt).getBody();

		// SecretKey key = Keys.hmacShaKeyFor(Decoders.BASE64.decode(jwtSecret));

//		if (claims == null)
//			throw new InvalidPasswordException("Invalid token/un-expired token/User not logged in!");
		log.info("claimssssssssssssssssssss");
		System.out.println(claims);
		System.out.println(claims.getExpiration());

		Map<String, Object> expectedMap = getMapFromIoJsonwebtokenClaims(claims);
		String token = jwtUtils.doGenerateRefreshToken(expectedMap, expectedMap.get("sub").toString());

		log.info("'doGenerateRefreshToken' method finished!");
		System.out.println(JwtCacheUtilWithEncryptKey.getUserNameJwtMapperWithKey());
		// response.setHeader(SecurityConstants.JWT_HEADER, token);
		System.out.println(token);
		// DECODING JWT to get token Expiry & Username :
		DecodedJWT decodedJWT = JWT.decode(token);
		String userName = decodedJWT.getClaim("username").toString();
		Date date = decodedJWT.getExpiresAt();
		log.info("decoded jwt inside auth controller  : " + decodedJWT.getToken());
		log.info("username : " + userName);
		log.info("Expiry date : " + date);

		// Map<String, Map<String, Date>> map = JwtCacheUtil.getUserNameJwtMapper();

		Map<String, Map<CustomJwtSecretKeyPair, Date>> map = JwtCacheUtilWithEncryptKey.getUserNameJwtMapperWithKey();

		String trimmedUserName = "";
		for (int i = 0; i < userName.length(); i++) {
			if (userName.charAt(i) == '"') {
				continue;
			} else {
				trimmedUserName += userName.charAt(i);
			}
		}

		log.info(trimmedUserName);

		// From the HttpRequest get the claims
		System.out.println("UserNameJwtMapperWithKey : ");
//				System.out.println(JwtCacheUtil.getUserNameJwtMapper());
		System.out.println(JwtCacheUtilWithEncryptKey.getUserNameJwtMapperWithKey());

		String encKeyFromDB = dpMasterRepo.findByDpID(userRepository.findByUseremailId(trimmedUserName).getDpID()).get()
				.getEnckey();

		
		//ohb..
		CustomJwtSecretKeyPair csp = new CustomJwtSecretKeyPair();
		String emailPlusJwt = trimmedUserName+" "+token;
		String encToken = EncryptDecrypt.encryptData(encKeyFromDB, emailPlusJwt);
		csp.setTokenKey(encToken);
		csp.setSecretKeyForToken(encKeyFromDB);

		if (map.containsKey(trimmedUserName)) {
			map.get(trimmedUserName).put(csp, date);
		}

//		for (String keys : map.keySet()) {
//
//			// keys = '"'+keys+'"';
//			log.info(keys);
//			if (keys.equals(trimmedUserName)) {
//				log.info("keys equals trimmedUsername");
//				map.get(keys).put(token, date);
//			}
//		}

		log.info("MAP : " + map);

		// ----------

		String d = convertToLocalDateTimeViaSqlTimestamp(date) + "";
		log.info(d);

		log.info("adding new token expiry date to token_expiry_list of  User_details_mapper table..");
		UserDetailsMapperEntity udm = udmRepo.findByUserEmail(trimmedUserName);
		List<String> newTokenExpListUDM = new ArrayList<>();
		for (String expDt : udm.getTokenExpiryList()) {
			newTokenExpListUDM.add(expDt);
		}
		newTokenExpListUDM.add(d);
		udm.setTokenExpiryList(newTokenExpListUDM);

		String trimmedRefreshTkn = (encToken.substring(0, 6))
				+ (encToken.substring(encToken.length() - 6, encToken.length()));
		System.out.println("trimmedRefreshTkn :" + trimmedRefreshTkn);
		List<String> newTokenListUDM = new ArrayList<>();
		for (String tkn : udm.getJwtList()) {
			newTokenListUDM.add(tkn);
		}
		newTokenListUDM.add(trimmedRefreshTkn);
		udm.setJwtList(newTokenListUDM);
		udmRepo.save(udm);
		System.out.println(udm.getJwtList());
		RefreshTokenResponse res = new RefreshTokenResponse(encToken, d);

		return new ResponseEntity<RefreshTokenResponse>(res, HttpStatus.OK);
	}

	// Date conversion-method:: : : :
	LocalDateTime convertToLocalDateTimeViaSqlTimestamp(Date dateToConvert) {
		return new java.sql.Timestamp(dateToConvert.getTime()).toLocalDateTime();
	}

	@PostMapping("/user/logoutfromall")
	public ResponseEntity<String> logoutFromAllDevicesHandler(@RequestBody LogoutRequest request,
			HttpServletRequest http) throws Exception {

		log.info(request.getUseremailId());

		String loggedOut = userService.logoutFromAllDevices(request.getUseremailId(), http);
		SecurityContextHolder.clearContext();

		log.info("Context cleared..");

		return new ResponseEntity<String>(loggedOut, HttpStatus.OK);

	}

	public Map<String, Object> getMapFromIoJsonwebtokenClaims(Claims claims) {
		Map<String, Object> expectedMap = new HashMap<String, Object>();
		for (Entry<String, Object> entry : claims.entrySet()) {
			expectedMap.put(entry.getKey(), entry.getValue());
		}
		return expectedMap;
	}

	// ********************************VALIDATE
	// TOKEN***********************************************

	@PostMapping("/token")
	public boolean validateToken(@RequestBody CheckTokenRequest req, HttpServletRequest request) {

		log.info("encryptedJWTfromReques with Bearer : " + req.getEncryptedToken());
		log.info("Dec_key from request : " + req.getDecKey());
		String jwt = EncryptDecrypt.decryptData(req.getDecKey(), req.getEncryptedToken());

		log.info("decryptedJWT : " + jwt);

		if (jwt != null) {

			try {

				// extracting the word 'Bearer':
				// jwt = jwt.substring(7);

				log.info("decrypted JWT  : " + "\n" + jwt);

				// DECODING JWT to get token Expiry & Username :
				DecodedJWT decodedJWT = JWT.decode(jwt);
				Date date = decodedJWT.getExpiresAt();
				log.info("EXPIRY :" + date);

				SecretKey key = Keys.hmacShaKeyFor(SecurityConstants.JWT_KEY.getBytes());

				Claims claims = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(jwt).getBody();

				String username = String.valueOf(claims.get("username"));

				log.info("USERNAME from claims after decryption : : " + username);

				// it returns the comma separated authorities :
				String authorities = (String) claims.get("authorities");

				List<GrantedAuthority> auths = AuthorityUtils.commaSeparatedStringToAuthorityList(authorities);

				Authentication auth = new UsernamePasswordAuthenticationToken(username, null, auths);

				// Authentication customAuthentication = customAuthProvider.authenticate(auth);

				SecurityContextHolder.getContext().setAuthentication(auth);

			} catch (ExpiredJwtException ex) {
				// TODO: handle exception
				log.info("INSIDE 'ExpiredJwtException' OF CHECK TOKEN.......");

				String isRefreshToken = request.getHeader("isRefreshToken");

				log.info("isRefreshToken from request HEADER: " + isRefreshToken);

				String requestURL = request.getRequestURL().toString();
				log.info("requestURL from request : " + requestURL);
				log.info("ex.getClaims() before if()  : " + ex.getClaims());

				// allow for Refresh Token creation if following conditions are true.
				if (isRefreshToken != null && isRefreshToken.equals("true") && requestURL.contains("refreshtoken")) {
					log.info("calling 'allowForRefreshToken(ex, request)' method...");
					log.info("CLAIMS from 'ExpiredJwtException'  : " + ex.getClaims());

					// allowForRefreshToken(ex, request);

					log.info(request.getHeader("isRefreshToken"));
					log.info("request LocalName : " + request.getLocalName());
					log.info("ex.getClaims() after allowForRefreshToken() inside if()  : " + ex.getClaims());
					log.info("'allowForRefreshToken' Executed!");
				} else
					request.setAttribute("exception", ex);
			} catch (Exception e) {
				throw new BadCredentialsException("Invalid Token received!");
			}
		} else
			return false;

		return true;
	}

	@GetMapping("/checktoken")
	public String checkToken() {

		return "true";
	}

	// ********************************************* old login
	

//	@PostMapping("/user/login")
//	public ResponseEntity<?> authLoginUser(@Valid @RequestBody LoginRequest loginRequest, HttpServletRequest http,
//			HttpServletResponse response) throws Exception {
//
//		SigninResponse res = userService.login(loginRequest, http, response);
//
//		return new ResponseEntity<SigninResponse>(res, HttpStatus.OK);
//	}
	
	
	//new ohb--
	
//	private ConcurrentHashMap<String, String> captchaMap = new ConcurrentHashMap<>();
	
	
//	@PostMapping("/user/login")
//	public ResponseEntity<?> authLoginUser(@Valid @RequestBody LoginRequest loginRequest, HttpServletRequest http,
//			HttpServletResponse response) throws Exception {
//		log.info("INSIDE LOGIN..");
//		System.out.println("Request : "+loginRequest.toString());
//		ConcurrentHashMap<String, String> captchaMap = CaptchaUtil.captchaMap;
//		SigninResponse res ;
//		
//		if(StringUtils.isNotBlank(loginRequest.getCapQue()) && StringUtils.isNotEmpty(loginRequest.getCapQue())
//						&& loginRequest.getCapQue() != null ) {
//			Boolean captchaFlag = loginRequest.getAnswer()
//					.equals(captchaMap.get(loginRequest.getUser() + "|" + loginRequest.getCapQue()));
//			System.out.println("captchaFlag : "+captchaFlag);
//			captchaMap.remove(loginRequest.getUser() + "|" + loginRequest.getCapQue());
//			System.out.println("Captcha questions remaining to be verified : " + captchaMap.size());
//			 res = new SigninResponse();
//			try {
//				if (captchaFlag) {
//					log.info("DAC APPLICATION LOGIN..");
//				res = userService.dacLogin(loginRequest, http, response);
//				} else if (!captchaFlag) {
//					res.setMessage("Invalid captcha!");
//				}
//			} catch (Exception e) {
//				e.printStackTrace();
//				System.out.println("inside stack tree");
//				if(e.getMessage().equalsIgnoreCase("Please check your email!") ) {
//					System.out.println("inside stack tree1");
//					res.setMessage("Wrong Email!");
//					System.out.println("old res is " + res);
//				}
////				else if(e.getMessage().equalsIgnoreCase("Please check your password!")) {
////					System.out.println("inside stack tree1");
////					res.setMessage("Wrong password!");
////					System.out.println("old res is " + res);
////				}
//				else {
//					System.out.println("inside stack tree1");
//					res.setMessage(e.getMessage());
//					System.out.println("old res is " + res);
//				}
//			}
//	 
//
//			System.out.println("res is " + res);
//		}else {
//			log.info("SELF-SERVICE APPLICATION LOGIN..");
//			res =  userService.selfServiceLogin(loginRequest, http, response);
//		}
//		
//		
//		return new ResponseEntity<SigninResponse>(res, HttpStatus.OK);
//	}
	

}
