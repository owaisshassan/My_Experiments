package com.ndml.user_module.response;

import java.util.List;

import com.ndml.user_module.model.EndPointsMaster;

public class GetUserDetailsResponse {

	private String useremail;

	private String username;

	private String roleName;

	private String roleDescription;

	private String application_name;

	private List<CustomResponseMenuMaster> menuList;

	private String accessToken;

	private String expDt;
	
	
	private String dpId;
	private String dpName;
	
	
	
	public String getDpName() {
		return dpName;
	}

	public void setDpName(String dpName) {
		this.dpName = dpName;
	}

	private List<EndPointsMaster> epList;
	
	

	public List<EndPointsMaster> getEpList() {
		return epList;
	}

	public void setEpList(List<EndPointsMaster> epList) {
		this.epList = epList;
	}

	public String getDpId() {
		return dpId;
	}

	public void setDpId(String dpId) {
		this.dpId = dpId;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getExpDt() {
		return expDt;
	}

	public void setExpDt(String expDt) {
		this.expDt = expDt;
	}

	public GetUserDetailsResponse() {
		// TODO Auto-generated constructor stub
	}

	public String getUseremail() {
		return useremail;
	}

	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleDescription() {
		return roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	public String getApplication_name() {
		return application_name;
	}

	public void setApplication_name(String application_name) {
		this.application_name = application_name;
	}

	public List<CustomResponseMenuMaster> getMenuList() {
		return menuList;
	}

	public void setMenuList(List<CustomResponseMenuMaster> menuList) {
		this.menuList = menuList;
	}

	public GetUserDetailsResponse(String useremail, String username, String roleName, String roleDescription,
			String application_name, List<CustomResponseMenuMaster> menuList) {
		super();
		this.useremail = useremail;
		this.username = username;
		this.roleName = roleName;
		this.roleDescription = roleDescription;
		this.application_name = application_name;
		this.menuList = menuList;
	}
	
	

	public GetUserDetailsResponse(String useremail, String username, String roleName, String roleDescription,
			String application_name, List<CustomResponseMenuMaster> menuList, String accessToken, String expDt,
			String dpId) {
		super();
		this.useremail = useremail;
		this.username = username;
		this.roleName = roleName;
		this.roleDescription = roleDescription;
		this.application_name = application_name;
		this.menuList = menuList;
		this.accessToken = accessToken;
		this.expDt = expDt;
		this.dpId = dpId;
	}
	
	

	public GetUserDetailsResponse(String useremail, String username, String roleName, String roleDescription,
			String application_name, List<CustomResponseMenuMaster> menuList, String accessToken, String expDt,
			String dpId, List<EndPointsMaster> epList) {
		super();
		this.useremail = useremail;
		this.username = username;
		this.roleName = roleName;
		this.roleDescription = roleDescription;
		this.application_name = application_name;
		this.menuList = menuList;
		this.accessToken = accessToken;
		this.expDt = expDt;
		this.dpId = dpId;
		this.epList = epList;
	}
	
	

	public GetUserDetailsResponse(String useremail, String username, String roleName, String roleDescription,
			String application_name, List<CustomResponseMenuMaster> menuList, String accessToken, String expDt,
			String dpId, String dpName, List<EndPointsMaster> epList) {
		super();
		this.useremail = useremail;
		this.username = username;
		this.roleName = roleName;
		this.roleDescription = roleDescription;
		this.application_name = application_name;
		this.menuList = menuList;
		this.accessToken = accessToken;
		this.expDt = expDt;
		this.dpId = dpId;
		this.dpName = dpName;
		this.epList = epList;
	}

	@Override
	public String toString() {
		return "GetUserDetailsResponse [useremail=" + useremail + ", username=" + username + ", roleName=" + roleName
				+ ", roleDescription=" + roleDescription + ", application_name=" + application_name + ", menuList="
				+ menuList + ", accessToken=" + accessToken + ", expDt=" + expDt + ", dpId=" + dpId + ", dpName="
				+ dpName + ", epList=" + epList + "]";
	}




}
