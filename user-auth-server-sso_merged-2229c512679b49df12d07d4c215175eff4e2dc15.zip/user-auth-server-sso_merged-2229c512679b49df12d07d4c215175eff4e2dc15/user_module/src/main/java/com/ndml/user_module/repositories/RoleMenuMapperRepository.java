package com.ndml.user_module.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ndml.user_module.model.RoleMenuMapper;

public interface RoleMenuMapperRepository extends JpaRepository<RoleMenuMapper, Long>{
	
//	select rolemenuma0_.role_id as role_id1_5_, rolemenuma0_.application_id as applicat2_5_, rolemenuma0_.crtd_dt as crtd_dt3_5_, rolemenuma0_.updt_dt as updt_dt4_5_ from role_menu_mapper rolemenuma0_

	@Query(value = "select * from role_menu_mapper rmp where rmp.role_id = ?", nativeQuery = true)
	public RoleMenuMapper findByRoleId(long roleId);
	
	List<RoleMenuMapper> findByApplicationId(long applicationId);
}
