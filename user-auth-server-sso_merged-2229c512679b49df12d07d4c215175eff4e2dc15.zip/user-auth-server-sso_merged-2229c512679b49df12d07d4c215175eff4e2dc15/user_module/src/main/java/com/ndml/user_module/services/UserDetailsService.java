package com.ndml.user_module.services;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.ResponseEntity;

import com.ndml.user_module.exceptions.RoleException;
import com.ndml.user_module.exceptions.UserDetailsException;
import com.ndml.user_module.model.UserDetails;
import com.ndml.user_module.request.ForgotPasswordRequest;
import com.ndml.user_module.request.LoginRequest;
import com.ndml.user_module.request.RequestNewResetPassword;
import com.ndml.user_module.response.GetPwrdSaltResponseBean;
import com.ndml.user_module.response.GetUserDetailsResponse;
import com.ndml.user_module.response.ResetPasswordResponseBean;
import com.ndml.user_module.response.SigninResponse;
import com.ndml.user_module.response.SigninResponseBean;

public interface UserDetailsService {
	
	//NOTE : Please find SignUp and SignIn services in Auth controller.
	
//	public TempSigninResponse login (LoginRequest loginRequest,HttpServletRequest http,
//			HttpServletResponse response)   throws Exception; 
	
//	public String login (LoginRequest loginRequest,HttpServletRequest http,
//			HttpServletResponse response)   throws Exception; 
	
//	public SigninResponse dacLogin (LoginRequest loginRequest,HttpServletRequest http,
//			HttpServletResponse response)   throws Exception; 
	
//	public SigninResponse selfServiceLogin (LoginRequest loginRequest,HttpServletRequest http,
//			HttpServletResponse response)   throws Exception;
	
	
	public SigninResponseBean dacLogin (LoginRequest loginRequest,HttpServletRequest http,
			HttpServletResponse response)   throws Exception; 
	
	public SigninResponseBean selfServiceLogin (LoginRequest loginRequest,HttpServletRequest http,
			HttpServletResponse response)   throws Exception; 
	
	public List<UserDetails> getAllUsers(String email) throws UserDetailsException, RoleException;

	public String logoutUser(String email,HttpServletRequest http) throws Exception;
	
	public String forgotPassword(ForgotPasswordRequest request) throws UserDetailsException;

	public ResetPasswordResponseBean resetPassword(RequestNewResetPassword request) throws UserDetailsException;
	
	public GetUserDetailsResponse getUserDetails (HttpServletRequest http)   throws Exception;  
	
	public String logoutFromAllDevices(String email,HttpServletRequest http) throws Exception;
	
	Map<String, List<String>> getAllEndpointsBasedOnAppId(Long appId);
	
	public GetPwrdSaltResponseBean getRandomPasswordSalt(LoginRequest req)  throws Exception; 

}
