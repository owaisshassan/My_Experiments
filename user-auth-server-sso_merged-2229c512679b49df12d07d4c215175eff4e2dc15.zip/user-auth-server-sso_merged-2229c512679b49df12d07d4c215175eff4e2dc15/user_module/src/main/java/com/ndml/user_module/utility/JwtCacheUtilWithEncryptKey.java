package com.ndml.user_module.utility;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import com.ndml.user_module.response.ActiveUserResponse;

/*This class is to maintain Currently logged-in users
 * checks : 
 * logged-in users,
 * logout,
 * unique sessions based on user email, secret-key, jwt token..   */
public class JwtCacheUtilWithEncryptKey {

	private static Map<String, Map<CustomJwtSecretKeyPair, Date>> userNameJwtMapperWithKey = new HashMap<String, Map<CustomJwtSecretKeyPair, Date>>();

	public static Map<String, Map<CustomJwtSecretKeyPair, Date>> getUserNameJwtMapperWithKey() {
		return userNameJwtMapperWithKey;
	}

	public static void setUserNameJwtMapperWithKey(
			Map<String, Map<CustomJwtSecretKeyPair, Date>> userNameJwtMapperWithKey) {
		JwtCacheUtilWithEncryptKey.userNameJwtMapperWithKey = userNameJwtMapperWithKey;
	}

	static Logger log = Logger.getLogger(JwtCacheUtil.class.getName());

	public static Map<String, Map<CustomJwtSecretKeyPair, Date>> currentUserjwtCacheDetailsWithkey(String username,
			CustomJwtSecretKeyPair customKeyobj, Date expiry) {

		if (userNameJwtMapperWithKey.containsKey(username)) {

			if (userNameJwtMapperWithKey.get(username).containsKey(customKeyobj)) {
				if ((userNameJwtMapperWithKey.get(username).get(customKeyobj)).compareTo(expiry) == 0)
					log.warning("username, Jwt, SecretKey, expiry are already present.");

			}
			userNameJwtMapperWithKey.get(username).put(customKeyobj, expiry);
			log.info("jwt + expiry added to 'userNameJwtMapper' for '" + username + "' ");

		} else {
			Map<CustomJwtSecretKeyPair, Date> jwtExpiryMapper = new HashMap<>();
			jwtExpiryMapper.put(customKeyobj, expiry);
			userNameJwtMapperWithKey.put(username, jwtExpiryMapper);
		}

		System.out.println("Active Users : " + userNameJwtMapperWithKey.size());
		System.out.println("Active Users List : ");
		userNameJwtMapperWithKey.entrySet().forEach(c -> System.out.println(c));

		return userNameJwtMapperWithKey;
	}
	

//	public static boolean isUserSessionActive(String username, String token, String decryptKey,Date expiry) {
//		
//		boolean isActive = false;
//		
//		CustomJwtSecretKeyPair customKeyobj = new CustomJwtSecretKeyPair();
//		customKeyobj.setTokenKey(token);
//		customKeyobj.setSecretKeyForToken(decryptKey);
//		
//		
//		if (userNameJwtMapperWithKey.containsKey(username)) {
//
//			if (userNameJwtMapperWithKey.get(username).containsKey(customKeyobj)) {
//				if ((userNameJwtMapperWithKey.get(username).get(customKeyobj)).compareTo(expiry) == 0)
//					log.warning("SESSION IS ACTIVE IN SSO FOR "+ username);
//				isActive = true;
//			}
//		}
//		
//		log.info("jwt + expiry added to 'userNameJwtMapper' for '" + username + "' ");
//		
//		return isActive;
//
//	}
	
    public static ActiveUserResponse isUserSessionActive(String username, String token, String decryptKey) {
		
    	ActiveUserResponse response = new ActiveUserResponse();
		
		CustomJwtSecretKeyPair customKeyobj = new CustomJwtSecretKeyPair();
		customKeyobj.setTokenKey(token);
		customKeyobj.setSecretKeyForToken(decryptKey);
		
		log.info("PAIR :"+customKeyobj.toString());
		
		
		if (userNameJwtMapperWithKey.containsKey(username)) {
			log.info("USERNAME FOUND IN ACTIVE USERS!");
			log.info("FINDING SESSION...");
			
			if (userNameJwtMapperWithKey.get(username).containsKey(customKeyobj)) {
				log.info("SESSION FOUND SUCCESSFULLY!");
				response.setUserSessionActive(true);
			}
		}
		
		log.info("Calling deleteAllExpiredSessions..");
		String deleteAllExpiredSessionsResponse = deleteAllExpiredSessions();
		log.info(deleteAllExpiredSessionsResponse);
		
		return response;

	}
    
    
    public static String deleteAllExpiredSessions() {
    	String deletionSuccessMsg = "All expired sessions of all users deleted successfully!";
    	
    	System.out.println("OHB LOGS...");
    	System.out.println();
    	System.out.println("ALL SESSIONS BEFORE CHECKING & DELETING EXPIRED SESSIONS..");
    	System.out.println();
    	System.out.println(userNameJwtMapperWithKey);
    	System.out.println();
    	System.out.println("DELETION OF EXPIRED SESSIONS STARTS...");
    	System.out.println();
    	
    	userNameJwtMapperWithKey.entrySet().forEach(e ->{
    		 
    		 Map<CustomJwtSecretKeyPair, Date> allSessionsOfUser = e.getValue();
    		 
    		 List<CustomJwtSecretKeyPair> toBedeletedSessions = new ArrayList<>();
    		 
    		  allSessionsOfUser.entrySet().forEach(v ->{
    	    	if(v.getValue().before(new Date())) {
    	    		System.out.println("Expiry dateTime for "+e.getKey() + " is :"+v.getValue());
    	    		System.out.println("isExpiredSession : "+v.getValue().before(new Date()));
    	    		System.out.println("Deleting this session...");
//    	    		allSessionsOfUser.remove(v.getKey());
    	    		toBedeletedSessions.add(v.getKey());
    	    	}
    		  });
    		  
    		  toBedeletedSessions.forEach(s ->{
    			  allSessionsOfUser.remove(s);
    		  });
    		  
    		 
    		 
    	});
    	
    	System.out.println();
    	System.out.println("ALL SESSIONS AFTER DELETING EXPIRED SESSIONS..");
    	System.out.println();
    	System.out.println(userNameJwtMapperWithKey);
    	System.out.println();
    	System.out.println("DELETION OF EXPIRED SESSIONS ENDS...");
    	System.out.println();
    	
    	return deletionSuccessMsg;
    }

}
