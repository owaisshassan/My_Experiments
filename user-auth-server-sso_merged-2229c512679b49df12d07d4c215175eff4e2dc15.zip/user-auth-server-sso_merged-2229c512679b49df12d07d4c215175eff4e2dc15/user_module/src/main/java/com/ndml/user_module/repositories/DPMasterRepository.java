package com.ndml.user_module.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ndml.user_module.model.DPMaster;

public interface DPMasterRepository extends JpaRepository<DPMaster, Long>{
	
	@Query(value = "select * from dpmaster d where d.dpname = ?", nativeQuery = true)
	public DPMaster findByDPName(String dpName);
	
	@Query(value = "select * from dpmaster d where d.dpid = ?", nativeQuery = true)
	public Optional<DPMaster> findByDpID(String dpid);


}
