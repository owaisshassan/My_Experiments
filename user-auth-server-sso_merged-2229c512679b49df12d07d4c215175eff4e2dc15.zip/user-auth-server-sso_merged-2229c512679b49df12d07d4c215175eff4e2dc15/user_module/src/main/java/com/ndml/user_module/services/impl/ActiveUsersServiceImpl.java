package com.ndml.user_module.services.impl;

import org.springframework.stereotype.Service;

import com.ndml.user_module.response.ActiveUserResponse;
import com.ndml.user_module.services.ActiveUsersService;
import com.ndml.user_module.utility.JwtCacheUtilWithEncryptKey;

@Service
public class ActiveUsersServiceImpl implements ActiveUsersService{



	@Override
	public ActiveUserResponse isUserSessionActive(String username, String sessionToken, String decryptKey) {
		
		ActiveUserResponse booleanResponse = JwtCacheUtilWithEncryptKey.isUserSessionActive(username, sessionToken, 
				decryptKey);
		
		return booleanResponse;
	}
}
