package com.ndml.user_module.exceptions;

public class NotFoundException extends RuntimeException{

	
	public NotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public NotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}
