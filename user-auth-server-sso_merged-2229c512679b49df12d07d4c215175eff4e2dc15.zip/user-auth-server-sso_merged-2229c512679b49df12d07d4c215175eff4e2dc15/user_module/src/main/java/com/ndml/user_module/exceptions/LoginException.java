package com.ndml.user_module.exceptions;

public class LoginException extends RuntimeException{
	
	public LoginException() {
		// TODO Auto-generated constructor stub
	}
	
	public LoginException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
	
	

}
