package com.ndml.user_module.services.impl;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ndml.user_module.constants.SSOConstants;
import com.ndml.user_module.exceptions.SSOBusinessException;
import com.ndml.user_module.response.FetchOtpDetailsResponse;
import com.ndml.user_module.model.OTPDetails;
import com.ndml.user_module.model.UserDetails;
import com.ndml.user_module.response.ValidateOtpResponse;
import com.ndml.user_module.repositories.OneTimePasswordRepository;
import com.ndml.user_module.repositories.UserRepository;
import com.ndml.user_module.request.OTPRequestBean;
import com.ndml.user_module.request.OTPValidationRequestBean;
import com.ndml.user_module.services.CommonService;
import com.ndml.user_module.services.OtpService;
import com.ndml.user_module.utility.SSOUtilities;

import in.co.nsdl.notification.client.MapElement;
import in.co.nsdl.notification.client.NotificationRequest;
import in.co.nsdl.notification.client.NotificationRequestHeader;
import in.co.nsdl.notification.client.NotificationRequestPayload;
//import in.co.nsdl.notification.client.mq.NotificationMQClient;

@Service
public class OtpServiceImpl implements OtpService {
	private static final Logger logger = LoggerFactory.getLogger(OtpServiceImpl.class);

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private OneTimePasswordRepository otpRepository;

	@Autowired
	private CommonService commonService;

//	@Autowired
//	NotificationMQClient notificationMQClient;

	@Value("${ndml.notificationType}")
	private String notificationType;

	@Value("${ndml.notification.channel.id}")
	private String notificationChannelId;

	@Value("${ndml.sms.notification.message.type}")
	private String smsNotificationMsgType;

	@Value("${ndml.notificationUrl}")
	private String notificationUrl;

	@Value("${ndml.notification.src.app}")
	private String notificatoinSrcApp;

	@Value("${ndml.proxy.host.name}")
	private String proxyHostName;

	@Value("${ndml.proxy.port.name}")
	private String proxyPortName;

	@Autowired
	MessageSource messageSource;

	@Value("${ndml.otp.count}")
	private String maxOtpCount;
	
	
	@Value("${ndml.otp.timeout}")
	private String ssoOtpTimeout;
	
	
	@Value("${ndml.notification.template.id}")
	private String notificationTemplateId;

	
	

	@Override
	public FetchOtpDetailsResponse fetchOtpDetails(OTPRequestBean requestBean) throws Exception {
		logger.info("Fetch OTP Details service START");
		FetchOtpDetailsResponse fetchOtpDetailsResponse = new FetchOtpDetailsResponse();

		Optional<UserDetails> fetchedUser = userRepository.findByUseremailIdAndMobile(requestBean.getEmail(),requestBean.getMobileNo());
		if (!fetchedUser.isPresent()) {
			logger.info("User not found using email id " + requestBean.getEmail());
			String wrongEmailErrorMsg = SSOConstants.WRONG_CREDENTIALS; 
			fetchOtpDetailsResponse.setSaved(false);
			fetchOtpDetailsResponse.setErrorMsg(wrongEmailErrorMsg);
			
			return fetchOtpDetailsResponse;
		}
		logger.info("User Fetched successfully using email id");

//		try {
			OTPDetails otpDetailsEntity = commonService.checkResendOtpCount(requestBean.getRequestType(), requestBean.getMobileNo(),
					requestBean.getEmail());
			logger.info("Checked resend otp count");
			if (otpDetailsEntity != null) {
				logger.info("otpDetailsEntity != null");
				int count = otpDetailsEntity.getOtpGenerationCount();
				int count1 = otpDetailsEntity.getErrOtpGenerationCount();
				
				long diff = System.currentTimeMillis() - otpDetailsEntity.getOtpTimestamp();
				long diffMinutes = diff / (60 * 1000);
				logger.info("diff : "+diff);
				logger.info("diffMinutes : "+diffMinutes);

			
				if(count >= Integer.parseInt(maxOtpCount) && diffMinutes > Integer.parseInt(ssoOtpTimeout)) {
					otpDetailsEntity.setOtpGenerationCount(0);
				}
				Long waitTime = 1l;
				
				if(diffMinutes < Integer.parseInt(ssoOtpTimeout)) {
					waitTime = Integer.parseInt(ssoOtpTimeout) - diffMinutes;
				}
				if (count >= Integer.parseInt(maxOtpCount) && diffMinutes <= Integer.parseInt(ssoOtpTimeout)) {
					logger.error("error.otp.wait");
					
					String timeOutMsg = messageSource.getMessage("error.otp.wait", null, Locale.ENGLISH) + " " + waitTime + " minute/s.";
					
					fetchOtpDetailsResponse.setSaved(false);
					fetchOtpDetailsResponse.setErrorMsg(timeOutMsg);
				} else {
					saveOtpDetails(otpDetailsEntity, requestBean, requestBean.getMobileNo(), fetchedUser.get());
					fetchOtpDetailsResponse.setSaved(true);
				}
			
			
			} else {
				logger.info("otpDetailsEntity == null");
				saveOtpDetails(otpDetailsEntity, requestBean, requestBean.getMobileNo(), fetchedUser.get());
				fetchOtpDetailsResponse.setSaved(true);
			}
//		} catch (Exception e) {
//			logger.info("Exception occured while checking resend otp count");
//		}

		logger.info("Fetch OTP Details service END");
		return fetchOtpDetailsResponse;
	}

	

	public void saveOtpDetails(OTPDetails otpDetailsEntity, OTPRequestBean otpRequestBean, String mobileNumber,
			UserDetails userBean) throws Exception {
		logger.info("Inside saveOtpDetails method");
		String otp = SSOUtilities.showRandomInteger();

		NotificationRequest request = new NotificationRequest();

		HttpHeaders requestHeader = new HttpHeaders();
		requestHeader.setContentType(MediaType.APPLICATION_JSON);

		logger.info("Setting header for notification");

		NotificationRequestHeader header = new NotificationRequestHeader();
		header.setChannelId(notificationChannelId);
		header.setMessageType(smsNotificationMsgType);
		header.setPriority(1);
		String transId = SSOUtilities.generateUniqueKeyUsingUUID();
		header.setRequestId(transId);
		header.setSrcAppName("DAC");
		header.setTemplateId("dac_verification");
		header.setTimestamp(SSOUtilities.generateTimestamp());
		header.setUserId("vishal.gupta@nsdl.co.in");

		logger.info("Setting Payload for notification");
		NotificationRequestPayload payload = new NotificationRequestPayload();
//		payload.setClientId("dac_verification");
		payload.setMobileNo(Long.parseLong(userBean.getUsermobileNumber()));


		logger.info("Setting MapElements for notification");
		MapElement element = null;
		List<MapElement> mapElements = new ArrayList<MapElement>();

		element = new MapElement();
		element.setKey("OTP");
		element.setValue(otp);
		mapElements.add(element);

		element = new MapElement();
		element.setKey("DP_NAME");
		element.setValue(otpRequestBean.getEmail());
		mapElements.add(element);

		payload.setMapElements(mapElements);


		request.setHeader(header);
		request.setPayload(payload);

		logger.info("Body: " + request.toString());

		logger.info("Gupshup SMS>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>: ");
		HttpEntity<?> requestEntity = new HttpEntity<>(request, requestHeader);
		ResponseEntity<String> mobileotpresponse = null, emailotpresponse = null;

		System.out.println(requestEntity);
		System.out.println(notificationUrl);

		Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress(proxyHostName, Integer.parseInt(proxyPortName)));

		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
		requestFactory.setProxy(proxy);
		RestTemplate restTemplate = new RestTemplate();
		mobileotpresponse = restTemplate.exchange(notificationUrl, HttpMethod.POST, requestEntity, String.class,
				new Object[0]);
		logger.info("RESPONDE CODE FROM NOTIFICATION ENGINE : " + mobileotpresponse.getStatusCode());

		if (otpDetailsEntity == null) {
			otpDetailsEntity = new OTPDetails();
			otpDetailsEntity.setOtpTimestamp(System.currentTimeMillis());
			otpDetailsEntity.setOtpRequestType(otpRequestBean.getRequestType());
			otpDetailsEntity.setMobileNumber(mobileNumber);
			otpDetailsEntity.setEmailId(otpRequestBean.getEmail());
			otpDetailsEntity.setCreatedTimestamp(new Timestamp(System.currentTimeMillis()));
		} else {
			otpDetailsEntity.setUpdatedTimestamp(new Timestamp(System.currentTimeMillis()));
			otpDetailsEntity.setOtpTimestamp(System.currentTimeMillis());
		}

		otpDetailsEntity.setOneTimePassword(otp);
		otpDetailsEntity.setOtpGenerationCount(
				otpDetailsEntity.getOtpGenerationCount() == 0 ? 1 : otpDetailsEntity.getOtpGenerationCount() + 1);
		int count = otpDetailsEntity.getErrOtpGenerationCount();
		if (count > 0) {
			otpDetailsEntity.setErrOtpGenerationCount(0);
			otpDetailsEntity.setValidateFlg("");
		}
		otpDetailsEntity = otpRepository.save(otpDetailsEntity);

		if (otpDetailsEntity == null) {
			logger.error(messageSource.getMessage("error.otp.save", null, Locale.ENGLISH));
			logger.info(messageSource.getMessage("error.otp.save", null, Locale.ENGLISH));

			throw new SSOBusinessException(SSOConstants.SSO_CUSTOM_EXCEPTION,
					messageSource.getMessage("error.otp.save", null, Locale.ENGLISH));
		}
	}

	@Override
	public ValidateOtpResponse validateOtp(OTPValidationRequestBean requestBean) throws Exception {
		logger.info("Validate OTP service START");
		
		
		ValidateOtpResponse validateOtpResponse = new ValidateOtpResponse(); 

		OTPDetails otpDetailsEntity = commonService.checkResendOtpCount(requestBean.getRequestType(),requestBean.getMobileNo(),
				requestBean.getEmailId());
		
		System.out.println("otpDetailsEntity :");
		System.out.println(otpDetailsEntity);

		if (otpDetailsEntity != null) {
			if (requestBean.getOtp().equalsIgnoreCase(otpDetailsEntity.getOneTimePassword())) {
				long diff = System.currentTimeMillis() - otpDetailsEntity.getOtpTimestamp();
				long diffMinutes = diff / (60 * 1000);
				logger.info("diff : "+diff);
				logger.info("diffMinutes : "+diffMinutes);

				if (diffMinutes <= 5) {

					otpDetailsEntity.setValidateFlg("Y");
					otpRepository.save(otpDetailsEntity);

					validateOtpResponse.setValid(true);
				} else {
					logger.error("Excedeed OTP timeout limit. Please try again after sometime..!");
					otpDetailsEntity.setValidateFlg("N");
					otpRepository.save(otpDetailsEntity);
					validateOtpResponse.setValid(false);
					validateOtpResponse.setErrorMsg(messageSource.getMessage("error.otp.timeout", null, Locale.ENGLISH));

				}
			} else {
				int count = otpDetailsEntity.getErrOtpGenerationCount();

				if (count >= Integer.parseInt(maxOtpCount)) {
					logger.error("error.retry.count");
					
					validateOtpResponse.setValid(false);
					validateOtpResponse.setErrorMsg(messageSource.getMessage("error.retry.count", null, Locale.ENGLISH));
					
				} else {
					logger.error("Entered OTP do not match.");
					otpDetailsEntity.setValidateFlg("N");
					otpDetailsEntity.setErrOtpGenerationCount(otpDetailsEntity.getErrOtpGenerationCount() == 0 ? 2
							: otpDetailsEntity.getErrOtpGenerationCount() + 1);
					otpRepository.save(otpDetailsEntity);
					
					validateOtpResponse.setValid(false);
					validateOtpResponse.setErrorMsg(messageSource.getMessage("error.wrong.otp", null, Locale.ENGLISH));

				}
			}
		} else {
			logger.error("No such OTP exists for user.");

			
			
			validateOtpResponse.setValid(false);
			validateOtpResponse.setErrorMsg(messageSource.getMessage("error.wrong.otp", null, Locale.ENGLISH));
			
			otpDetailsEntity.setValidateFlg("N");
			otpRepository.save(otpDetailsEntity);

			
		}
		logger.info("Validate OTP service END");
		return validateOtpResponse;
	}

}
