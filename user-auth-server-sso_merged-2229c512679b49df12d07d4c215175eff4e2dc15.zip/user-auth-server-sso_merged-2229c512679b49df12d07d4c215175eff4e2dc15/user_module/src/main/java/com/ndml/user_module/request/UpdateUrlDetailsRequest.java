package com.ndml.user_module.request;

public class UpdateUrlDetailsRequest {

	private String userEmail;

	private String url;

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
