package com.ndml.user_module.services;

import com.ndml.user_module.model.EndPointsMaster;
import com.ndml.user_module.request.EndPointsRegisterRequest;

public interface EndPointsService {
	
	public EndPointsMaster registerNewEndPoint(EndPointsRegisterRequest req);

}
