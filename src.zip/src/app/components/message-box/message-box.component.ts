import { Component, OnInit, Input } from '@angular/core';
import { Subscription } from 'rxjs';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-message-box',
  templateUrl: './message-box.component.html',
  styleUrls: ['./message-box.component.scss']
})
export class MessageBoxComponent implements OnInit {

  @Input() message: string;
  @Input() secondMessage: string;
  @Input() title: string;
  @Input() btnOkText: string;
  @Input() btnCancelText: string;
  @Input() btnVal1: boolean;
  @Input() btnVal2: boolean;
  @Input() digimessage: string;
  
  flag: any;
  subscription: Subscription;






  constructor(public dialogRef: MatDialogRef<MessageBoxComponent>) {



  }

  ngOnInit() {
  }

  confirmSelection() {

    this.dialogRef.close(this.flag);
  }

}
