package com.ndml.user_module.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ndml.user_module.model.UserDetails;

@Repository
public interface UserRepository extends JpaRepository<UserDetails, Long>{
	
	
	  Optional<UserDetails> findByUsername(String username);
	
	  Boolean existsByUsername(String username);
	
	  Boolean existsByUseremailId(String useremailId);
	  
	  @Query(value = "select * from user_details u where u.useremail_id = :useremailId", nativeQuery = true)
	  public UserDetails findByUseremailId(@Param("useremailId")String useremailId);
	  
	  Optional<UserDetails> findByResetPasswordToken(String resetPasswordToken);
	  
	  @Query(value = "select * from user_details u where u.useremail_id=:userEmailId and u.usermobile_number=:userMobileNo", nativeQuery = true)
	  Optional<UserDetails> findByUseremailIdAndMobile(@Param("userEmailId") String userEmailId,
				@Param("userMobileNo") String userMobileNo);

}
