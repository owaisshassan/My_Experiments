package com.ndml.user_module.response;

public class SigninResponse {

	private String token;

	private String redirectURL;

	private String expDt;

	private String emailId;
	
	//new ohb - 
	private String message;
	
	
	
	

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}


	public String getExpDt() {
		return expDt;
	}

	public void setExpDt(String expDt) {
		this.expDt = expDt;
	}

	public String getRedirectURL() {
		return redirectURL;
	}

	public void setRedirectURL(String redirectURL) {
		this.redirectURL = redirectURL;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public SigninResponse() {
		
	}

	public SigninResponse(String token, String redirectURL) {
		super();
		this.token = token;
		this.redirectURL = redirectURL;
	}

	public SigninResponse(String token, String redirectURL, String expDt, String emailId) {
		super();
		this.token = token;
		this.redirectURL = redirectURL;
		this.expDt = expDt;
		this.emailId = emailId;
	}

	@Override
	public String toString() {
		return "SigninResponse [token=" + token + ", redirectURL=" + redirectURL + ", expDt=" + expDt + ", emailId="
				+ emailId + ", message=" + message + "]";
	}

	
	
	

	
}
