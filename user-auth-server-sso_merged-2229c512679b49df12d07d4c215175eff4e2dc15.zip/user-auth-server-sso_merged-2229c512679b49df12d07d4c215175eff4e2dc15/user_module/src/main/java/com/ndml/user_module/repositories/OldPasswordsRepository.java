package com.ndml.user_module.repositories;

import java.util.List;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

//import com.ndml.user_module.model.OldPasswords;
import com.ndml.user_module.model.OldPasswordsEntity;

public interface OldPasswordsRepository extends JpaRepository<OldPasswordsEntity, Integer> {

//	@Query(value = "select * from old_passwords e where e.password_owner_email = :passwordOwnerId ORDER BY e.created_at DESC LIMIT 3", nativeQuery = true)
//	List<OldPasswords> findByPasswordOwnerId(String passwordOwnerId);
	
	
	@Query(value = "select * from old_passwords_tbl e where e.user_email = :passwordOwnerId", nativeQuery = true)
	OldPasswordsEntity findByPasswordOwnerId(String passwordOwnerId);
	
	@Modifying
	@Transactional
	@Query(value = "delete from old_passwords_tbl e where e.user_email = :email and e.id = :id ", nativeQuery = true)
	void updateOldPasswords(String email, Integer id);

}
