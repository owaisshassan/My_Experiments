package com.ndml.user_module.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ndml.user_module.model.ApplicationMaster;

public interface ApplicationMasterRepository extends JpaRepository<ApplicationMaster, Long>{
	
	@Query(value = "select * from application_master a where a.application_name = ?", nativeQuery = true)
	public ApplicationMaster findByApplicationName(String applicationName);

}
