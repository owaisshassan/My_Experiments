package com.ndml.user_module.exceptions;

public class AddUrlException extends RuntimeException{
	
	public AddUrlException() {
		// TODO Auto-generated constructor stub
	}
	
	public AddUrlException(String error){
		super(error);
	}

}
