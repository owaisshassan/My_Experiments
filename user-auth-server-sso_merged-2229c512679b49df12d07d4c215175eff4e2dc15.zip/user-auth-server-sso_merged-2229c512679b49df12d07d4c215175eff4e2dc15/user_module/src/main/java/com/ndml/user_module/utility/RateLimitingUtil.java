package com.ndml.user_module.utility;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ndml.user_module.request.OTPRequestBean;
import com.ndml.user_module.services.OtpService;
import com.ndml.user_module.services.impl.OtpServiceImpl;

@Component
public class RateLimitingUtil {
	
 
	public static ConcurrentHashMap<String, ConcurrentHashMap<LocalDateTime, Integer>> ipBasedRateLimitMap = new ConcurrentHashMap<>();
	
 
	public static boolean rateLimit(HttpServletRequest http,Integer maxOtpAllowedForIp) {

		System.out.println("maxOtpCount--- : "+maxOtpAllowedForIp);

	     LocalDateTime currentTime = LocalDateTime.now();
	     ConcurrentHashMap<LocalDateTime, Integer> userLastHit =  ipBasedRateLimitMap.get(http.getRemoteHost());
	     LocalDateTime key = null;
	     Integer value = null;
	     if(userLastHit!=null) {
	    	 for(Map.Entry<LocalDateTime, Integer> k : userLastHit.entrySet()) {
		    	 key = k.getKey();
		    	 value = k .getValue();
		     }
	    	
	    	 System.out.println("ChronoUnit.MINUTES.between(key, currentTime) " + ChronoUnit.MINUTES.between(key, currentTime) +" value " + value);
	    	 if(ChronoUnit.MINUTES.between(key, currentTime)<1) {
	    		 if(value >= maxOtpAllowedForIp) {
	    			 if(ChronoUnit.MINUTES.between(key, currentTime)<1) {	
	    	    		 return false;
	    			 }
	    			 else {
	    				ConcurrentHashMap<LocalDateTime, Integer> map = new ConcurrentHashMap<LocalDateTime, Integer>();
		    	    	map.put(LocalDateTime.now(), 0);
		    	    	ipBasedRateLimitMap.put(http.getRemoteHost(), map);
		    	    	return true;
	    			 }
	    		 }
	    		 else {
		    		 ConcurrentHashMap<LocalDateTime, Integer> map = new ConcurrentHashMap<LocalDateTime, Integer>();
		    		 value = value +1;
	    			 map.put(LocalDateTime.now(), value++);
	    			 ipBasedRateLimitMap.put(http.getRemoteHost(), map);
	    			 return true;
		    	 }
	    	 }
	    	 else {
	    		 ConcurrentHashMap<LocalDateTime, Integer> map = new ConcurrentHashMap<LocalDateTime, Integer>();
		    	 map.put(LocalDateTime.now(), 1);
		    	 ipBasedRateLimitMap.put(http.getRemoteHost(),map);
		    	 return true;
	    	 }
	     }
	     else {
	    	 ConcurrentHashMap<LocalDateTime, Integer> map = new ConcurrentHashMap<LocalDateTime, Integer>();
	    	 map.put(LocalDateTime.now(), 1);
	    	 ipBasedRateLimitMap.put(http.getRemoteHost(),map);
	    	 return true;
	     }
	}
	
 

}
