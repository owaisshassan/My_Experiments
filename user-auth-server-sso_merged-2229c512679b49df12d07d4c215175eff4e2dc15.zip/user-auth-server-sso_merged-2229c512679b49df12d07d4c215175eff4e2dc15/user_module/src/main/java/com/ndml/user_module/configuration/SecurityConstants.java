package com.ndml.user_module.configuration;

public interface SecurityConstants {
	
//	public static final String JWT_KEY = "======================ndml=jwt===========================";  
	
	public static final String JWT_KEY = "secretn@827Bydjnsk$3sb^bhwkoveesvnj&$%ndml#svsohbdhcftohbd";  
	
	public static final String JWT_HEADER = "Authorization";
	
	public static final long EXPIRE_TOKEN_AFTER_MINUTES = 5;

}


